#!/usr/bin/env python3
"""
    CumfatMethods Module.
        This module contains Cumfat-specific methods 
            that aren't attached to the classes at this stage.

"""

def get_cumfat_error_from_code(code):
    """
        This method returns the error code intepretation given a Cumfat error code.
        Right now, there are limitations. Some cumfat versions seem to have other error codes,
        prefixed with a W. This handles just E codes for now.
    """
    error_dict = {
            "E1":  "Node temperature is less than available temperatures for Youngs modulus and Poissons Ratio.  (Material data, node temperature less than TVA in .d21 file.)",
            "E2":  "Node temperature is greater than available temperatures for Youngs modulus and Poissons Ratio. (Material data, node temperature greater than TVA in .d21 file.)",
            "E3":  "Node temperature is less than temperature of available LCF data. (Material data, node temperature less than TLCFA in .d21 file.)",
            "E4":  "Node temperature is greater than temperature of available LCF data. (Material data, node temperature greater than TLCFA in .d21 file.)",
            "E5":  "Node temperature is less than temperature of available stress-strain data. (Material data, node temperature less than TCA in .d21 file.)",
            "E6":  "Node temperature is greater than temperature of available stress-strain data. (Material data, node temperature greater than TCA in .d21 file.)",
            "E7":  "Stress/strain range of RFC cycle is greater than available LCF material data. (Material data, RFC cycle stress/strain range greater than LCF material data in .d21 file)",
            "E8":  "Node stress greater than creep material data. (Material data, node stress above CREEP_sig in .d21 file.)",
            "E9":  "Node temperature is greater than creep material data. (Material data, node temperature above CREEP_maxT in .d21 file.)",
            "E10": "In elastic-plastic correction subroutine, extrapolation is needed to calculate elastic plastic corrected stress and strain (Material data, node stress/strain greater than SCA - ECA in .d21 file.)",
            "E11": "In elastic-plastic correction subroutine before RFC, cyclic plasticity exists."
    }
    return error_dict.get(code)
