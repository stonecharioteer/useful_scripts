#!/opt/anaconda3/bin/python3
# -*- conding: utf-8 -*-

from .pansys import Ansys
from .pansys import tests
