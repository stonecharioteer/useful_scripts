#!/usr/bin/env python3

class InvalidInput(Exception):
	"""This exception is raised whenever an invalid input is passed to a method.
	TODO: Expand this class to print a standard output, and accept 
	excepted type, received type, and received value."""
	def __init__(self, value):
		self.value = value

	def __str__(self):
		return repr(self.value)