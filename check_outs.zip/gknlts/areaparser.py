#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
"""

class Area(object):
    """Class to parse the Area XML file and extract
    information from it."""
    def __init__(self, area_file_path=None, *args, **kwargs):
        super().__init__()
        self.xml = None
        if area_file_path is None:
            self.area_file_path = None
        else:
            self.area_file_path = area_file_path
            self.load_from_xml(self.area_file_path)

    def load_from_xml(self, path_to_xml):
        """Method to parse XML."""
        import pandas as pd
        import xml.etree.ElementTree as ET
        with open(path_to_xml, "r") as f:
            xml_data = f.read()
        # element tree
        root = ET.XML(xml_data)

        area_tags = root.findall("area")
        areas = []
        for area in area_tags:
            area_dict = {
                    "id": area.attrib["id"]
                        }
            children = area.getchildren()
            for child in children:
                if child.text is not None and child.text.strip() != "":
                    area_dict[child.tag] = child.text.strip()
                else:
                    keys = list(child.attrib.keys())
                    if len(keys) == 1:
                        area_dict[child.tag] = child.attrib[keys[0]]
                    elif len(keys) == 0:
                        # Need to check this child's children.
                        s_children = child.getchildren()
                        for s_child in s_children:
                            s_child_key = child.tag + "_" + s_child.tag
                            not_none = s_child.text is not None
                            if not_none and s_child.text.strip != "":
                                area_dict[s_child_key] = s_child.text
                            else:
                                area_dict[s_child_key] = s_child.getchildren()
                    else:
                        print("*"*10)
                        print(keys)
                        print("*"*10)
                        raise Exception("Stop!")
            areas.append(area_dict)
        area_keys = []
        for area in areas:
            keys = sorted(area.keys())
            if len(keys) > len(area_keys):
                area_keys = keys
        area_xml_df = pd.DataFrame(columns=area_keys)
        for area in areas:
            for key in area_keys:
                if key not in area.keys():
                    area[key] = "-"
            area_xml_df = area_xml_df.append(area, ignore_index=True)

        self.xml = area_xml_df


#end
