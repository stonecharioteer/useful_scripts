"""
PWLife Module
===
This module provides an interface to parse PWlife input files.
It will enable users to read these files and construct their own PWLife files.
The module also makes it easy to run PWLife with a given PWLife input file.
It's also easy to run PWLife using the data from a PWLife object.
===
Maintained & Created by : Najeem Muhammed & Vinay Keerthi

"""
import os
from getpass import getuser
import datetime
import subprocess
from shutil import copyfile

import pandas as pd

class PWLife(pd.DataFrame):
    """PWLife Dataframe class
    Derived from Pandas Dataframe class
    """
    # Store the csv and node file from which the orignal data came from.
    csv_file = None
    nod_file = None

    _metadata = ['config']

    @property
    def _constructor(self):
        return PWLife

    def _repr_html_(self):
        """Definition for IPython's HTML representation of PWLife object."""
        html = super()._repr_html_()

        # When the dataframe is created by concating, the config data will not get copied.
        try:
            config_html = self.config._repr_html_()
        except AttributeError:
            config_html = "<p>The new PWLife object does not have a config data " +\
                          "associated with it. You can copy the config data " +\
                          "from the another PWLife object</p>"
        
        info = "<h1>PWLife Object Definition</h1><br>"
        info += "<b>CSV File Path:</b> {}<br>".format(self.csv_file)
        info += "<b>Node File Path:</b> {}<br>".format(self.nod_file)
        info += "<b>No. of Nodes:</b> {}<br>".format(len(self.nodes()))
        info += "<b>No. of Time Points:</b> {}".format(len(self.timepoints()))
        info += "<h2>Config Data</h2> <br>"
        info += config_html
        info += "<h2>Stress Data</h2> <br>"
        info += html
        return info
          
    def nodes(self):
        """Returns a list of all nodes in the current PWLife file"""
        # get_level_values will return all the indices in the data frame at
        # the specified level.
        return self.index.get_level_values(0).unique()
    
    def timepoints(self):
        """Returns a list of all timepoints in the current PWLife file"""
        # get_level_values will return all the indices in the data frame at
        # the specified level.
        return self.index.get_level_values(1).unique()
    
    def get_subset(self,nodes=None,timepoints=None):
        """Get a subset of the PWLife data filtered by node and timepoint list.
        
        Parameters
        ----------
        nodes : A list or range of nodes in string format.
        timepoints : A list or range of timepoints in string format.
                
        Example of a list: "1,3,2,23"
        Example of a range: "1:10"
            
        You can combine the above method as well
        Example of combination: "1:10,15:18"
        """
        idx = pd.IndexSlice
        if nodes==None or nodes=="":
            idx_nodes = eval("idx[:]")
        else:
            idx_nodes = eval("idx[{}]".format(nodes))
        if timepoints==None or timepoints=="":
            idx_tp = eval("idx[:]")
        else:
            idx_tp = eval("idx[{}]".format(timepoints))
        return self.loc[(idx_nodes,idx_tp),:].copy()

    def write_pwlife(self,file_prefix):
        """Function to write out a PWLife dataframe.

        Parameters
        ----------
        file_prefix: The prefix of the file, including the path, to which the
                     PWLife data should be written. Two files will be generated.
                     A csv file and a nod file; csv file contaning the PWLife
                     data and nod file containing the node list.
        """
        self.sort_index(level=0, inplace=True)
        node = 0
        with open(file_prefix + ".csv", "w") as out_csv, open(file_prefix + ".nod", "w") as out_nod:
            out_csv.write("z515,2,,,\n")
            for row in self.itertuples():
                if row.Index[0] != node:
                    node = row.Index[0]
                    out_nod.write(str(node) + "\n")
                    check = True
                    for item in self.config.columns:
                        if check:
                            prefix = "mission,config,"
                            check = False
                        else:
                            prefix = ",,"
                        # There will be only one row in config. Hence taking the first item from the list
                        out_csv.write(prefix + ",".join([item]+[str(self.config[item][0])]) + "\n")
                    out_csv.write(",points,time," + ",".join([item for item in self.columns]) + "\n")
                out_csv.write(",," + ",".join([str(row.Index[1])] + [str(item) for item in row[1:]]) + "\n")

    def calc_life(self,run_path,run_command='pwlife'):
        """Function to calculate life from the PWLife dataframe
        
        This function will calculate the life numbers for the current PWlife
        dataframe. It will run pwlife and pwlife2ans scripts in the background
        and read the *.life file into a pandas dataframe. The run_path variable
        has to be set so that the huge files that gets created during the run
        does not end up in an un-expected location.

        Parameters
        ----------
        run_path : The folder path where you want the output files to be stored.
                   If the pwlife dataframe is huge, it may produce huge files at
                   this location.

        run_command : The command that should be used to run pwlife. The default
                      is 'pwlife' which will inturn take the latest pwlife version
                      from the pwlife directory. You can substitute it with another
                      version of pwlife if needed.
        """
        if not os.path.exists(run_path):
            print("Path {} not found, creating".format(run_path))
            os.makedirs(run_path)
        print("Writing PWLife file...")
        self.write_pwlife(os.path.join(run_path, "pwlife_run"))
        cwd = os.getcwd()
        os.chdir(run_path)
        print("Running PWLife...")
        subprocess.check_output([run_command,"pwlife_run.csv"])
        if not os.path.exists("pwlife_run.out.pout"):
            os.chdir(cwd)
            raise OSError("The PWLife run was not successful")
        print("Converting PWLife files to ans format...")
        subprocess.check_output(["pwlife2ans",
                                 "-i","pwlife_run.out.pout",
                                 "-c","pwlife_run.nod",
                                 "-o","pwlife_run"])
        if not os.path.exists("pwlife_run.life"):
            os.chdir(cwd)
            raise OSError("The pwlife2ans run was not succesful")
        print("Reading PWLife output")
        retlife = read_pwlife_out("pwlife_run.life","life")
        os.chdir(cwd)
        return retlife

def read_pwlife(csv_file, nod_file):
    """Read a pwlife csv and node file into a pandas dataframe.

    This function reads the PWLife input file in csv format and a node file 
    into a Pandas dataframe. The returned object is a pandas dataframe.
    The object also stores the PWLife config data under object.config function.
    This also return a dataframe with config data.

    Usage:
        my_var = read_pwlife(csv_file, nod_file)

    Parameters
    ---------
    csv_file : The path to the csv file to be read in.
               The first line of the csv file should contain z515,2 which denotes
               the PWLife input file format. If it is not found, the read
               operation will throw a value error.

    nod_file : The file containing the node list corresponding to the csv file.
               If there are less number of nodes in the node file than the csv
               mission data, then the read operation will return an error. If
               Node file contains more nodes, then the read_operation will 
               succeed. However, the user should make sure that the csv and node
               data are corresponding to each other.
    """
    config = {}
    node_matrix = []
    mheader = sheader = None
    with open(csv_file, "r") as fstress, open(nod_file, "r") as fnode:
        mheader = [item.strip() for item in fstress.readline().lower().strip().
                                            rstrip(",").split(",")]
        if not mheader[0] == 'z515' or not mheader[1] == '2':
            raise ValueError("The file format of csv file does not match a " +
                              "PWLife input file format")
        for line in fstress:
            data = [item.strip() for item in line.lower().strip().
                                             rstrip(",").split(",")]
            #print(data)
            if data[0] != "": l1 = data[0]
            if data[1] != "": l2 = data[1]
            if l1 == "mission":
                if l2 == "config":
                    if config.get(data[2]) and config.get(data[2]) != data[3]:
                        print("Config mis-match between nodes")
                    else:
                        config[data[2]] = data[3]
                elif l2 == "points":
                    if sheader == None:
                        sheader = ["NodeID"] + data[2:]
                        node_matrix.append(sheader)
                    if not is_float(data[2]):
                        nline = [item.strip() for item in fnode.readline().split()]
                    else:
                        try:
                            row = [int(nline[0])] + [float(item) for item in data[2:]]
                            node_matrix.append(row)
                        except ValueError:
                            pass
        npwdf = PWLife(node_matrix[1:],columns=node_matrix[0])
        npwdf.csv_file = csv_file
        npwdf.nod_file = nod_file
        npwdf.config = pd.DataFrame(list(config.items()), columns=["Item", "Value"])
        npwdf.config.set_index("Item", inplace=True)
        npwdf.config = npwdf.config.transpose()
        npwdf.set_index(["NodeID", "time"], inplace=True)
        return npwdf

def read_pwlife_out(out_path,out_type):
    if out_type is None:
        raise ValueError("You have to give an out_type that you want to read")
    elif not os.path.exists(out_path):
        raise OSError("Output file {} is not existing".format(out_path))
    if out_type == "pout":
        pass
    elif out_type == "life":
        out_matrix = []
        with open(out_path, "r") as outfile:
            for line in outfile:
                row = [item.strip() for item in line.lower().split(",")]
                if row[0] == "dnsol" and is_float(row[1]):
                    out_matrix.append([int(row[1]), float(row[4])])
    newdf = pd.DataFrame(out_matrix, columns=["NodeID", "Life"])
    newdf.set_index("NodeID", inplace=True)
    return newdf

def run_pwlife(csv_file, nod_file, run_path, run_command="pwlife"):
    """Function to calculate life from the PWLife input files
    without reading the pwlife data into a dataframe.
    
    This function will calculate the life numbers for the a given PWLife
    input file. It will run pwlife and pwlife2ans scripts in the background
    and read the *.life file into a pandas dataframe. The run_path variable
    has to be set so that the huge files that gets created during the run
    does not end up in an un-expected location.

    Parameters
    ----------
    csv_file : The path to the csv file to be read in.
               The first line of the csv file should contain z515,2 which denotes
               the PWLife input file format. If it is not found, the read
               operation will throw a value error.

    nod_file : The file containing the node list corresponding to the csv file.
               If there are less number of nodes in the node file than the csv
               mission data, then the read operation will return an error. If
               Node file contains more nodes, then the read_operation will 
               succeed. However, the user should make sure that the csv and node
               data are corresponding to each other.

    run_path : The folder path where you want the output files to be stored.
               If the pwlife dataframe is huge, it may produce huge files at
               this location.

    run_command : The command that should be used to run pwlife. The default
                  is 'pwlife' which will inturn take the latest pwlife version
                  from the pwlife directory. You can substitute it with another
                  version of pwlife if needed.

    Returns a pandas dataframe with node number as index and Life number as data
    """
    if not os.path.exists(run_path):
        print("Path {} not found, creating".format(run_path))
        os.makedirs(run_path)
    print("Copying the pwlife file to run path")
    copyfile(csv_file, os.path.join(run_path, "pwlife_run.csv"))
    copyfile(nod_file, os.path.join(run_path, "pwlife_run.nod"))
    cwd = os.getcwd()
    os.chdir(run_path)
    print("Running PWLife...")
    subprocess.check_output([run_command,"pwlife_run.csv"])
    if not os.path.exists("pwlife_run.out.pout"):
        os.chdir(cwd)
        raise OSError("The PWLife run was not successful")
    print("Converting PWLife files to ans format...")
    subprocess.check_output(["pwlife2ans",
                             "-i","pwlife_run.out.pout",
                             "-c","pwlife_run.nod",
                             "-o","pwlife_run"])
    if not os.path.exists("pwlife_run.life"):
        os.chdir(cwd)
        raise OSError("The pwlife2ans run was not succesful")
    print("Reading PWLife output")
    retlife = read_pwlife_out("pwlife_run.life","life")
    os.chdir(cwd)
    return retlife

def is_float(s):
    try:
        float(s)
        return True
    except ValueError:
        return False
