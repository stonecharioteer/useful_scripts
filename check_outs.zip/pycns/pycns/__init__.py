#!/opt/anaconda3/bin/python
# -*- coding:utf-8 -*-

"""
gkncns Module
---


This module was jointly developed at GKN Aerospace India by Najeem Muhammad and Vinay Keerthi. Feel free to contact one of them for assistance.

This module should be set up in a common way. Hence, there are a few dos and do-nots.
    DOs:
        1. Open your .cshrc file located in your Linux home folder. If the file doesn't exist, create it using gedit or vim.

            Depending upon your access and location, this can change. Don't worry, we are working on writing scripts to do all these for you. Please bear with us until then.
            
            In Bangalore/GAI use this.

            setenv PYTHONPATH /project/Methods_VAI/dev/stable

            For the GAS RM12 LTS project, use this.

            setenv PYTHONPATH /project/las_india/scripts/blr_modules/

            NOTE: 
            * This module depends upon the pandas python module. GKN has installed a packaged version of python with all the required dependencies in
            /opt/anaconda3.
            Contact one of the developers to find out how to use that version of python and jupyter-notebook as your default setup. Or alternately, add the following lines
            to your .cshrc file.

            alias python3 /opt/anaconda3/bin/python3
            alias jupyter-notebook /opt/anaconda3/bin/jupyter-notebook
            /opt/anaconda3/bin/jupyter nbextension enable --py widgetsnbextension

        2. Now, whenever you execute python scripts, you can directly import the module using the regular import statement.
        3. Go through the example Jupyter notebook that is provided in the examples directory.
        4. Navigate to the directory where this module is located and run `jupyter-notebook` in your shell. Firefox should launch with the directory.
            Execute the cns demo notebook and go through it to understand how to make use of this module.

    DoNots:
        1. DO NOT copy the module folder into another directory for your own use. If you wish to make improvements, contact us and we will grant you access to the development environment.
            Even if you don't want to make changes, do not copy the folder because the updates happen regularly and you will gain newer features all the time.

---


"""
from .cns import *
