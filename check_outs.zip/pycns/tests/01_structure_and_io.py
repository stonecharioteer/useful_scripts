#!/opt/anaconda3/bin/python3
# -*- coding:utf-8 -*-
"""Tests

Tests for the gkncns module.

"""

import unittest
import os
from pycns import CNS, read_cns, generate_random_cns

class TestStructure(unittest.TestCase):
    """Test Case to test the structure of a cns object."""
    def test_generate_random_cns_default(self):
        """Tests that the generate random cns function works with the default structure.
        Default shape of 50 nodes, 50 timepoints and 7 columns is expected."""
        cns = generate_random_cns()
        self.assertTrue(isinstance(cns, CNS))
        self.assertEqual(cns.shape, (50*50, 7))
        self.assertEqual(list(cns.columns), ["sxx", "syy", "szz", "sxy","syz", "sxz", "temp"])
        self.assertEqual(list(cns.index.names), ["NodeID", "time"])
    
    def test_generate_random_cns_custom(self):
        """Tests that generate_random_cns returns a cns with required size."""
        cns = generate_random_cns(nodes=10, time=10)
        self.assertEqual(cns.shape, (10*10, 7))
    
    def test_write_to_cns(self):
        """Tests writing to a *.cns file."""
        cns = generate_random_cns(nodes=10, time=10)
        cns.write_cns("test.cns")
        self.assertTrue(os.path.isfile("test.cns"))
        os.remove("test.cns")
    
    def test_read_cns(self):
        """Tests reading from a *.cns file."""
        cns = generate_random_cns(nodes=10, time=10)
        cns.write_cns("test.cns")
        cns = read_cns("test.cns")
        self.assertTrue(isinstance(cns, CNS))
        self.assertTrue(cns.shape, (10*10, 7))
        self.assertEqual(list(cns.columns), ["sxx", "syy", "szz", "sxy","syz", "sxz", "temp"])
        self.assertEqual(list(cns.index.names), ["NodeID", "time"])
        os.remove("test.cns")
    

if __name__ == "__main__":
    unittest.main()