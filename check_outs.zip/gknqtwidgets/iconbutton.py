#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 11:10:50 2017

@author: yy54426
"""

from PyQt5.QtWidgets import QPushButton
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSize


class IconButton(QPushButton):
    def __init__(self, label, image_path, size_tuple=None, *args, **kwargs):
        super(IconButton, self).__init__(*args, **kwargs)
        self.setIcon(QIcon(image_path))
        self.setText(label)
        if size_tuple is not None:
            self.setIconSize(QSize(*size_tuple))
