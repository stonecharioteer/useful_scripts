#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 11:08:42 2017

@author: yy54426
"""

import os

from PyQt5.QtWidgets import (QLabel, QLineEdit,
                             QHBoxLayout)

from PyQt5.QtWidgets import QFileDialog

from PyQt5.QtCore import QMargins, pyqtSignal

from .imagebutton import ImageButton
from .basewidget import BaseWidget

from .widgetmethods import get_image


class DirectoryWidget(BaseWidget):
    """QWidget to browse and load paths.

    Args:
        label:
            Label for the widget.
        directory:
            Instantiate with a path, if required.
        multi:
            Allow appending multiple directories to the path. Boolean.

    Returns:
        A QWidget item that can be used anywhere a PyQt Qt5 object can be used.
    """
    directoryChanged = pyqtSignal(str)

    def __init__(self, label=None, directory=None, multi=None, *args, **kwargs):
        super().__init__()
        self.multi = not(multi is None)
        self.directory = directory if directory is not None else os.getcwd()
        self.label = QLabel(label+":")
        self.line_edit = QLineEdit(self.directory)
        image_path = get_image("browse")
        self.browse_button = ImageButton(image_path)
        self.browse_button.setToolTip("Click to select {}.".format(label))
        self.layout = QHBoxLayout()
        self.layout.addWidget(self.label)
        self.layout.addWidget(self.line_edit)
        self.layout.addWidget(self.browse_button)
        self.layout.setContentsMargins(QMargins(0, 0, 0, 0))
        self.setLayout(self.layout)
        self.browse_button.clicked.connect(self.browse)
        self.line_edit.returnPressed.connect(self.pasteLocation)

    def set_label_visible(self, b):
        self.label.setVisible(b)

    def browse(self):
        instruction = "Select the {} directory: ".format(self.label.text())
        start_path = os.getcwd()
        directory = QFileDialog.getExistingDirectory(
                                        self,
                                        instruction,
                                        start_path
                                        )

        if not(directory is None or directory.strip() == ""):
            if os.path.exists(directory):
                self.directory = directory
                self.line_edit.setText(directory)
                self.directoryChanged.emit(self.directory)

    def pasteLocation(self):
        directory = self.line_edit.text().strip()
        if not(directory is None or directory.strip() == ""):
            if os.path.exists(directory):
                self.directory = directory
                self.line_edit.setText(directory)
                self.directoryChanged.emit(self.directory)
        else:
            message = ("{} is not a valid directory. "
                       "The directory will be reset to "
                       "the last known value.").format(directory)
            self.alert("Error", message)
            self.line_edit.setText(self.directory)
