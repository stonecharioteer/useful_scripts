#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 09:40:51 2017

@author: yy54426
"""

from PyQt5.QtWidgets import (QAbstractItemView,
                             QListWidget)
from PyQt5.QtCore import pyqtSignal, Qt

import os

class FileListWidget(QListWidget):
    itemDropped = pyqtSignal(list)

    def __init__(self, file_list=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if file_list is None:
            file_list = []
        else:
            if not isinstance(file_list, list):
                file_list = [file_list]
        self.file_list = []
        self.setAcceptDrops(True)
        self.setDragDropMode(
                QAbstractItemView.InternalMove)
        self.mapEvents()
        self.add_urls(file_list)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls:
            event.accept()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            super().dragMoveEvent(event)
            print("Internal 1")
        else:
            print("Internal 2")
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            links = []
            for url in event.mimeData().urls():
                links.append(str(url.toLocalFile()))
            self.itemDropped.emit(links)
            event.acceptProposedAction()
        else:
            super().dropEvent(event)
    def mapEvents(self):
        self.itemDropped.connect(self.add_urls)

    def add_urls(self, file_list):
        for i in file_list:
            if i not in self.file_list:
                self.file_list.append(i)
                self.addItem(i[-40:])

    def get_file_list(self):
        return self.file_list
