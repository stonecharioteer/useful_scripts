#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""This module provides an interface to the HPCMONWidget
QWidget class.

.. :module: HPCMonWidget
    :platform: Unix, Windows
    :synopsis: A PyQt5.QtWidgets.QWidget that is used
    to monitor the High Performance Cluster at
    GKN Aerospace Engine Systems (Sweden/India).

.. moduleauthor:: Vinay Keerthi (yy54426)
    <VinayKeerthi.KrishnapuramTirumala@gknaerospace.com>

"""

import sys

import pandas as pd
from PyQt5.QtWidgets import (QWidget, QLabel, QTextEdit,
                             QPushButton, QApplication,
                             QVBoxLayout)

from hpcjobmon.algorithms.unix_methods import get_qstat

from .tablewidget import TableWidget


class HPCMonWidget(QWidget):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.build_ui()
        self.show()

    def build_ui(self):
        label = QLabel("This")
        text_area = QTextEdit("")
        button = QPushButton("Push This")
        table = TableWidget()
        table.showDataFrame(get_qstat())
        layout = QVBoxLayout()
        layout.addWidget(label)
        layout.addWidget(text_area)
        layout.addWidget(button)
        layout.addWidget(table)
        self.setLayout(layout)


def main():
    app = QApplication([])
    widget = HPCMonWidget()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
