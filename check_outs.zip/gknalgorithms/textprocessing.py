#!/usr/bin/env python3
import os
import sys
import re
"""Text Processing Functions"""

def get_nth_instance(list_object,string_to_find,n,exact_match=None):
    """This method returns the index of the object which corresponds to the nth appearance within the given list."""
    if exact_match is None:
        exact_match = True #Default is an exact match.
        #Any other value indicates that a substring is needed.

    positions = []
    counter = 0
    for item in list_object:
        if exact_match:
            if item == string_to_find:
                positions.append(counter)
        else:
            if string_to_find in item:
                positions.append(counter)
        if len(positions) == n:
            break
        counter+=1
    return positions[-1] if len(positions)>0 else None

def get_matching_positions(list_object,string_to_find,exact_match=None):
    """This method returns the indices of the matching objects."""
    if exact_match is None:
        exact_match = True #Default is an exact match.
        #Any other value indicates that a substring is needed.
    positions = []
    counter = 0
    for item in list_object:
        if exact_match:
            if item == string_to_find:
                positions.append(counter)
        else:
            if string_to_find in item:
                positions.append(counter)
        counter+=1
    return positions

def get_file_as_string(file_path):
    """Returns file contents using force loading and iterating though all possible encodings."""
    pass

def xml2df(xml_data):
    import xml.etree.ElementTree as ET
    import pandas as pd
    root = ET.XML(xml_data) # element tree
    all_records = [] #This is our record list which we will convert into a dataframe
    for i, child in enumerate(root): #Begin looping through our root tree
        record = {} #Place holder for our record
        for subchild in child: #iterate through the subchildren to user-agent, Ex: ID, String, Description.
            record[subchild.tag] = subchild.text #Extract the text create a new dictionary key, value pair
            all_records.append(record) #Append this record to all_records.
    return pd.DataFrame(all_records) #return records as DataFrame

# end
