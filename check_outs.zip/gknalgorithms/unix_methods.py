#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""This module contains functions and methods native to Unix.

.. :module: unix_methods
    :platform: Unix
    :synopsis: Contains functions native to Unix. Raises
    IncompatibleOSError if invoked from non-Unix environments.

.. moduleauthor:: Vinay Keerthi (yy54426)
    <VinayKeerthi.KrishnapuramTirumala@gknaerospace.com>

"""
from gknexceptions import IncompatibleOSError


def get_qstat(user=None):
    """Get the output of the qstat command as a pandas dataframe.

    Uses subprocess.check_output to parse the output of
    the qstat Linux command. It then converts this to
    a pandas.DataFrame object for easy representation
    or filtering.

    Args:
        user:
            A user's yyid. If blank, it returns all users'
            processes.

    Returns:
        A pandas.DataFrame object that has information
        about HPC runs.

    Raises:
        exceptions.IncompatibleOSError:
            Raised when this function is invoked from an
            unsupported platform. Right now, the qstat command
            is only supported on GNU/Linux Platforms at GKN
            Aerospace Engine Systems.
    TODO:
        * Clean output to align to the right columns. There is some
          ambiguity about the columns and the values parsed.
    """
    import os
    from subprocess import check_output
    import pandas as pd
    if os.name != "posix":
        err = ("The qstat command cannot be invoked "
               "in a non-Unix environment!")
        raise IncompatibleOSError(err)
    else:
        if user is None:
            user = "*"
        qstat_list = ["qstat", "-u", user]
        output = str(check_output(qstat_list), "utf-8")
        if output.strip() == "":
            return None
        else:
            out_list = output.split("\n")
            qstat_list = [x.split() for x in out_list]
            qstat_list = [x[:9] for x in qstat_list if len(x) >= 9]
            df = pd.DataFrame(qstat_list[1:], columns=qstat_list[0])
            return df
