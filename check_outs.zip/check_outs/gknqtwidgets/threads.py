#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 11 16:19:14 2017

@author: yy54426
"""

from PyQt5.QtCore import QThread

class QStatThread(QThread):
    """
    Thread to transmit QStat information.
    """
    def __init__(self, *args, **kwargs):
        super().__init__()
