#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""This module provides an interface to the HPCJonMon
QWidget class.

.. :module: HPCJonMon
    :platform: Unix, Windows
    :synopsis: A PyQt5.QtWidgets.QWidget that is used
    to monitor the High Performance Cluster at
    GKN Aerospace Engine Systems (Sweden/India).

.. moduleauthor:: Vinay Keerthi (yy54426)
    <VinayKeerthi.KrishnapuramTirumala@gknaerospace.com>

"""

import sys

from PyQt5.QtWidgets import (QWidget, QLabel, QTextEdit,
                             QPushButton, QApplication,
                             QVBoxLayout)


class HPCJobMon(QWidget):
    def __init__(self, *args, **kwargs):
        super().__init__()
        self.build_ui()
        self.show()

    def build_ui(self):
        label = QLabel("HPCJobMon")
        text_area = QTextEdit("")
        button = QPushButton("Push This")
        layout = QVBoxLayout()
        layout.addWidget(label)
        layout.addWidget(text_area)
        layout.addWidget(button)
        self.setLayout(layout)


def run_hpcjobmon(*args):
    app = QApplication([])
    widget = HPCJobMon(*args)
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
