#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 19 11:56:30 2017

@author: yy54426
"""

from PyQt5 import QtWidgets, QtCore

import sys
import pickle
from io import StringIO
import copy

class Item(object):
    def __init__(self, name, parent=None):
        self.name = name
        self.children = []
        self.parent = parent

        if parent is not None:
            self.parent.addChild( self )

    def addChild(self, child):
        self.children.append(child)
        child.parent = self

    def removeChild(self, row):
        self.children.pop(row)

    def child(self, row):
        return self.children[row]

    def __len__(self):
        return len(self.children)

    def row(self):
        if self.parent is not None:
            return self.parent.children.index(self)

#====================================================================

class PyObjMime(QtCore.QMimeData):
    MIMETYPE = 'application/x-pyobj'

    def __init__(self, data=None):
        super(PyObjMime, self).__init__()

        self.data = data
        if data is not None:
            # Try to pickle data
            try:
                pdata = pickle.dumps(data)
            except:
                return

            self.setData(self.MIMETYPE, pickle.dumps(data.__class__) + pdata)

    def itemInstance(self):
        if self.data is not None:
            return self.data

        io = StringIO(str(self.data(self.MIMETYPE)))

        try:
            # Skip the type.
            pickle.load(io)

            # Recreate the data.
            return pickle.load(io)
        except:
            pass

        return None

#====================================================================

class TreeModel(QtCore.QAbstractItemModel):
    def __init__(self, root, parent=None):
        super(TreeModel, self).__init__(parent)
        self.root = root

    def itemFromIndex(self, index):
        if index.isValid():
            return index.internalPointer()
        return self.root

    def rowCount(self, index):
        item = self.itemFromIndex(index)
        return len(item)

    def columnCount(self, index):
        return 1

    def flags(self, index):
        if not index.isValid():
            return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsDropEnabled
        return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsDropEnabled | QtCore.Qt.ItemIsDragEnabled | QtCore.Qt.ItemIsSelectablel

    def supportedDropActions(self):
        return QtCore.Qt.MoveAction | QtCore.Qt.CopyAction

    def data(self, index, role):
        if role == QtCore.Qt.DisplayRole:
            item = self.itemFromIndex(index)
            return item.name

    def index(self, row, column, parentIndex):
        parent = self.itemFromIndex(parentIndex)
        return self.createIndex( row, column, parent.child(row) )

    def parent(self, index):
        item = self.itemFromIndex(index)
        parent = item.parent
        if parent == self.root:
            return QtCore.QModelIndex()
        return self.createIndex(parent.row(), 0, parent)

    def insertRows(self, row, count, parentIndex):
        self.beginInsertRows(parentIndex, row, row+count-1)
        self.endInsertRows()
        return True

    def removeRows(self, row, count, parentIndex):
        self.beginRemoveRows(parentIndex, row, row+count-1)
        parent = self.itemFromIndex(parentIndex)
        parent.removeChild(row)
        self.endRemoveRows()
        return True

    def mimeTypes(self):
        types = []
        types.append('application/x-pyobj')
        return types

    def mimeData(self, index):
        item = self.itemFromIndex(index[0])
        mimedata = PyObjMime(item)
        return mimedata

    def dropMimeData(self, mimedata, action, row, column, parentIndex):
        item = mimedata.itemInstance()
        dropParent = self.itemFromIndex(parentIndex)
        itemCopy = copy.deepcopy(item)
        dropParent.addChild(itemCopy)
        self.insertRows(len(dropParent)-1, 1, parentIndex)
        self.dataChanged.emit(parentIndex, parentIndex)
        return True

if __name__ == '__main__':

    app = QtWidgets.QApplication(sys.argv)

    root = Item( 'root' )
    itemA = Item( 'ItemA', root )
    itemB = Item( 'ItemB', root )
    itemC = Item( 'ItemC', root )
    itemD = Item( 'ItemD', root )
    itemE = Item( 'ItemE', root )
    itemF = Item( 'ItemF', root )

    model = TreeModel(root)
    tree = QtWidgets.QTreeView()
    tree.setModel( model )
    tree.setDragEnabled(True)
    tree.setAcceptDrops(True)
    tree.setDragDropMode( QtWidgets.QAbstractItemView.InternalMove )
    tree.show()
    tree.expandAll()
    sys.exit(app.exec_())
