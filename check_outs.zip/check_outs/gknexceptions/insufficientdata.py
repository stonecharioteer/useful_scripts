#!/usr/bin/env python3
"""
Custom Exception
Defines the InsufficientData exception. This should be raised whenever a particular customclass
doesn't have enough data to go with.
"""

class InsufficientData(Exception):
	"""This error is raised when there is insufficient data for a particular class to be usable."""
	pass
