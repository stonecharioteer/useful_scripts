"""
This exception is thrown whenever a folder is write protected.
"""
class WriteProtected(Exception):
    pass
