#!/usr/bin/env python3
class CumfatLimitation(Exception):
	pass