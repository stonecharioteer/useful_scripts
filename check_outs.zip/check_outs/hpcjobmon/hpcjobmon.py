#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""This module provides an interface to the HPCMONWidget
QWidget class.

.. :module: HPCMonWidget
    :platform: Unix, Windows
    :synopsis: A PyQt5.QtWidgets.QWidget that is used
    to monitor the High Performance Cluster at
    GKN Aerospace Engine Systems (Sweden/India).

.. moduleauthor:: Vinay Keerthi (yy54426)
    <VinayKeerthi.KrishnapuramTirumala@gknaerospace.com>

"""

import sys
import os
from os.path import basename
import argparse
import time

from glob import glob

import pandas as pd

from PyQt5.QtWidgets import (QLabel, QPushButton,
                             QApplication, QComboBox,
                             QCheckBox, QLineEdit,
                             QSlider, QRadioButton, QLayout,
                             QButtonGroup, QGridLayout)

from PyQt5.QtCore import (Qt, QThread, pyqtSignal,
                          QMutex, QWaitCondition)

from PyQt5.QtGui import QIcon

from gknalgorithms.unix_methods import get_qstat
from gknalgorithms.analysis_methods import get_ansys_license_info

from gknqtwidgets import (BaseWidget, TableWidget,
                          DirectoryWidget, IconButton,
                          FileListWidget, get_image)


class HPCJobMonThread(QThread):
    """PyQt5.QtCore.QThread object that is to be used to provide
    a responsive interface..

    This is the class via which is used to execute commands.

    TODO:
        Use requests to communicate with the listening server.
    """
    qstat_signal = pyqtSignal(pd.DataFrame)
    defaults_signal = pyqtSignal(dict)
    license_signal = pyqtSignal(list)

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.enabled = True
        self.defaults_dict = None

        self.mutex = QMutex()
        self.condition = QWaitCondition()

        if not self.isRunning():
            self.start(QThread.LowPriority)

    def run(self):
        """Execution function."""
        while True:
            if self.enabled:
                # TODO: These calls need to be sent to
                # the listening server.
                qansys_paths = glob("/opt/qscripts/qansys*")
                qansys_list = [basename(x) for x in qansys_paths]
                ansys_paths = glob("/usr/local/bin/ansys*")
                ansys_list = [basename(x) for x in ansys_paths]
                defaults_dict = {
                        "ansys": {
                                "qserver": qansys_list,
                                "local": ansys_list
                                }
                        }
                if defaults_dict != self.defaults_dict:
                    self.defaults_dict = defaults_dict
                    self.defaults_signal.emit(self.defaults_dict)
                qstat_data = get_qstat()
                if qstat_data is not None:
                    self.qstat_signal.emit(qstat_data)
                license_info = get_ansys_license_info()
                self.license_signal.emit(license_info)
                time.sleep(10)

    def __del__(self):
        """Deleter function."""
        self.mutex.lock()
        self.condition.wakeOne()
        self.mutex.unlock()
        self.wait()

    def disable(self):
        self.enabled = False

    def enable(self):
        self.enabled = True


class HPCJobMon(BaseWidget):
    """PyQt5.QtWidgets.QWidget object that can be used to send
    jobs to the cluster.

    """
    def __init__(self, server_id=None, input_files=None, *args, **kwargs):
        super().__init__()
        if input_files is None:
            self.input_files = []
        else:
            if isinstance(input_files, list):
                self.input_files = input_files
            else:
                self.input_files = [input_files]
        if server_id is None:
            self.server_id = None
        else:
            self.server_id = server_id
            # TODO: Add listening server validation here.

        self.ansys_dict = {
                "qserver": [],
                "local": []
                }
        self.license_info_dict = [
                {
                    "license": "meba",
                    "status": None,
                    "users": None
                },
                {
                    "license": "preppost",
                    "status": None,
                    "users": None
                },
                {
                    "license": "ansys",
                    "status": None,
                    "users": None
                }]

        self.build_ui()
        self.create_threads()
        self.map_events()
        self.reset()
        self.show()
        self.center()

    def build_ui(self):
        """Build the UI and sets layout."""
        # Create the widgets.
        # NOTE: All widgets need to be accessible at the "self" level.
        #    In other terms, they need to be accessible as class attributes,
        #    if the user is planning on attaching actions to them.
        #    Labels don't really need to be defined at the class level,
        #    but it's safer to do so.
        self.input_files_button = QPushButton("Input Files (-i)")
        # self.input_files_dir_label = QLabel("Input Files (-i):")
        # self.input_files_dir_widget = DirectoryWidget("Input Files")
        # self.input_files_dir_widget.set_label_visible(False)
        self.input_files_listbox = FileListWidget(self.input_files)
        self.input_files_listbox.setVisible(False)

        self.local_cluster_label = QLabel("Run in Local or Q-Server:")
        self.local_radio = QRadioButton("Local System")
        self.cluster_radio = QRadioButton("Q-Server")

        self.local_cluster_button_group = QButtonGroup()
        self.local_cluster_button_group.addButton(self.local_radio)
        self.local_cluster_button_group.addButton(self.cluster_radio)

        self.use_distributed_checkbox = QCheckBox("DMP (-dis)")

        self.ansys_version_label = QLabel("Ansys Version")
        self.ansys_version_dropbox = QComboBox()
        self.license_label = QLabel("License Type (-p):")
        self.license_meba_radio = QRadioButton("meba")
        self.license_ansys_radio = QRadioButton("ansys")
        self.license_preppost_radio = QRadioButton("preppost")

        self.license_group = QButtonGroup()
        self.license_group.addButton(self.license_meba_radio)
        self.license_group.addButton(self.license_ansys_radio)
        self.license_group.addButton(self.license_preppost_radio)

        self.processors_label = QLabel("Number of Processors (-np):")
        self.processors_slider = QSlider(Qt.Horizontal)
        self.processors_slider_value = QLabel()
        self.output_files_dir_label = QLabel("Output File:")
        self.output_files_dir_widget = DirectoryWidget("Output File")
        self.output_files_dir_widget.set_label_visible(False)
        self.jobname_label = QLabel("Job Name (-j):")
        self.jobname_lineedit = QLineEdit()

        self.queue_label = QLabel("Queue to Job (-D):")
        self.queue_button = QPushButton("Select &Job ID(s)")
        self.license_button = QPushButton("Check &License Availability")
        self.run_button = IconButton("&Run", get_image("run"))
        self.qstat_mon_table = TableWidget()
        self.license_table = TableWidget()

        css_content = """
        .QLabel, .QPushButton, .QRadioButton,
        .QCheckBox, .QLineEdit, .QComboBox,
        .IconButton, .FileListWidget, .ImageButton {
                font-size: 14px;
                min-height: 30px;
                }
        """
        self.setStyleSheet(css_content)

        # Create the layout and attach it to this widget.
        layout = QGridLayout()
        layout.addWidget(self.input_files_button, 0, 0, 1, 4)
        # layout.addWidget(self.input_files_dir_label, 0, 0, 1, 1)
        # layout.addWidget(self.input_files_dir_widget, 0, 1, 1, 3)
        layout.addWidget(self.local_cluster_label, 1, 0, 1, 1)
        layout.addWidget(self.local_radio, 1, 1, 1, 1)
        layout.addWidget(self.cluster_radio, 1, 2, 1, 1)
        layout.addWidget(self.use_distributed_checkbox, 1, 3, 1, 1)
        layout.addWidget(self.input_files_listbox, 0, 4, 10, 3)

        layout.addWidget(self.ansys_version_label, 2, 0, 1, 1)
        layout.addWidget(self.ansys_version_dropbox, 2, 1, 1, 3)
        layout.addWidget(self.license_label, 3, 0)
        layout.addWidget(self.license_meba_radio, 3, 1, 1, 1)
        layout.addWidget(self.license_ansys_radio, 3, 2, 1, 1)
        layout.addWidget(self.license_preppost_radio, 3, 3, 1, 1)

        layout.addWidget(self.processors_label, 4, 0)
        layout.addWidget(self.processors_slider, 4, 1, 1, 2)
        layout.addWidget(self.processors_slider_value,
                         4, 3, 1, 1, Qt.AlignCenter)
        layout.addWidget(self.output_files_dir_label, 5, 0, 1, 1)
        layout.addWidget(self.output_files_dir_widget, 5, 1, 1, 3)
        layout.addWidget(self.jobname_label, 6, 0)
        layout.addWidget(self.jobname_lineedit, 6, 1, 1, 3)

        layout.addWidget(self.queue_label, 7, 0)
        layout.addWidget(self.queue_button, 7, 1, 1, 3)
        layout.addWidget(self.license_button, 8, 0, 1, 4)
        layout.addWidget(self.run_button, 9, 0, 1, 4)
        layout.setColumnStretch(0, 0)
        layout.setColumnStretch(1, 0)
        layout.setColumnStretch(2, 0)
        layout.setColumnStretch(3, 0)
        layout.setColumnStretch(4, 0)
        for i in range(11):
            layout.setRowStretch(i, 0)
        layout.setRowStretch(11, 2)
        layout.setSpacing(10)
        self.setLayout(layout)
        self.resize(500, 300)
        self.layout().setSizeConstraint(QLayout.SetFixedSize)

    def create_threads(self):
        """Creates the threads that this class can talk to."""
        self.message_thread = HPCJobMonThread()

    def map_events(self):
        """Maps events to functions within the class."""
        self.input_files_button.clicked.connect(self.toggle_input_listbox)
        self.message_thread.qstat_signal.connect(
                self.qstat_mon_table.showDataFrame)
        self.message_thread.defaults_signal.connect(
                self.assign_defaults)
        self.message_thread.license_signal.connect(
                self.set_license_info)

        self.local_cluster_button_group.buttonClicked.connect(
                self.remap_ansys_version)

        self.license_group.buttonClicked.connect(
                self.refresh_license_info)

        self.processors_slider.valueChanged.connect(self.refresh_processor)

    def toggle_input_listbox(self):
        if self.input_files_listbox.isVisible():
            self.input_files_listbox.setVisible(False)
        else:
            self.input_files_listbox.setVisible(True)

    def refresh_processor(self, val):
        if val not in range(2, 14, 2):
            val += 1
            if val > 12:
                val = 2
            self.processors_slider.setValue(val)
        self.processors_slider_value.setText(str(val))

    def refresh_license_info(self, *val):
        """Refreshes the license information based on the selected option."""
        license_ = None
        if self.license_ansys_radio.isChecked():
            license_ = "ansys"
        elif self.license_meba_radio.isChecked():
            license_ = "meba"
        elif self.license_preppost_radio.isChecked():
            license_ = "preppost"
        else:
            self.alert("Error!", "Wrong license is selected?")
        self.show_license_info(license_)

    def set_license_info(self, license_info):
        """Overwrites the license information list with
        the passed information."""
        self.license_info_dict = license_info
        self.refresh_license_info()

    def show_license_info(self, license_tag):
        """Renders license information on the button."""
        if license_tag is not None:
            license_info = None
            for license_info_dict in self.license_info_dict:
                if license_tag == license_info_dict["license"]:
                    license_info = license_info_dict["status"]
                    self.license_table.showDataFrame(
                            license_info_dict["users"])
                    break
            if license_info is None:
                self.license_button.setText("No License info available")
            else:
                msg = "See License Info ({})".format(license_info)
                self.license_button.setText(msg)

    def assign_defaults(self, defaults):
        """Takes the defaults that the message thread passes and
        uses it to set the values for the GUI's options."""
        self.ansys_dict = defaults["ansys"]
        self.reset()

    def reset(self):
        """Resets the UI to the default setting."""
        self.cluster_radio.setChecked(True)
        self.license_meba_radio.setChecked(True)
        self.processors_slider.setRange(2, 12)
        self.processors_slider.setTickInterval(2)
        self.processors_slider.setSingleStep(2)
        self.processors_slider.setTickPosition(2)
        self.processors_slider.setValue(8)
        self.remap_ansys_version()

    def remap_ansys_version(self, *args):
        if self.cluster_radio.isChecked():
            selected_server = "qserver"
            self.use_distributed_checkbox.setChecked(False)
            self.use_distributed_checkbox.setVisible(True)
        else:
            selected_server = "local"
            self.use_distributed_checkbox.setChecked(False)
            self.use_distributed_checkbox.setVisible(False)

        self.ansys_version_dropbox.clear()
        for i in sorted(self.ansys_dict[selected_server]):
            self.ansys_version_dropbox.addItem(i)


def run_hpcjobmon(*args):
    """Runs the HPCJobMon tool.

    Args:
        server_id:
            This is the host id and port of the listening server.
        input_files:
            This is a list of input files.

    Returns:
        N.A.

    Raises:
        Put exceptions list here.

    TODO:
        * Build exceptions for this.
        * Listening server and API.
        * Thread for the data pool.
    """
    app = QApplication([])
    widget = HPCJobMon(*args)
    widget.setWindowTitle("High Performance Cluster Job Monitor")
    widget.setWindowFlags(
            Qt.WindowMinimizeButtonHint | Qt.WindowCloseButtonHint)
    widget.setWindowIcon(QIcon(get_image("gkn_square", ext="ico")))
    widget.show()
    sys.exit(app.exec_())


def main():
    if os.name == "posix":
        server_id = "a"
        #  start_server()
    else:
        server_id = None
    parser = argparse.ArgumentParser()
    help_string = ("List of input files to "
                   "the hpcjobmon application. "
                   "Optional.")
    parser.add_argument("-i", "-inp", nargs='+', help=help_string)

    help_string = ("Run listening server only.")
    parser.add_argument("-s", "-serveronly",
                        help=help_string, action='store_true')

    input_files = parser.parse_args().i
    run_hpcjobmon(server_id, input_files)


if __name__ == "__main__":
    main()
