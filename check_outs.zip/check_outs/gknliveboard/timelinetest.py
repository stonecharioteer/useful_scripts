# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 15:05:26 2017

@author: Vinay.Keerthi
"""

def get_timeline_json(inp_file=None):
    import pandas as pd
    inp_file = r"C:\Users\vinay.keerthi\svn_repos\XT4210\apps\tinkering\check_outs\gknliveboard\data\timeline.xlsx"
    timeline_df = pd.read_excel(inp_file, sheetname="Sheet1")
    timeline_json = {
                        "title": {},
                        "events": []
                    }
    for ix, row in timeline_df.iterrows():
        row_json = {
                "text": {
                        "headline": "",
                        "text": ""
                        },
                "media": {
                        "url": "",
                        "caption":""
                        },
                "start_date": {
                        "year": "",
                        "month": "",
                        "day": ""
                        },
                "end_date": {
                        "year": "",
                        "month": "",
                        "day": ""
                        }
                }
        if row["text-headline"] != "":
            row_json["text"]["headline"] = row["text-headline"]

        if row["text-text"] != "":
            row_json["text"]["text"] = row["text-text"]

        if row["media-url"] != "":
            row_json["media"]["url"] = row["media-url"]

        if row["media-caption"] != "":
            row_json["media"]["caption"] = row["media-caption"]

        if not(pd.isnull(row["start-year"])):
            row_json["start_date"]["year"] = row["start-year"]

        if not(pd.isnull(row["start-month"])):
            row_json["start_date"]["month"] = row["start-month"]

        if not(pd.isnull(row["start-day"])):
            row_json["start_date"]["day"] = row["start-day"]

        if not(pd.isnull(row["end-year"])):
            row_json["end_date"]["year"] = row["end-year"]

        if not(pd.isnull(row["end-month"])):
            row_json["end_date"]["month"] = row["end-month"]

        if not(pd.isnull(row["end-day"])):
            row_json["end_date"]["day"] = row["end-day"]


        if row["type"] == "title":
            timeline_json["title"] = row_json
        else:
            timeline_json["events"].append(row_json)

    return timeline_json


a = get_timeline_json()