// Set some values.
var width = 900,
    height = window.innerHeight,
    slide_duration = 1250;

var projection = d3.geo.orthographic()
    .translate([width / 4, height / 4])
    .scale(width / 4 - 20)
    .clipAngle(90)
    .precision(0.6);

var canvas = d3.select("#chart").append("canvas")
    .attr("width", width/2)
    .attr("height", height/2)
    .attr("border","2px solid black");

var c = canvas.node().getContext("2d");

var path = d3.geo.path()
    .projection(projection)
    .context(c);

var title = d3.select("#country_name"),
    data_l = d3.select("#data_l"),
    data_r = d3.select("#data_r");


queue()
    .defer(d3.json, "/data/globe/world-110m.json") // GEOJSON.
    .defer(d3.json, "/data/globe/map_data") //Get map data from the map_list excel file.
    .await(begin_rotation);

function shift(i, n, countries, land, borders, globe) {
  i++;
  var country_name = countries[i % n].country;
  d3.transition()
      .duration(slide_duration)
      .each("start", function() {
        title.text(country_name);
        data_l.text("");
        data_r.text("Sites will be listed here");

      })
      .tween("rotate", function() {
        var p = d3.geo.centroid(countries[i]),
            r = d3.interpolate(projection.rotate(), [-p[0], -p[1]]);
        return function(t) {
          projection.rotate(r(t));
          c.clearRect(0, 0, width, height);
          // Other countries color
          c.fillStyle = "#03A9F4", c.beginPath(), path(land), c.fill();
          // Selected country color
          c.fillStyle = "#fbc02d", c.beginPath(), path(countries[i]), c.fill();
          // Border color
          c.strokeStyle = "#03A9F4", c.lineWidth = .5, c.beginPath(), path(borders), c.stroke();
          // Globe Border color
          c.strokeStyle = "#ffffff", c.lineWidth = 1, c.beginPath(), path(globe), c.stroke();
        };
      })
    .transition()
      .each("end", function(){
        if (i >= countries.length-1) {
          i=0;
          /*location.reload();*/
          shift(i, n, countries, land, borders, globe)
        } else {
          shift(i, n, countries, land, borders, globe)
        }
      })
  };
// Activate this function once the data is all loaded.
function begin_rotation(error, world, globe_data) {
  // world is a json that contains information about the
  if (error) throw error;
  //Take the globe_data and use it.
  var g_json = JSON.parse(globe_data),
      globe = {type: "Sphere"},
      land = topojson.feature(world, world.objects.land),
      countries = topojson.feature(world, world.objects.countries).features,
      borders = topojson.mesh(world, world.objects.countries, function(a, b) { return a !== b; }),
      i = -1,
      n = countries.length;

  countries = countries.filter(function(d) {
    return g_json.some(function(n) {
      //n is the geojson row.
      //d is the map list excel data.
      if (d.id == n.id) return d.country = n.country;
    });
  });
  countries = countries.sort(function(a, b) {
    return a.country.localeCompare(b.country);
  });
  shift(i, n, countries, land, borders, globe);
}
d3.select(self.frameElement).style("height", height + "px");
// d3.select("#chart").attr("align", "center");
// d3.select("#chart").attr("vertical-align","top");
d3.select("#chart").css({top: 200, left: 200, position:'absolute'});

