// Set some values.
var width = window.innerHeight/1.4,
    height = window.innerWidth/2.4,
    slide_duration = 12000;

var projection = d3.geo.orthographic()
    .translate([width / 2, height / 2])
    .scale(width / 2 - 20)
    .clipAngle(90)
    .precision(0.6);

var canvas = d3.select("#chart").append("canvas")
    .attr("width", width)
    .attr("height", height);

var c = canvas.node().getContext("2d");

var path = d3.geo.path()
    .projection(projection)
    .context(c);

var title = d3.select("h1");

queue()
    .defer(d3.json, "/data/globe/world-110m.json")
    .defer(d3.tsv, "/data/globe/world-country-names.tsv")
    .await(ready);

// Activate this function once the data is all loaded.
function ready(error, world, names) {
  // world is a json that contains information about the
  if (error) throw error;
  console.log(typeof(names));
  var globe = {type: "Sphere"},
      land = topojson.feature(world, world.objects.land),
      countries = topojson.feature(world, world.objects.countries).features,
      borders = topojson.mesh(world, world.objects.countries, function(a, b) { return a !== b; }),
      i = -1,
      n = countries.length;

  countries = countries.filter(function(d) {
    return names.some(function(n) {
      if (d.id == n.id) return d.name = n.name;
    });
  }).sort(function(a, b) {
    return a.name.localeCompare(b.name);
  });

  (function transition() {
    i++;
    if (i >= countries.length) {
      location.reload();
    }
    else {
    var country_name = countries[i % n].name;
    d3.transition()
        .duration(slide_duration)
        .each("start", function() {
          title.text(country_name);
        })
        .tween("rotate", function() {
          var p = d3.geo.centroid(countries[i]),
              r = d3.interpolate(projection.rotate(), [-p[0], -p[1]]);
          return function(t) {
            projection.rotate(r(t));
            c.clearRect(0, 0, width, height);
            c.fillStyle = "#03A9F4", c.beginPath(), path(land), c.fill();
            c.fillStyle = "#FFEB3B", c.beginPath(), path(countries[i]), c.fill();
            c.strokeStyle = "#03A9F4", c.lineWidth = .5, c.beginPath(), path(borders), c.stroke();
            c.strokeStyle = "#ffffff", c.lineWidth = 2, c.beginPath(), path(globe), c.stroke();
          };
        })
      .transition()
        .each("end", transition);
    }
  })();
}
d3.select(self.frameElement).style("height", height + "px");
d3.select("#chart").attr("align", "center");