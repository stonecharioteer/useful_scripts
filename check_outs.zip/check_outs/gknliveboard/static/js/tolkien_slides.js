Reveal.initialize({
    dependencies: [
        {src: 'lib/reveal.js/plugin/markdown/marked.js', condition: function() { return !!document.querySelector( '[data-markdown]' ); } },
        {src: 'lib/reveal.js/plugin/markdown/markdown.js', condition: function() { return !!document.querySelector( '[data-markdown]' ); } }
    ],
    markdown: {
        smartypants: true
    },
    slideNumber: true,
    hideAddressBar: true,
    transition: "convex",
    margin:0,
    width: "100%",
    height: "100%"
});