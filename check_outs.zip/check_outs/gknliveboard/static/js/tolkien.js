// Map Presentation script.
//
// Requires Leaflet.js, JQuery.js, and d3.js.
//
// Components should be served via the Flask API built
// for the gkn liveboard.
//
// This script should take into account the state of the toggle buttons
//
// It should also show the data for each site in a loop, progressing every x seconds.
//
// Author: Vinay Keerthi

var map_request = $.getJSON("/map_list_data", function (data) {
        console.log( "Requesting data from the server!" );
            })

map_request.done(function(data){
    buildMap(data);
    });


function buildMap(data) {
    // Build the map and loop through the entire thing.
    var mymap;
    var mapdata;
    var jList = JSON.parse(data);
    var points = [];
    var point_markers = [];

    var mapbox_api = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.'+
                'png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA'+
                '2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
    // Add the GEOJson data from openmaps.
    var basemap_layer = L.tileLayer(mapbox_api, {
        maxZoom: 9,
        minZoom: 2,
        attribution: 'GKN Aerospace India',
        id: "mapbox.run-bike-hike"
    });
    var satellite_layer = L.tileLayer(mapbox_api, {
        maxZoom: 9,
        minZoom: 2,
        attribution: 'GKN Aerospace India',
        id: "mapbox.satellite"
    });

    mymap = L.map('gkn_map', {
        center: [21.505, 10.09],
        zoom: 2,
        // maxBounds: bounds,
        // maxBoundsViscosity: 0.75,
        maxZoom:9
    });

    basemap_layer.addTo(mymap)
        // mapbox.run-bike-hike
        // mapbox.pencil
        // mapbox.streets
        // mapbox.light
        // mapbox.dark
        // mapbox.satellite
        // mapbox.streets-satellite
        // mapbox.wheatpaste
        // mapbox.streets-basic
        // mapbox.comic
        // mapbox.outdoors
        // mapbox.run-bike-hike
        // mapbox.pencil
        // mapbox.pirates
        // mapbox.emerald
        // mapbox.high-contrast

    var empty_icon = L.icon({
        iconUrl: '/static/images/marker.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [18, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });

    var gkn_icon = L.icon({
        iconUrl: '/static/images/gkn_marker.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [15, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });

    var fokker_icon = L.icon({
        iconUrl: '/static/images/fokker_marker.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [15, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });

    // When selected.

    var empty_icon_selected = L.icon({
        iconUrl: '/static/images/marker_selected.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [18, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });

    var gkn_icon_selected = L.icon({
        iconUrl: '/static/images/gkn_marker_selected.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [15, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });

    var fokker_icon_selected = L.icon({
        iconUrl: '/static/images/fokker_marker_selected.png',
        shadowUrl: '/static/images/shadow.png',

        iconSize:     [30, 50], // size of the icon
        shadowSize:   [34, 50], // size of the shadow
        iconAnchor:   [15, 45], // point of the icon which will correspond to marker's location
        shadowAnchor: [15, 44],  // the same for the shadow
        popupAnchor:  [-3, -44] // point from which the popup should open relative to the iconAnchor
    });


    function reBind(j) {
        html_content = "Clicked on " + j;
        if (j !== undefined) {
            var row = jList[j];
            var site_name = row["Site"];
            var competence = row["Competence"];
            var classification = row["Classification"];
            var products = row["Product From startsheets Excel"];
            var sitecontact = row["Site Contact"];
            var gaicontact = row["GAI Contact"];
            var delegations = row["Delegations held"];
            var active = row["Active/Non Active"];
            var invoicedhours = [
                    {label:"Q", value: row["Invoiced Hours"]},
                    {label:"Q -1", value:row["Invoiced Hours -Q1"]},
                    {label:"Q -2", value:row["Invoiced Hours -Q2"]},
                    {label:"Q -3", value:row["Invoiced Hours -Q3"]},
                    {label:"Q -4", value:row["Invoiced Hours -Q4"]},
                    {label:"Q -5", value:row["Invoiced Hours -Q5"]}
            ];
            change(invoicedhours);
            var point = [
                row["Latitude"],
                row["Longitude"]
            ];

            // console.log(html_content);

            $("#sitename").html(site_name);
            $("#competence").html(competence);
            $("#sitecontact").html(sitecontact);
            $("#gaicontact").html(gaicontact);
            $("#products").html(products);
            $("#delegations").html(delegations);

            // Zoom into selected point.
            // mymap.setView(point, 8);

            // Highlight
            for (var x=0; x<jList.length; x++) {
                var point_object = point_markers[x];
                if (x !== j ){
                    var point_site_name = jList[x]["Site"];
                    var point_classification = jList[x]["Classification"];

                    if (point_classification == "Site") {
                        if (point_site_name.indexOf("Fokker") == -1) {
                            point_object.setIcon(gkn_icon);
                        } else {
                            point_object.setIcon(fokker_icon);
                        };
                    } else {
                        point_object.setIcon(empty_icon);
                    }
                } else {
                    if (classification == "Site") {
                        if (site_name.indexOf("Fokker") == -1) {
                            point_object.setIcon(gkn_icon_selected);
                        } else {
                            point_object.setIcon(fokker_icon_selected);
                        };
                    } else {
                        point_object.setIcon(empty_icon_selected);
                    }
                }
            };

        // Need to put d3 plotting here.

        };
    };

    var rebindCalls = [];

    function createRebindCall(x) {
        return function(){ reBind(x); };
    };

    for (var k=0; k<jList.length; k++) {
        rebindCalls[k] = createRebindCall(k);
    };
    // keep all the sites together.
    var fokker_sites = L.layerGroup(),
        gkn_sites = L.layerGroup(),
        suppliers = L.layerGroup();

    for (var i=0; i<jList.length; i++) {
        var point = [
            jList[i]["Latitude"],
            jList[i]["Longitude"]
            ];
        var classification = jList[i]["Classification"];
        var site_name = jList[i]["Site"];
        var icon = empty_icon;
        var count = i;
        if (classification == "Site") {
            if (site_name.indexOf("Fokker") == -1) {
                icon = gkn_icon;
            } else {
                icon = fokker_icon;
            }
        };
        var p = L.marker(
            point,
            {
            icon: icon
            });

        point_markers.push(p);

        if (classification == "Site") {
            if (site_name.indexOf("Fokker") == -1) {
                p.addTo(gkn_sites);
            } else {
                p.addTo(fokker_sites);
            }
        } else {
            p.addTo(suppliers);
        };
        p.on("click", rebindCalls[i]);
    };

    var base_maps = {
        "World": basemap_layer,
        "Satellite": satellite_layer
    };
    var overlays = {
        "GKN Sites": gkn_sites,
        "Fokker Sites": fokker_sites,
        "Suppliers": suppliers
    };
    // var bounds = new L.LatLngBounds(new L.LatLng(140.0, 90.0), new L.LatLng(-140.0, -90.0));

    gkn_sites.addTo(mymap);
    fokker_sites.addTo(mymap);


    L.control.layers(base_maps, overlays).addTo(mymap);

    var margin = {
            top: (parseInt(d3.select('#invoicedhours').style('height'), 10)/10),
            right: (parseInt(d3.select('#invoicedhours').style('width'), 10)/20),
            bottom: (parseInt(d3.select('#invoicedhours').style('height'), 10)/10),
            left: (parseInt(d3.select('#invoicedhours').style('width'), 10)/20)
            },
        width = parseInt(d3.select('#invoicedhours').style('width'), 10) - margin.left - margin.right,
        height = parseInt(d3.select('#invoicedhours').style('height'), 10) - margin.top - margin.bottom;

    var div = d3.select("#invoicedhours").append("div").attr("class", "toolTip");

    var formatPercent = d3.format("");

    var x = d3.scale.ordinal()
            .rangeRoundBands([0, width], .2, 0.5);

    var y = d3.scale.linear()
            .range([height, 0]);

    var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");

    var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left")
            .tickFormat(formatPercent);

    var svg = d3.select("#invoicedhours").append("svg")
            .attr("width", width + margin.left + margin.right)
            .attr("height", height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .call(xAxis);

    var datasetTotal = [
        {label:"Q", value:0},
        {label:"Q -1", value:0},
        {label:"Q -2", value:0},
        {label:"Q -3", value:0},
        {label:"Q -4", value:0},
        {label:"Q -5", value:0}
    ];

    change(datasetTotal);

    function change(dataset) {

        x.domain(dataset.map(function(d) { return d.label; }));
        y.domain([0, d3.max(dataset, function(d) { return d.value; })]);

        svg.append("g")
                .attr("class", "x axis")
                .attr("transform", "translate(0," + height + ")")
                .call(xAxis);

        svg.select(".y.axis").remove();
        svg.select(".x.axis").remove();

        svg.append("g")
                .attr("class", "y axis")
                .call(yAxis)
                .append("text")
                .attr("transform", "rotate(-90)")
                .attr("y", 6)
                .attr("dy", ".71em")
                .style("text-anchor", "end")
                .text("Hours Billed");

        var bar = svg.selectAll(".bar")
                .data(dataset, function(d) { return d.label; });
        // new data:
        bar.enter().append("rect")
                .attr("class", "bar")
                .attr("x", function(d) { return x(d.label); })
                .attr("y", function(d) { return y(d.value); })
                .attr("height", function(d) { return height - y(d.value); })
                .attr("width", x.rangeBand());

        bar
                .on("mousemove", function(d){
                    div.style("left", d3.event.pageX+10+"px");
                    div.style("top", d3.event.pageY-25+"px");
                    div.style("display", "inline-block");
                    div.html((d.label)+"<br>"+(d.value)+"%");
                });
        bar
                .on("mouseout", function(d){
                    div.style("display", "none");
                });

        // removed data:
        bar.exit().remove();
        // updated data:
        bar
                .transition()
                .duration(750)
                .attr("y", function(d) { return y(d.value); })
                .attr("height", function(d) { return height - y(d.value); });
    };


    // reBind();

    // Timer action
    // var i=0;
    // setTimeout(function(){present(mymap, i, point_markers, jList, reBind)}, 10000)
};

function present(mymap, i, point_markers, jList, reBind) {
    //Presentation function.
    if (i >= point_markers.length) {
        // i=0;
        location.reload();
    }
    console.log("Map reset to : " + i)
    var point = [jList[i]["Latitude"], jList[i]["Longitude"]];
    var point_marker = point_markers[i];
    mymap.setView(point, 6);
    reBind();
    point_marker.openPopup();
    i++;
    // present(i,point_markers,jList)
    setTimeout(function(){present(mymap, i,point_markers,jList,reBind)},15000);
};
