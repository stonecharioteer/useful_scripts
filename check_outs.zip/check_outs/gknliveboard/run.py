#!/opt/anaconda3/bin python

"""
Flask Application to serve the Tolkien map.
===
Created by Vinay Keerthi (yy54426)

"""

import os

import json

from flask import (Flask, request, url_for,
                render_template, jsonify,
                Response)
import pandas as pd

app = Flask(__name__)

@app.route("/")
def present():
    """Home page. Reveal Presentation."""
    return render_template("present.html")

@app.route("/timeline")
def serve_timeline():
    return render_template("timeline.html")

@app.route("/timeline_data")
def serve_timeline_data():
    inp_file = os.path.join("data","timeline.xlsx")
    timeline_df = pd.read_excel(inp_file, sheetname="Sheet1")
    timeline_json = {
                        "title": {},
                        "events": []
                    }
    for ix, row in timeline_df.iterrows():
        row_json = {
                "text": {
                        "headline": "",
                        "text": ""
                        },
                "media": {
                        "url": "",
                        "caption": ""
                        },
                "start_date": {
                        "year": "",
                        "month": "",
                        "day": ""
                        },
                "end_date": {
                        "year": "",
                        "month": "",
                        "day": ""
                        }
                }
        if row["text-headline"] != "":
            row_json["text"]["headline"] = row["text-headline"]

        if row["text-text"] != "":
            row_json["text"]["text"] = row["text-text"]

        if row["media-url"] != "":
            if not (row["media-url"].startswith("http") or row["media-url"].startswith("www")):
                row_json["media"]["url"] = url_for("static", filename="images/"+row["media-url"])
            else:
                row_json["media"]["url"] = row["media-url"]

        if row["media-caption"] != "":
            row_json["media"]["caption"] = row["media-caption"]

        if not(pd.isnull(row["start-year"])):
            row_json["start_date"]["year"] = row["start-year"]

        if not(pd.isnull(row["start-month"])):
            row_json["start_date"]["month"] = row["start-month"]

        if not(pd.isnull(row["start-day"])):
            row_json["start_date"]["day"] = row["start-day"]

        if not(pd.isnull(row["start-year"])):
            row_json["display_date"] = str(row["start-year"])

        if not(pd.isnull(row["end-year"])):
            row_json["end_date"]["year"] = row["end-year"]

        if not(pd.isnull(row["end-month"])):
            row_json["end_date"]["month"] = row["end-month"]

        if not(pd.isnull(row["end-day"])):
            row_json["end_date"]["day"] = row["end-day"]

        if row["type"] == "title":
            timeline_json["title"] = row_json
        else:
            timeline_json["events"].append(row_json)
    print(timeline_df)
    return jsonify(timeline_json)

# Methods to create the globe with reveal.js.
@app.route("/globe")
def serve_globe():
    return render_template("globe.html")

@app.route("/globe_map_data")
def serve_globe_map_data():
    """Function to return map data for the globe.
    """
    excel_path = os.path.join("data", "map list.xlsx")
    map_df = pd.read_excel(excel_path, sheetname="data")
    df_countries = pd.read_excel(
            excel_path,
            sheetname="countries_list")
    condition_1 = pd.notnull(map_df["Latitude"])
    condition_2 = pd.notnull(map_df["Country"])
    condition = [one and two for one,two in zip(condition_1, condition_2)]
    map_df = map_df.loc[condition].copy()
    map_df["ID"] = None
    map_df["sites"] = "-"
    for ix, row in map_df.iterrows():
        country = row["Country"]
        relevant_row = df_countries.loc[df_countries["name"] == country]
        country_id = int(relevant_row["id"])
        map_df.set_value(ix,"ID", country_id)
        sites = list(map_df.loc[map_df["Country"] == country]["Site"])
        sites = "<br />".join(sites)
        map_df.set_value(ix,"sites", sites)
    map_df.columns = [x.lower().replace(" ","_") for x in map_df.columns]
    return jsonify(map_df.to_json(orient="records"))

@app.route("/globe_site_list", methods=["GET"])
def get_site_list():
    country = request.args.get("country_name")
    if country is not None:
        excel_path = os.path.join("data", "map list.xlsx")
        map_df = pd.read_excel(excel_path, sheetname="data")
        condition_one = map_df.Country == country
        condition_two = map_df.Classification == "Site"
        condition = [(one and two) for one,two in zip(condition_one, condition_two)]
        sites_filtered_df = map_df.loc[condition]
        site_names = sorted(list(sites_filtered_df.Site))
        nega_condition = [(not(one) and two) for one,two in zip(condition_one, condition_two)]
        other_sites_filtered_df = map_df.loc[nega_condition]
        other_sites = sorted(list(other_sites_filtered_df.Site))
        return jsonify({"sites": site_names, "others": other_sites})
    else:
        return ""

@app.route("/globe_geojson")
def serve_globe_json():
    with open("data/globe/world-110m.json") as fp:
        json_contents = json.load(fp)
    return jsonify(json_contents)

# Leaflet page
@app.route("/map")
def serve_index():
    return render_template("map.html")

# Leaflet page data.
@app.route("/map_list_data")
def serve_map_list_data():
    """Used to fetch the JSON data"""
    data_file = os.path.join("data","map list.xlsx")
    map_data_df = pd.read_excel(data_file)
    condition_one = pd.notnull(
            map_data_df["Latitude"])
    condition_two = pd.notnull(
            map_data_df["Longitude"])
    condition = [one and two for one,two in zip(condition_one, condition_two)]
    filtered_df = map_data_df.loc[condition].copy()
    filtered_df.sort_values(
            by=["Latitude","Longitude"],
            inplace=True)
    return jsonify(
            filtered_df.to_json(orient='records'))

@app.route("/map_report")
def serve_map_report_html():
    """Serves the Report portion of the leaflet page.
    """
    site = request.args.get("site")
    country = request.args.get("country")
    renderable_html = """
    <table>
        <tr>
            <th>Site</th>
            <th>Country</th>
        </tr>
        <tr>
            <td>{}</td>
            <td>{}</td>
        </tr>
    </table>""".format(site, country)
    return renderable_html

# Export control information for the leaflet page.
@app.route("/export_control_data")
def serve_export_control_data():
    # Find a way to get this data
    # from Sharepoint through Linux
    # instead of a local file.
    # Or should this be a Windows Flask server?
    eco_file = os.path.join(
            "data",
            "Startsheet_Matrix_GAI.xlsx")
    xl = pd.ExcelFile(eco_file)
    sh =  xl.book.sheet_by_index(0)
    nrows = sh.nrows
    ncols= sh.ncols

    data = []
    for rown in range(nrows):
        row = []
        for coln in range(ncols):
            cell = sh.cell(rown, coln)
            # val = cell.value
            row.append(cell.value)
        valid = False
        for item in row:
            if item!= "":
                valid = True
        if valid:
            data.append(row)
    header_cols = [
            'Partner',
            'Country',
            'Site',
            'End Use']
    business = "-"
    new_data = []
    for row in data:
        product = "-"
        partner = "-"
        country = "-"
        site = "-"
        end_use = '-'
        ex_class_us = "-"
        ex_class_eu = "-"
        startsheet_av = "-"
        is_header = True
        for col in header_cols:
            if col not in row:
                is_header=False
                break
        if is_header:
            business = row[0]
        else:
            cleaned_row = [x for x in row if x!=""]
            if len(cleaned_row)>2:
                product = row[0]
                partner = row[1]
                country = row[2]

                site = row[3]
                end_use = row[4]
                ex_class_us = row[5]
                ex_class_eu = row[6]
                # col7 is some sweden specific data.
                startsheet_av = row[8]
                new_row = [
                        business,
                        product,
                        partner,
                        country,
                        site,
                        end_use,
                        ex_class_us,
                        ex_class_eu,
                        startsheet_av
                        ]
                new_data.append(new_row)
    headers = [
            "business",
            "product",
            "partner",
            "country",
            "site",
            "end_use",
            "ex_class_us",
            "ex_class_eu",
            "startsheet_av"
            ]
    eco_df = pd.DataFrame(
            new_data, columns=headers)
    return jsonify(
            eco_df.to_json(orient="records"))

def main():
    """Function to run the application."""
    app.run(debug=True, port=8080,
        threaded=True, host="0.0.0.0")


if __name__ == "__main__":
    main()

