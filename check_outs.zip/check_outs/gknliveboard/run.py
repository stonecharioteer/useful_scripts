#!/opt/anaconda3/bin python

"""
Flask Application to serve the Tolkien map.
===
Created by Vinay Keerthi (yy54426)

"""

import os

import json

from flask import (Flask, request,
                render_template, jsonify,
                Response)
import pandas as pd

app = Flask(__name__)

@app.route("/map_report")
def serve_map_report_html():
    """
    """
    site = request.args.get("site")
    country = request.args.get("country")
    renderable_html = """
    <table>
        <tr>
            <th>Site</th>
            <th>Country</th>
        </tr>
        <tr>
            <td>{}</td>
            <td>{}</td>
        </tr>
    </table>""".format(site, country)
    return renderable_html

@app.route("/")
def present():
    """Default Page."""
    return render_template("present.html")

@app.route("/data/globe/map_data")
def serve_globe_map_data():
    """Function to return map data for the globe."""
    excel_path = os.path.join("data", "map list.xlsx")
    map_df = pd.read_excel(excel_path, sheetname="data")
    df_countries = pd.read_excel(
            excel_path,
            sheetname="countries_list")

    condition_1 = pd.notnull(map_df["Latitude"])
    condition_2 = pd.notnull(map_df["Country"])
    condition = [one and two for one,two in zip(condition_1, condition_2)]
    map_df = map_df.loc[condition].copy()
    map_df["ID"] = None
    map_df["sites"] = "-"
    for ix, row in map_df.iterrows():
        country = row["Country"]
        relevant_row = df_countries.loc[df_countries["name"] == country]
        country_id = int(relevant_row["id"])
        map_df.set_value(ix,"ID", country_id)
        sites = list(map_df.loc[map_df["Country"] == country]["Site"])
        sites = "<br />".join(sites)
        map_df.set_value(ix,"sites", sites)
    map_df.columns = [x.lower().replace(" ","_") for x in map_df.columns]
    return jsonify(map_df.to_json(orient="records"))

#Methods to create the globe with reveal.js.
@app.route("/globe_2")
def serve_globe_2():
    return render_template("globe_2.html")

@app.route("/data/globe/world-110m.json")
def serve_globe_json():
    with open("data/globe/world-110m.json") as fp:
        json_contents = json.load(fp)
    return jsonify(json_contents)

@app.route("/data/globe/world-country-names.tsv")
def serve_globe_tsv():
    with open("data/globe/world-country-names_orig.tsv") as fp:
        tsv = fp.read()
    return Response(
        tsv,
        mimetype="text/tsv",
        headers={
            "Content-disposition":
            "attachment; filename=world-country-names.tsv"})

# Methods to create the globe with reveal.js.
@app.route("/globe")
def serve_globe():
    return render_template("globe_2.html")

# Methods to create the d3 test.
@app.route("/d3_data")
def serve_d3_data():
    # with open("outputs/Adjacency.csv") as fp:
    #     csv = fp.read()
    with open("data/d3_data.csv") as fp:
        csv = fp.read()
    # csv = '1,2,3\n4,5,6\n'
    return Response(
        csv,
        mimetype="text/csv",
        headers={"Content-disposition":
                 "attachment; filename=d3_data.csv"})

@app.route("/d3")
@app.route("/test_d3")
@app.route("/d3_test")
def test_d3():
    return render_template("d3_test.html")

@app.route("/map")
def serve_index():
    return render_template("map.html")

@app.route("/map_list_data")
def serve_map_list_data():
    """Used to fetch the JSON data"""
    data_file = os.path.join("data","map list.xlsx")
    map_data_df = pd.read_excel(data_file)
    condition_one = pd.notnull(
            map_data_df["Latitude"])
    condition_two = pd.notnull(
            map_data_df["Longitude"])
    condition = [one and two for one,two in zip(condition_one, condition_two)]
    filtered_df = map_data_df.loc[condition].copy()
    filtered_df.sort_values(
            by=["Latitude","Longitude"],
            inplace=True)
    return jsonify(
            filtered_df.to_json(orient='records'))

@app.route("/export_control_data")
def serve_export_control_data():
    # Find a way to get this data
    # from Sharepoint through Linux
    # instead of a local file.
    # Or should this be a Windows Flask server?
    eco_file = os.path.join(
            "data",
            "Startsheet_Matrix_GAI.xlsx")
    xl = pd.ExcelFile(eco_file)
    sh =  xl.book.sheet_by_index(0)
    nrows = sh.nrows
    ncols= sh.ncols

    data = []
    for rown in range(nrows):
        row = []
        for coln in range(ncols):
            cell = sh.cell(rown, coln)
            # val = cell.value
            row.append(cell.value)
        valid = False
        for item in row:
            if item!= "":
                valid = True
        if valid:
            data.append(row)
    header_cols = [
            'Partner',
            'Country',
            'Site',
            'End Use']
    business = "-"
    new_data = []
    for row in data:
        product = "-"
        partner = "-"
        country = "-"
        site = "-"
        end_use = '-'
        ex_class_us = "-"
        ex_class_eu = "-"
        startsheet_av = "-"
        is_header = True
        for col in header_cols:
            if col not in row:
                is_header=False
                break
        if is_header:
            business = row[0]
        else:
            cleaned_row = [x for x in row if x!=""]
            if len(cleaned_row)>2:
                product = row[0]
                partner = row[1]
                country = row[2]

                site = row[3]
                end_use = row[4]
                ex_class_us = row[5]
                ex_class_eu = row[6]
                # col7 is some sweden specific data.
                startsheet_av = row[8]
                new_row = [
                        business,
                        product,
                        partner,
                        country,
                        site,
                        end_use,
                        ex_class_us,
                        ex_class_eu,
                        startsheet_av
                        ]
                new_data.append(new_row)
    headers = [
            "business",
            "product",
            "partner",
            "country",
            "site",
            "end_use",
            "ex_class_us",
            "ex_class_eu",
            "startsheet_av"
            ]
    eco_df = pd.DataFrame(
            new_data, columns=headers)
    return jsonify(
            eco_df.to_json(orient="records"))

def main():
    """Function to run the application."""
    app.run(debug=True, port=8080,
        threaded=True, host="0.0.0.0")


if __name__ == "__main__":
    main()

