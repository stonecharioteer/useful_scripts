# GKN Aerospace India Liveboard

---

This code creates the API and the HTML for the GAI liveboard.

Created by: yy54426 - Vinay Keerthi Krishnapuram Tirumala

