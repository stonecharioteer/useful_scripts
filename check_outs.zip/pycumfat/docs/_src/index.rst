.. PROJECT_NAME documentation master file, created by
   sphinx-quickstart on Tue Oct 17 13:07:21 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pycumfat Documentation
======================

This module can be used to parse ``Cumfat`` material, method, run and output files. It was developed by Vinay Keerthi and this current 
version of the code was refactored from code he'd developed for the RM12 LTS project.


Introduction
============

``Cumfat`` is an inhouse tool to conduct lifing tests for stress files extracted from Ansys in the form of the cns files. To understand
more about cns files, go through the pycns documentation. To understand cumfat better, the author recommends reading Eva Wetterholm's excellent
documentation that is stored in SAP.

This module allows users to parse the d20, d21, dat and .life files that are used constantly when running Cumfat.


Coverage Details
================

This module, as it currently stands, supports parsing the files for Cumfat v5.12 and writing files in Cumfat v7.1's format.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents:
   
   Export Control Information <exportcontrol>
   Tutorial <tutorials>
   Examples <examples>
   API Documentation <api>
   
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
