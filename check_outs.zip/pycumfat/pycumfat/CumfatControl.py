#!/opt/anaconda3/bin/python3
# -*- coding: utf-8 -*-
"""
CumfatControl class.
This module contains the class definition for the CumfatControl class.
It offers parsing methods, creation methods and it can retrieve associated 
attributes as well.

From the Cumfat manual:
 * The cumfat control file states the type of run that should be performed.
 * It states the job name and search path to the load sequence file, method
 selection file and material data file.
 * It usually has an FNAMES.DAT filename, but that isn't necessary.
 * Type of run is either NORMAL or COM_MIX.
 * A NORMAL run is the simplest way to perform a Cumfat run where only one
 load if provided to the program.
 * For the COM_MIX run a mix of load sequence files can be provided.
"""

class CumfatControl:
    def __init__(self, file_path=None, version=None):
        """Initializer method."""
    def parse_from_file(self, file_path=None, version=None):
        """"parser method."""
    def save_to_file(self, file_path=None, version=None):
        """File dumping method."""
    


if __name__ == "__main__":
    pass
