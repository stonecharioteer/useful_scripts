#!/opt/anaconda3/bin/python3
# -*- coding: utf-8 -*-

import sys
import os
import glob
import pandas as pd
from gknexceptions import CumfatLimitation
from gknexceptions import InsufficientData
from gknexceptions import InvalidInput
from gknexceptions import FeatureNotImplementedError
from gknexceptions import SaveNotAllowedError
from gknexceptions import CumfatLimitation

from gknalgorithms.file_opener_methods import get_file_as_list_using_any_encoding

cumfat_versions = ["5.12", "7.1"]

class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self


def get_method_interpretation(version, parameter, value):
    """Return Natural Language version of the method parameter values."""
    if version == "5.12":
        if parameter in ["COMMENT_1", "COMMENT_2"]:
            return "{}: {}".format(parameter.title().replace("_"," "), value)
        elif parameter == "NLOTY":
            prefix = "Format of Stress Input"
            meanings_dict = {
                1: "Loading_history     (old format, normally not used)",
                2: "Spannings_sekvens   (old format, normally not used)",
                3: "Grundlastfall       (not implemented)",
                4: "New_Stress_Sequence (linear elastic FE analysis)",
                5: "Elastic_Plastic_FE  (elastic-plastic FE analysis)"
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "SPEKT":
            # Only value for NLOTY = 4,5
            if value == 0:
                return "Disengage a model for sequence effects"
            else:
                return "Activate a model for sequence effects"
        elif parameter == "NAR":
            return "{} areas with different material data.".format(value)
        elif parameter == "NCONC":
            return "{} areas of the FE-model, need to be provided with stress concentration factors.".format(value)
        elif parameter == "NHYP":
            prefix = "Hypothesis for Multiaxial Stress Measure to be Used"
            meanings_dict = {
                1 : "Maximum Principal Stress",
                2 : "Maximum Shear Stress",
                3 : "Maximum Principal Strain",
                4 : "Octahedral Shear Stress",
                5 : "Plastic Principal Strain" # Only for (NLOTY=5)
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "KORR":
            prefix = "Hypothesis for Elastic-Plastic Correction to be Used"
            meanings_dict = {
                0 : "No correction",
                1 : "The Linear Rule",
                2 : "The Neuber Rule",
                3 : "Correction performed by FE-code" # Only for (NLOTY=5)
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "NCUR":
            prefix = "Fatigue Data Is Provided via"
            meanings_dict = {
                #  Analysis without creep consideration
                2 : "Table of strain-range versus life (Creep is not Considered)",
                3 : "Data are defined by Basquin-Coffin-Manson parameters (Creep is not Considered)",
                4 : "Table of Smith-Watson-Topper-value versus life (Creep is not Considered)",
                5 : "Table of pseudo-stress-amplitude versus life (Creep is not Considered)",
                # Analysis with creep consideration
                6 : "Table of strain-range versus life, followed by table of PLM (Larson-Miller parameter, here as function of stress in a table) (Creep is Considered)",
                7 : "Table of strain-range versus life, followed by Coffin frequency-parameter (Creep is Considered)",
                8 : "Data defined by Basq.-Coff.-Mans. parameters, followed by table of PLM (Creep is Considered)",
                9 : "Data defined by Basq.-Coff.-Mans. parameters, followed by Coff. freq.-param (Creep is Considered)",
                10 : "Table of Smith-Watson-Topper-value, followed by table of PLM (Creep is Considered)",
                11 : "Table of Smith-Watson-Topper-value, followed by table Coff. freq.-parameter (Creep is Considered)",
                12 : "Table of pseudo-stress-amplitude versus life, followed by table of PLM (Creep is Considered)",
                13 : "Table of pseudo-stress-amplitude versus life, followed by Coff. freq.-param (Creep is Considered)"
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "NMEAN":
            prefix = "Hypotheis for Mean Stress Influence"
            meanings_dict = {
                1 : "Morrow",
                2 : "Smith-Watson-Topper",
                3 : "Walker"
                }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "LIMLIFE":
            return "Limiting Life: {}".format(value)
        elif parameter == "NTOP":
            return "NTOP Nodes: {}".format(value)
        elif parameter == "NK":
            return "No. of Nodes For Which Extra Check Data is Written: {}".format(value)
        elif parameter == "NON":
            return "NON Nodes List: {}".format(value)
        elif parameter == "TEST":
            if value == -999:
                return "Create Extra Output .cyc File."
            elif value is None:
                return "No Test Run Specified"
            else:
                raise ValueError("TESTRUN cannot be {}".format(value))
        else:
            raise ValueError("{} is not a valid key!".format(parameter))
    elif version == "7.1":
        if parameter == "NLOTY":
            prefix = "Load Sequence File Format"
            meanings_dict = {
                1: "linear-elastic load input (Linear_FE)".title(),
                2: "elastic-plastic corrected load input (Elastic_Plastic_FE)".title()
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))
        elif parameter == "OLCYC":
            meanings_dict = {
                1: "Find largest cycle by iteration, a combination of temperature and load level determine the largest cycle".title(),
                2: "find largest cycle in the RFC subroutine, only load level is used to determine the largest cycle (default)".title()
            }
            return meanings_dict.get(value,"Not Set")
        elif parameter == "OSKT":
            if value == 0:
                return "No Stress Concentration"
            elif value == 1:
                return "Stress Concentration Factor should be considered"
                # NB! Stress concentration factors can only be provided if NLOTY = 1 (linear elastic FE analysis)
            else:
                return "Stress Concentration Factor: {}.".format(value)
        elif parameter == "KT":
            return "Stress Concentration Tensor: {}".format(value)
        elif parameter == "NHYP":
            prefix = "Hypothesis for Effective Stress-Strain Measure to be Used for the Analysis"
            meanings_dict = {
               1 : "Maximum Principal Stress",
               2 : "Maximum Principal Strain",
               3 : "von Mises Stress with sign", #Cannot be combined with NLOTY == 2
               4 : "Normal Stress acting on a specific plane"
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))            
        elif parameter == "OHYP":
            # Needed if NHYP in [1, 2, 4]
            if value == 1:
                return "Only calculate damage in the direction of the largest principal stress/strain (default)"
            elif value == 2:
                return "Calculate damage in the three principal stress/strain directions of the largest load step"
            elif value == 3:
                return "Iterate through space to find the most critical plane."
                #    For this option the parameter IHYP needs to be specified. IHYP
                #    indicates how many steps should be made by the program to
                #    determine next plane for damage calculation. For instance, if
                #    IHYP is set to 6, first the three principal stress/strain
                #    directions will be used. Then the space will be divided into
                #    6*6 different planes. I.e. 3+6*6 = 39 iterations will be made.
                #    On the same row write NHYP OHYP IHYP separated by space."
            elif value == 4:
                return "calculate damage in predefined direction."
                #    If this option is chosen,
                #    write desired direction as the normal unit vector (NUX,NUY,NUZ)
                #    perpendicular to the chosen plane. Write the parameters
                #    NUX NUY NUZ separated by space directly after NHYP and OHYP.
                #    I.e. write NHYP OHYP NUX NUY NUZ"
            else:
                return "Damage Calculation Directions (OHYP) not Specified"
        elif parameter == "IHYP":
            return "{} steps should be made by the program to detect the next plane for damage calculation.".format(value)
        elif parameter == "DIRECTIONVECTOR":
            return "Direction Vector for Damage Calculation: {}".format(value)
        elif parameter == "KORR":
            prefix = "Hypothesis For Elastic-Plastic Correction to be Used"
            meanings_dict = {
                0 : "No correction",
                1 : "Linear Rule, displacement controlled (Strain controlled loading)",
                2 : "Neuber Rule (Notches)",
                3 : "Linear Rule, load controlled (Stress controlled loading)",
                4 : "Correction performed by FE-code"
            }
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))            
        elif parameter == "OKORR":
            if value == 1:
                return "Elastic-Plastic Correction should be performed before RFC."
            elif value == 2:
                return "Elastic-Plastic Correction should be performed after RFC. (Default)"
                # NB! OKORR will be set to OKORR = 2 (after RFC) if
                #     KORR = 0 (No correction) automatically by the program.
                # NB! OKORR will be set to OKORR = 1 (before RFC) if
                #     NLOTY = 2 (elastic plastic FE) automatically by the program.
                # NB! In Cumfat7.1, the combination NLOTY = 1 (linear elastic FE) and
                #     OKORR = 1 (correction before RFC) should only be performed in
                #     method development work or in consultation with system owner.
            else:
                return "Elastic-Plastic Correction Not Set"
        elif parameter == "NMEAN":
            prefix = "Hypothesis for Mean Stress Influence to be Used"
            meanings_dict = {
                1 : "Morrow_Hyp   Morrow Hypothesis",
                2 : "SWT_Hyp      Smith-Watson-Topper Hypothesis",
                3 : "WES_Hyp      Walker Effective Stress Hypothesis",
            }                           
            #  NB! Following NMEAN can only be combined with following OLCF
            #      (format of material data), all other alternatives are not allowed.
            #  NMEAN = 1,2 <-> OLCF = 1 LCF_Table   (Table of strain-range versus life)
            #  NMEAN = 1   <-> OLCF = 2 BCM_Coeff   (Data are defined by
            #                                        Basquin-Coffin-Manson parameters)
            #  NMEAN = 2   <-> OLCF = 3 SWT_Table   (Table of Smith-Watson-Topper-value
            #                                        versus life)
            #  NMEAN = 3   <-> OLCF = 4,5,6 WES_mR* (Data are defined by Walker
            #                                        Effective Stress parameters)
            return "{}: {}".format(prefix, meanings_dict.get(value,"Not Set"))            
        elif parameter == "LIMLIFE":
            return "Limiting Life: {}".format(value)
        elif parameter == "NTOP":
            return "NTOP Nodes: {}".format(value)
        elif parameter == "NK":
            return "No. of Nodes For Which Extra Check Data is Written: {}".format(value)
        elif parameter == "NON":
            return "NON Nodes List: {}".format(value)
        elif parameter == "TEST":
            if value == -999:
                return "Create Extra Output .cyc File."
            elif value is None:
                return "No Test Run Specified"
            else:
                raise ValueError("TESTRUN cannot be {}".format(value))
        else:
            raise ValueError("{} is not a valid key!".format(parameter))
    return "{}: {}: {}".format(version, parameter, value)


def get_method_parameters(version):
    if version == "5.12":
        return ["COMMENT_1", "COMMENT_2","NLOTY", "SPEKT","NAR", "NCONC",
                "NHYP","KORR", "NCUR", "NMEAN","LIMLIFE", "NTOP", "NK",
                "NON", "TEST"]
    elif version == "7.1":
        return ["NLOTY","OLCYC","OSKT","KT","NHYP","OHYP","IHYP","DIRECTIONVECTOR",
                "KORR","OKORR","NMEAN","LIMLIFE","NTOP","NK","NON","TEST"]
    else:
        raise ValueError("{} is not a recognized Cumfat Version.".format(version))


class MethodSelectionParameters:
    def __init__(self, version=7.1):
        self._version = version
        self._parameters = {
                        "5.12" : AttrDict((key,None) for key in get_method_parameters("5.12")),
                        "7.1" : AttrDict((key,None) for key in get_method_parameters("7.1"))
        }

    def __repr__(self):
        representation =  "Cumfat MethodSelectionParameters\n"
        for v in cumfat_versions:
            parameters = self._parameters[v].keys()
            
            params_string = "****\nVersion: {}\nParameters:\n".format(v)
            params = [get_method_interpretation(v, p, self._parameters[v][p]) for p in parameters]
            params_string += "\n".join(str(x) for x in params)
            representation += params_string
            representation += "\n"
        return representation

    @property
    def version(self):
        return self._version
    
    @version.setter
    def version(self, version):
        if version in ["5.12", "7.1"]:
            self._version = version
        else:
            raise ValueError("Cumfat Version {} is not recognized.".format(version))
    
    @property
    def parameters(self):
        return self._parameters[self.version]
    
    @parameters.setter
    def parameters(self, parameters):
        required_keys = sorted(get_method_parameters(self.version))
        if sorted(parameters.keys()) == required_keys:
            self._parameters[self.version] = AttrDict(parameters)
        else:
            missing_keys = [x for x in parameters.keys() if x not in required_keys]
            error_message = ("Cumfat Method Selection parameters for v{}"
                            " require ALL of the following keys:\n{}.\n"
                            "{} were not supplied.").format(self.version, parameters.keys(), missing_keys)
            raise KeyError(error_message)

            
class CumfatMethodSelection:
    """Cumfat Method Selection File (d21) Parser/Definition Class

    This class defines the Cumfat Method Selection file structure. It currently
    supports the specifications as detailed in Cumfat 5.12 and 7.1.


    Examples:

        This is the standard way of using this class

        >>> from pycumfat import CumfatMethodSelection
        >>> d20 = CumfatMethodSelection("/path/to/sample.d20", version="5.12")

        In this way of using this class, a dictionary of corresponding values can 
        be passed to construct the required d20 object.

        >>> d21 = CumfatMaterialData(method_selection=dict_method_selection)
        >>> d21.save_to_file("/path/to/output.d20", version="5.12")

    .. note::

        From the Cumfat Manual

            * In the method selection file, the selection of available hypotheses are performed.
            * In general

                * Comment blocks are written inside instruction blocks.
                * An instruction block is enclosed by a row of at least 10 asterixes or plus signs.
                * An instruction block can be as long as it needs to be.
                * The used hypotheses are controlled via the parameters that occur between instruction blocks.


        This is the format of the d20 file according to Cumfat 5.12

        .. code-block:: none
        
            ***********************Instruction block*******************************
             This is an instruction block. An instruction block starts with a row,
             which in at least in its 10 first positions contains asterisks. It also
             ends in the same way. An instruction block can have any number of rows.
             Data used by CUMFAT must be written in between instruction blocks. The
             purpose of the instruction block is to define what data to be written,
             and thus facilitate for the user. Blank rows are allowed in front of an
             instruction block. Now actual instructions are given:

             Write 2 rows with arbitrary information texts to appear in results files
            ******************End of instruction block******************************
            {COMMENT_1}
            {COMMENT_2}
            ************************************************************************
             Write the parameters NLOTY and SPEKT in that order separated
             by space.

             NLOTY indicates the format of the stress input:
             1 = Loading_history     (old format, normally not used)
             2 = Spannings_sekvens   (old format, normally not used)
             3 = Grundlastfall       (not implemented)
             4 = New_Stress_Sequence (linear elastic FE analysis)
             5 = Elastic_Plastic_FE  (elastic-plastic FE analysis)

             SPEKT activates or disengage the model for sequence effects, only
             available for NLOTY=4 and NLOTY=5
             0 = Disengage a model for sequence effects
             1 = Activate a model for sequence effects
            ************************************************************************
             {NLOTY} {SPEKT}
            ************************************************************************
             Write the parameter NAR, telling how many aeras with different material
             data there are in the model (maximum 10 is allowed)
            ************************************************************************
             {NAR}
            ************************************************************************
             Write NCONC, telling how many areas of the FE-model, which need to be
             provided with stress concentration factors (normally NCONC=0)
            ************************************************************************
             {NCONC}
            ************************************************************************
             Write the parameters NHYP

             NHYP indicates which of the hypotheses for multiaxial stress measure
             to be used in this analysis:
             1 = Maximum Principal Stress
             2 = Maximum Shear Stress
             3 = Maximum Principal Strain
             4 = Octahedral Shear Stress
             5 = Plastic Principal Strain (NLOTY=5)
            ************************************************************************
             {NHYP}
            ************************************************************************
             Write KORR, telling which of the hypotheses for elastic-plastic
             correction to be used:
             0 = No correction
             1 = The Linear Rule
             2 = The Neuber Rule
             3 = Correction performed by FE-code (NLOTY=5)
            ************************************************************************
             {KORR}
            ************************************************************************
             Write the parameter NCUR

             NCUR tells how the fatigue data are provided:
              Analysis without creep consideration:
               2 = Table of strain-range versus life
               3 = Data are defined by Basquin-Coffin-Manson parameters
               4 = Table of Smith-Watson-Topper-value versus life
               5 = Table of pseudo-stress-amplitude versus life
              Analysis with creep consideration:
             (PLM is the Larson-Miller parameter, here as function of stress in a table)
               6 = Table of strain-range versus life, followed by table of PLM
               7 = Table of strain-range versus life, followed by Coffin frequency-parameter
               8 = Data defined by Basq.-Coff.-Mans. parameters, followed by table of PLM
               9 = Data defined by Basq.-Coff.-Mans. parameters, followed by Coff. freq.-param
               10 = Table of Smith-Watson-Topper-value, followed by table of PLM
               11 = Table of Smith-Watson-Topper-value, followed by table Coff. freq.-parameter
               12 = Table of pseudo-stress-amplitude versus life, followed by table of PLM
               13 = Table of pseudo-stress-amplitude versus life, followed by Coff. freq.-param
            ************************************************************************
             {NCUR}
            ************************************************************************
             Write NMEAN, telling which of the hypotheses for mean stress influence
             to be used in this analysis:
             1 = Morrow
             2 = Smith-Watson-Topper
             3 = Walker
            ************************************************************************
             {NMEAN}
            ************************************************************************
             Write LIMLIFE, telling that lives longer than LIMLIFE are given the
             value LIMLIFE. This value is used only for plot data.
            ************************************************************************
             {LIMLIFE}
            ************************************************************************
             Write NTOP, telling that the node numbers of NTOP nodes with lowest
             life are sorted and written to the file job_name.inf
            ************************************************************************
              {NTOP}
            ************************************************************************
             Write NON and define the NON nodes for which extra check data are
             written to the file job_name.cyc (maximum value of NON is 10000)
            ************************************************************************
            {NK} {NON}
    

        This is the format of the file in Cumfat 7.1.0

        .. code-block:: none
            
            ***********************Instruction block*******************************
             This is an instruction block. An instruction block starts with a row,
             which in at least in its first positions contains 10 asterisks or
             10 plus signs. It also ends in the same way.
             An instruction block can have any number of rows.
             Data used by CUMFAT must be written in between instruction blocks. The
             purpose of the instruction block is to define what data to be written,
             and thus facilitate for the user. Blank rows are allowed in front of an
             instruction block. Now actual instructions are given:

            ------------------------------------------------------------------------
             Write the parameters NLOTY and OLCYC on the same row separated by space

             - NLOTY indicates the format of the load sequence file:
               1 = linear-elastic load input (Linear_FE)
               2 = elastic-plastic corrected load input (Elastic_Plastic_FE)

             - OLCYC indicates if the Largest CYCle should be found by iteration
               or in the RFC subroutine
                1 = find largest cycle by iteration, a combination of temperature and
                    load level determine the largest cycle
                2 = find largest cycle in the RFC subroutine, only load level is used
                    to determine the largest cycle (default)
            ************************************************************************
            {NLOTY} {OLCYC}
            ************************************************************************
             Write the parameter OSKT KTXX KTYY KTZZ KTXY KTYZ KTXZ  on the same
             row separated by space.

             - OSKT indicate if stress concentration factor should be considered
               0 = No stress concentration
               1 = Stress concentration factor should be considered

             - KTXX KTYY KTZZ KTXY KTYZ KTXZ only needs to be specified if OSKT
               is set to 1 (Stress concentration factor should be considered).
               - KTXX corresponds to a factor that will be multiplied to the stress
                 component SXX in the load history file.
               - KTYY corresponds to a factor that will be multiplied to the stress
                 component SYY in the load history file.
               - And similar for remaining stress components.

             The stress concentration will be added directly after the load
             history has been read and before any manipulation of load data.
             I.e. SXX = KTXX*SXX, SYY = KTYY*SYY and etc.

             NB! Provided stress concentration factors is applied to all load steps.
             NB! Provided stress concentration factors is applied to all nodes.
             NB! Stress concentration factors can only be provided if NLOTY = 1
                 (linear elastic FE analysis)
            ************************************************************************
            {OSKT} {KT}
            ************************************************************************
             Write the parameters NHYP and OHYP on the same row separated by space.

             - NHYP indicates which of the hypotheses for effective
               stress/strain measure to be used in the analysis:
               1 = Maximum Principal Stress
               2 = Maximum Principal Strain
               3 = von Mises Stress with sign
               4 = Normal Stress acting on a specific plane

             NB! NLOTY = 2, (elastic plastic FE) cannot be combined with NHYP = 3
                 (von Mises Stress).

             - OHYP only needs to be specified if NHYP is equal to 1 (Maximum
               Principal Stress), 2 (Maximum Principal Strain) or equal to 4
               (Normal Stress)
               1 = Only calculate damage in the direction of the largest principal
                   stress/strain (default)
               2 = Calculate damage in the three principal stress/strain directions
                   of the largest load step
               3 = Iterate through space to find the most critical plane.
                   For this option the parameter IHYP needs to be specified. IHYP
                   indicates how many steps should be made by the program to
                   determine next plane for damage calculation. For instance, if
                   IHYP is set to 6, first the three principal stress/strain
                   directions will be used. Then the space will be divided into
                   6*6 different planes. I.e. 3+6*6 = 39 iterations will be made.
                   On the same row write NHYP OHYP IHYP separated by space.
               4 = calculate damage in predefined direction. If this option is chosen,
                   write desired direction as the normal unit vector (NUX,NUY,NUZ)
                   perpendicular to the chosen plane. Write the parameters
                   NUX NUY NUZ separated by space directly after NHYP and OHYP.
                   I.e. write NHYP OHYP NUX NUY NUZ
            ************************************************************************
            {NHYP} {OHYP} {IHYP} {DIRECTIONVECTOR}
            ************************************************************************
             Write the parameters KORR and OKORR on the same row separated by space

             - KORR indicates which of the hypotheses for elastic-plastic
               correction to be used:
               0 = No correction
               1 = Linear Rule, displacement controlled (Strain controlled loading)
               2 = Neuber Rule (Notches)
               3 = Linear Rule, load controlled (Stress controlled loading)
               4 = Correction performed by FE-code

             - OKORR indicated if elastic-plastic correction should be performed
               before or after RFC
               1 = Before RFC.
               2 = After RFC (default)

             NB! OKORR will be set to OKORR = 2 (after RFC) if
                 KORR = 0 (No correction) automatically by the program.
             NB! OKORR will be set to OKORR = 1 (before RFC) if
                 NLOTY = 2 (elastic plastic FE) automatically by the program.
             NB! In Cumfat7.1, the combination NLOTY = 1 (linear elastic FE) and
                 OKORR = 1 (correction before RFC) should only be performed in
                 method development work or in consultation with system owner.
            ************************************************************************
            {KORR} {OKORR}
            ************************************************************************
             Write the parameter NMEAN

             - NMEAN indicates which of the hypotheses for mean stress influence
               to be used in this analysis
               1 = Morrow_Hyp   Morrow Hypothesis
               2 = SWT_Hyp      Smith-Watson-Topper Hypothesis
               3 = WES_Hyp      Walker Effective Stress Hypothesis

             NB! Following NMEAN can only be combined with following OLCF
                 (format of material data), all other alternatives are not allowed.
             NMEAN = 1,2 <-> OLCF = 1 LCF_Table   (Table of strain-range versus life)
             NMEAN = 1   <-> OLCF = 2 BCM_Coeff   (Data are defined by
                                                   Basquin-Coffin-Manson parameters)
             NMEAN = 2   <-> OLCF = 3 SWT_Table   (Table of Smith-Watson-Topper-value
                                                   versus life)
             NMEAN = 3   <-> OLCF = 4,5,6 WES_mR* (Data are defined by Walker
                                                   Effective Stress parameters)
            ************************************************************************
            {NMEAN}
            ************************************************************************
             Write the parameter LIMLIFE.

              - LIMLIFE, calculated life greater than LIMLIFE is set to LIMLIFE.
                This value is only used in output files created for contour plotting
                data in ANSYS.
            ************************************************************************
             {LIMLIFE}
            ************************************************************************
             Write the parameter NTOP

             - NTOP is the number of nodes with lowest life that will be written
               on the file jobname.inf
            ************************************************************************
              {NTOP}
            ************************************************************************
             Write the parameters NK and NON in that order separated by space.

             - NK is the number of nodes for which extra check data are
               written to the file jobname.cyc (maximum value of NK is 10000, minimum
               value is 0).

             - NON is the node number for the NK nodes.

             If more information about the Cumfat run is desired, on the next row
             write -999, the TESTRUN parameter. A extra output file *.cyc 2 will be
             written with more detailed information about the analysis.
             Can be omitted if no extra output is desired.
            ************************************************************************
             {NK} {NON}
            {TEST}
    
    """
    def __init__(self, file_path=None, version=None, method_selection=None):
        """Initializer method."""
        if version is None:
            self._version = "7.1"
        else:
            self.set_version(version)
        self._parameters = MethodSelectionParameters(self.version)
        
        if file_path is not None:
            self.parse_from_file(file_path, self._version)
        
    def __str__(self):
        """Need to parse data and print it in a nice and readable format."""
        return self.__repr__()

    def __repr__(self):
        """Class representation."""
        representation = ("<<CumfatMethodSelection Object>>>\n"
                "<<Active Version: {}>>\n"
                "{}").format(self.version, self.parameters)
        return representation
    
    @property
    def version(self):
        """Cumfat Version."""
        return self._version
    
    @version.setter
    def version(self, value):
        if value in [5.12, 7.1]:
            self._version = value
            self.parameters.version = value
        else:
            raise ValueError("Cumfat Version {} is not a valid version.".format(value))
    
    @property
    def parameters(self):
        """The parameters for the current version."""
        return self._parameters
    
    @parameters.setter
    def parameters(self, params):
        if not isinstance(params, dict):
            raise TypeError("The parameters need to be a dictionary.")
        else:
            self._parameters = params

    def parse_from_file(self, file_path, version=None):
        """Parses file from the format specified by the version argument."""
        if version is None:
            self.set_default_version()
        else:
            self.set_version(version)
        if not(os.path.isfile(file_path)):
            raise FileNotFoundError
        else:
            self.file_path = file_path
            d20_lines = get_file_as_list_using_any_encoding(self.file_path)
            if self.version == 5.12:
                parameters_list = get_method_parameters(self.version)
                d20_data_dict = Parameters((x, None) for x in parameters_list)
                instruction_counter = 0
                line_counter = 0
                for line in d20_lines:
                    line_counter += 1
                    if "*"*10 in line:
                        instruction_counter+=1
                        if instruction_counter == 2:
                            d20_data_dict["COMMENT_1"] = d20_lines[line_counter]
                            d20_data_dict["COMMENT_2"] = d20_lines[line_counter+1]
                        elif instruction_counter == 4:
                            nloty_row = d20_lines[line_counter].split()
                            if len(nloty_row) in (1,2):
                                d20_data_dict["NLOTY"] = int(float(nloty_row[0]))
                            if len(nloty_row) == 2:
                                d20_data_dict["SPEKT"] = int(float(nloty_row[1]))
                        elif instruction_counter == 6:
                            d20_data_dict["NAR"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 8:
                            d20_data_dict["NCONC"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 10:
                            d20_data_dict["NHYP"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 12:
                            d20_data_dict["KORR"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 14:
                            d20_data_dict["NCUR"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 16:
                            d20_data_dict["NMEAN"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 18:
                            d20_data_dict["LIMLIFE"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 20:
                            d20_data_dict["NTOP"] = int(float(d20_lines[line_counter]))
                        elif instruction_counter == 22:
                            non_row = d20_lines[line_counter].split()
                            if len(non_row) >= 1:
                                d20_data_dict["NK"] = int(float(non_row[0]))
                            if len(non_row) > 1:
                                d20_data_dict["NON"] = " ".join(non_row[1:])
                            if len(d20_lines) >= line_counter+2:
                                test_row = d20_lines[line_counter+1]
                                if test_row == "-999":
                                    d20_data_dict["TEST"] = test_row
                self._parameters[self._version] = d20_data_dict
            else:
                raise FeatureNotImplementedError("The CumfatMethodSelection class cannot yet parse the method file for version 7.10.")

    def update(self, version, **kwargs):
        """This method converts the Method Selection between versions.

        The user asks to update to a version, and depending upon that, it updates
        the parameters object for that version using the valus in the other version.

        Note that there are problems here. Not all Cumfat 5 values have been carried forward.
        Several have been deprecated. Several new ones have been introduced. And the values 
        don't exactly mean the same thing. Something that was 1 could be 4 now.
        
        While automating this updation function, several liberal assumptions have been made in accordance
        with the requirements of the RM12 LTS project's testing needs. As of this update (v0.2a), 
        this function only supports this project.
        
            * This code works only with NHYP=3 for now. 
              NHYP is an indicator of the hypothesis used
              for analysis. 3 corresponds to "Maximum Principal Strain" hypothesis.
            
            * NHYP used to be linked with NCUR, which, in 5.12, is linked to the Material file, instead
              of the Method file.
            
            * For RM12's initial test purposes, it has been decided to test all areas with the Maximum
              Principal Strain hypothesis. Some areas use the Orthogonal Shear Stress Hypothesis, and this is fine,
              but there is appropriate hypothesis in 7.1.0.1, thus it has been decided to convert the pseudo shear stress
              amplitudes to strain, and use the Max. Strain hypothesis.

        """
        if version == 5.12:
            raise FeatureNotImplementedError(("It is not yet possible to convert from a "
                                        "7.1.01 Cumfat Method Selection File to a "
                                        "Cumfat 5.12 compliant format."))
        else:
            parameters_for_cumfat_5_12 = self._parameters.get(5.12)
            self._parameters[version] = {
                                "NLOTY": "", "OLCYC": "",
                                "OSKT": "", "KT": "",
                                "NHYP": "", "OHYP": "",
                                "IHYP": "", "DIRECTIONVECTOR": "",
                                "KORR": "", "OKORR": "",
                                "NMEAN": "", "LIMLIFE": "",
                                "NTOP": "", "NK": "",
                                "NON": "", "TEST": ""
                                }
            #NLOTY had 5 possible values before.
            #Excerpt from Cumfat 5.12 demo method file:
            ### Write the parameters NLOTY and SPEKT in that order separated
            ###      by space.

            ###      NLOTY indicates the format of the stress input:
            ###      1 = Loading_history     (old format, normally not used)
            ###      2 = Spannings_sekvens   (old format, normally not used)
            ###      3 = Grundlastfall       (not implemented)
            ###      4 = New_Stress_Sequence (linear elastic FE analysis)
            ###      5 = Elastic_Plastic_FE  (elastic-plastic FE analysis)

            # SPEKT has been deprecated and doesn't carry forth.
            ###      SPEKT activates or disengage the model for sequence effects, only
            ###      available for NLOTY=4 and NLOTY=5
            ###      0 = Disengage a model for sequence effects
            ###      1 = Activate a model for sequence effects

            #Excerpt from Cumfat 7.1.0 demo method file:
            ###Write the parameters NLOTY and OLCYC on the same row separated by space

            ### - NLOTY indicates the format of the load sequence file:
            ###   1 = linear-elastic load input (Linear_FE)
            ###   2 = elastic-plastic corrected load input (Elastic_Plastic_FE)
            # OLCYC is a new value.
            ### - OLCYC indicates if the Largest CYCle should be found by iteration
            ###   or in the RFC subroutine
            ###    1 = find largest cycle by iteration, a combination of temperature and
            ###        load level determine the largest cycle
            ###    2 = find largest cycle in the RFC subroutine, only load level is used
            ###        to determine the largest cycle (default)

            nloty_5_12 = parameters_for_cumfat_5_12.get("NLOTY")
            if nloty_5_12 in (4,5):
                #There are only 2 possible values for NLOTY now, and they correspond to the old values of 4,5.
                self._parameters[version]["NLOTY"] = nloty_5_12-3
            else:
                raise Exception("Invalid value for NLOTY. %d is not a viable option in Cumfat 7.1.0."%(nloty_5_12))
            self._parameters[version]["OLCYC"] = 2 #This is the default value.

            #NAR is deprecated.
            #Excerpt from Cumfat 5.12 demo method file:
            ###Write the parameter NAR, telling how many aeras with different material
            ###  data there are in the model (maximum 10 is allowed)

            #NCONC was deprecated, and replaced by OSKT.
            #Excerpt from Cumfat 5.12 demo method file:
            ###Write NCONC, telling how many areas of the FE-model, which need to be
            ###  provided with stress concentration factors (normally NCONC=0)

            #Excerpt from Cumfat 7.1.0 demo method file:
            ###Write the parameter OSKT KTXX KTYY KTZZ KTXY KTYZ KTXZ  on the same
            ###     row separated by space.

            ###     - OSKT indicate if stress concentration factor should be considered
            ###       0 = No stress concentration
            ###       1 = Stress concentration factor should be considered
            #The KT vector is new.
            ###     - KTXX KTYY KTZZ KTXY KTYZ KTXZ only needs to be specified if OSKT
            ###       is set to 1 (Stress concentration factor should be considered).
            ###       - KTXX corresponds to a factor that will be multiplied to the stress
            ###         component SXX in the load history file.
            ###       - KTYY corresponds to a factor that will be multiplied to the stress
            ###         component SYY in the load history file.
            ###       - And similar for remaining stress components.

            ###     The stress concentration will be added directly after the load
            ###     history has been read and before any manipulation of load data.
            ###     I.e. SXX = KTXX*SXX, SYY = KTYY*SYY and etc.

            ###     NB! Provided stress concentration factors is applied to all load steps.
            ###     NB! Provided stress concentration factors is applied to all nodes.
            ###     NB! Stress concentration factors can only be provided if NLOTY = 1
            ###         (linear elastic FE analysis)
            nconc_5_12 = parameters_for_cumfat_5_12.get("NCONC")
            if nconc_5_12 == 0:
                self._parameters[version]["OSKT"] = 0
                self._parameters[version]["KT"] = "1.0 1.0 1.0 1.0 1.0 1.0"
            else:
                #Non zero means there are areas with stress concentration.
                #Need to parse the d31 file then.
                self._parameters[version]["OSKT"] = 1
                if self.file_path is not None:
                    file_directory = os.path.dirname(self.file_path)
                    d31_files = glob.glob(os.path.join(file_directory,"*.d31"))
                    if len(d31_files) >0:
                        d31_lines = get_file_as_list_using_any_encoding(d31_files[0])
                        stress_concentration_vector_text = d31_lines[0].split()
                        #Need to convert the stress concentration vector from scientific notation to floating point.

                        stress_concentration_vector = [float(x) for x in stress_concentration_vector_text]
                        self._parameters[version]["KT"] = " ".join([str(x) for x in stress_concentration_vector])
                    else:
                        #Need to figure out how to handle this one.
                        raise InvalidInput("The method file indicates that stress concentration needs to be considered. Cumfat 5.12 uses *.d31 files to map a stress concentration vector to a particular node. Cumfat 7.1 doesn't allow node-specific stress tensors, but it is possible to override this. However, the folder containing this method file doesn't contain any d31 files, so it is impossible to decide what the stress concentration vector should be.")
                else:
                    #TODO: Design an alternate algorithm.
                    raise InvalidInput("Need a file path to able to obtain information about the d31 file containing the stress concentration vector.")

            #NHYP has been limited, and purged of unused features, while introducing new features.
            #The old order of inputs has changed, as a result
            #Excerpt from Cumfat 5.12 demo method file:
            ### Write the parameters NHYP

            ###      NHYP indicates which of the hypotheses for multiaxial stress measure
            ###      to be used in this analysis:
            ###      1 = Maximum Principal Stress
            ###      2 = Maximum Shear Stress
            ###      3 = Maximum Principal Strain
            ###      4 = Octahedral Shear Stress
            ###      5 = Plastic Principal Strain (NLOTY=5)
            #Excerpt from Cumfat 7.1.0 demo method file:.
            ###Write the parameters NHYP and OHYP on the same row separated by space.

            ### - NHYP indicates which of the hypotheses for effective
            ###   stress/strain measure to be used in the analysis:
            ###   1 = Maximum Principal Stress
            ###   2 = Maximum Principal Strain
            ###   3 = von Mises Stress with sign
            ###   4 = Normal Stress acting on a specific plane

            ### NB! NLOTY = 2, (elastic plastic FE) cannot be combined with NHYP = 3
            ###     (von Mises Stress).
            #OHYP is new, as an extension to the NHYP parameter.
            ### - OHYP only needs to be specified if NHYP is equal to 1 (Maximum
            ###   Principal Stress), 2 (Maximum Principal Strain) or equal to 4
            ###   (Normal Stress)
            ###   1 = Only calculate damage in the direction of the largest principal
            ###       stress/strain (default)
            ###   2 = Calculate damage in the three principal stress/strain directions
            ###       of the largest load step
            ###   3 = Iterate through space to find the most critical plane.
            ###       For this option the parameter IHYP needs to be specified. IHYP
            ###       indicates how many steps should be made by the program to
            ###       determine next plane for damage calculation. For instance, if
            ###       IHYP is set to 6, first the three principal stress/strain
            ###       directions will be used. Then the space will be divided into
            ###       6*6 different planes. I.e. 3+6*6 = 39 iterations will be made.
            ###       On the same row write NHYP OHYP IHYP separated by space.
            ###   4 = calculate damage in predefined direction. If this option is chosen,
            ###       write desired direction as the normal unit vector (NUX,NUY,NUZ)
            ###       perpendicular to the chosen plane. Write the parameters
            ###       NUX NUY NUZ separated by space directly after NHYP and OHYP.
            ###       I.e. write NHYP OHYP NUX NUY NUZ
            nhyp_5_12 = parameters_for_cumfat_5_12.get("NHYP")
            if nhyp_5_12 == 1:
                #Default value. Need to check with Martin or Magnus.
                self._parameters[version]["NHYP"]= 1
                self._parameters[version]["OHYP"] = 1
            elif nhyp_5_12 == 2:

                raise Exception(("Need to check what value of NHYP to choose when "
                                "5.12 used 2 (Maximum Shear Stress). "
                                "Is this deprecated?"))
            elif nhyp_5_12 == 3:
                self._parameters[version]["NHYP"]= 2
                self._parameters[version]["OHYP"] = 1 #Need to figure out how to handle this one.
            elif nhyp_5_12 == 4:
                #HACK: Just to get this working, mapping octa to maximum principal strain.
                self._parameters[version]["NHYP"]= 2
                self._parameters[version]["OHYP"] = ""
                #raise FeatureNotImplementedError("It is not possible to compare a setup for octahedral stress with Von Mises as it is unclear how octahedral stress algorithms in cumfat handle the signs of the stresses.")
                # raise Exception(("Need to check what value of NHYP to choose when 5.12 used ",
                #    "4 (Octahedral Shear Stress). Is this deprecated?"))
            elif nhyp_5_12 == 5:
                if nloty_5_12 != 5:
                    raise Exception(("The 5.12 method file seems invalid. According to the documentation, "
                        "nhyp can be 5 (Plastic Principal Strain) only when NLOTY = 5 "
                        "(Elastic_Plastic_FE  (elastic-plastic FE analysis)). "
                        "However, this method file seems to have used such a situation. "
                        "Check with EIC."))
                else:
                    raise Exception(("Need to check what value of NHYP to choose in 7.1.0 "
                                    "when 5.12 used 5 (Plastic Principal Strain)."))
            else:
                raise Exception("%r is an invalid input for NHYP in the 5.12 method file."%nhyp_5_12)
            #TODO: NLOTY = 2, (elastic plastic FE) cannot be combined with NHYP = 3
            #(von Mises Stress). Figure out how to do this.
            #TODO: There are other possible values for NHYP in the new Cumfat. Need to check when they are usable.

            #KORR has been carried forward, with one additional possible value,
            #and there's a new extension parameter OKORR.
            #Excerpt from Cumfat 5.12 demo method file:
            ### Write KORR, telling which of the hypotheses for elastic-plastic
            ###      correction to be used:
            ###      0 = No correction
            ###      1 = The Linear Rule
            ###      2 = The Neuber Rule
            ###      3 = Correction performed by FE-code (NLOTY=5)

            #Excerpt from Cumfat 7.1.0 demo method file:.
            ###Write the parameters KORR and OKORR on the same row separated by space

            ### - KORR indicates which of the hypotheses for elastic-plastic
            ###   correction to be used:
            ###   0 = No correction
            ###   1 = Linear Rule, displacement controlled (Strain controlled loading)
            ###   2 = Neuber Rule (Notches)
            ###   3 = Linear Rule, load controlled (Stress controlled loading)
            ###   4 = Correction performed by FE-code

            ### - OKORR indicated if elastic-plastic correction should be performed
            ###   before or after RFC
            ###   1 = Before RFC.
            ###   2 = After RFC (default)

            ### NB! OKORR will be set to OKORR = 2 (after RFC) if
            ###     KORR = 0 (No correction) automatically by the program.
            ### NB! OKORR will be set to OKORR = 1 (before RFC) if
            ###     NLOTY = 2 (elastic plastic FE) automatically by the program.
            ### NB! In Cumfat7.1, the combination NLOTY = 1 (linear elastic FE) and
            ###     OKORR = 1 (correction before RFC) should only be performed in
            ###     method development work or in consultation with system owner.
            korr_cumfat_5_12 = parameters_for_cumfat_5_12.get("KORR")
            if 0 <= korr_cumfat_5_12 <= 3:
                self._parameters[version]["KORR"] = korr_cumfat_5_12
                #TODO: CHECK THE PRECEDENCE OF THESE TWO CONDITIONS.
                #Which condition is more important?
                if self._parameters[version].get("NLOTY") == 2:
                    self._parameters[version]["OKORR"] = 2
                elif korr_cumfat_5_12 == 0:
                    self._parameters[version]["OKORR"] = 1
                if self._parameters[version].get("NLOTY") == 1 and self._parameters[version].get("OKORR") == 1:
                    raise Exception(("In Cumfat7.1, the combination NLOTY = 1 (linear elastic FE) ",
                        "and OKORR = 1 (correction before RFC) should only be performed in method ",
                        "development work or in consultation with system owner."))
                    #TODO: Make a new kind of exception for these kind of situations. Something that the
                    #Code can override at a later stage, when the user seems to know what he's doing.
            #Todo: There's a new value for korr in cumfat 7.1.0 that needs to be used, so when does the user need it?

            #NCUR is ported to the material data file.
            #Excerpt from the cumfat 5.12 demo method file:
            ###Write the parameter NCUR

            ###  NCUR tells how the fatigue data are provided:
            ###   Analysis without creep consideration:
            ###    2 = Table of strain-range versus life
            ###    3 = Data are defined by Basquin-Coffin-Manson parameters
            ###    4 = Table of Smith-Watson-Topper-value versus life
            ###    5 = Table of pseudo-stress-amplitude versus life
            ###   Analysis with creep consideration:
            ###  (PLM is the Larson-Miller parameter, here as function of stress in a table)
            ###    6 = Table of strain-range versus life, followed by table of PLM
            ###    7 = Table of strain-range versus life, followed by Coffin frequency-parameter
            ###    8 = Data defined by Basq.-Coff.-Mans. parameters, followed by table of PLM
            ###    9 = Data defined by Basq.-Coff.-Mans. parameters, followed by Coff. freq.-param
            ###    10 = Table of Smith-Watson-Topper-value, followed by table of PLM
            ###    11 = Table of Smith-Watson-Topper-value, followed by table Coff. freq.-parameter
            ###    12 = Table of pseudo-stress-amplitude versus life, followed by table of PLM
            ###    13 = Table of pseudo-stress-amplitude versus life, followed by Coff. freq.-param

            #NMEAN is copied over verbatim,
            #but there seem to be some conditions to look into.
            #For these conditions, the material data file needs to be parsed. Looks like
            #Both these files need to be parsed simultaneously.
            #Excerpt from the cumfat 5.12 demo method file:
            ###Write NMEAN, telling which of the hypotheses for mean stress influence
            ###  to be used in this analysis:
            ###  1 = Morrow
            ###  2 = Smith-Watson-Topper
            ###  3 = Walker
            #Excerpt from Cumfat 7.1.0 demo method file:
            ###    Write the parameter NMEAN
            ### - NMEAN indicates which of the hypotheses for mean stress influence
            ###   to be used in this analysis
            ###   1 = Morrow_Hyp   Morrow Hypothesis
            ###   2 = SWT_Hyp      Smith-Watson-Topper Hypothesis
            ###   3 = WES_Hyp      Walker Effective Stress Hypothesis

            ### NB! Following NMEAN can only be combined with following OLCF
            ###     (format of material data), all other alternatives are not allowed.
            ### NMEAN = 1,2 <-> OLCF = 1 LCF_Table   (Table of strain-range versus life)
            ### NMEAN = 1   <-> OLCF = 2 BCM_Coeff   (Data are defined by
            ###                                       Basquin-Coffin-Manson parameters)
            ### NMEAN = 2   <-> OLCF = 3 SWT_Table   (Table of Smith-Watson-Topper-value
            ###                                       versus life)
            ### NMEAN = 3   <-> OLCF = 4,5,6 WES_mR* (Data are defined by Walker
            ###                                       Effective Stress parameters)

            nmean_cumfat_5_12 = parameters_for_cumfat_5_12.get("NMEAN")
            self._parameters[version]["NMEAN"] = nmean_cumfat_5_12
            #TODO: Alter this method so that it also reads the material data file and then does this validation.
            #TODO: Looks like both the method and material data files need to be synced. Need to look into how
            #   to do this.
            # if nmean_cumfat_5_12 == 1 and cumfat_7_1_0_material_dict.get("OLCF") not in (1,2):
            # elif nmean_cumfat_5_12 == 2 and cumfat_7_1_0_material_dict.get("OLCF") not in (1,3):
            # elif nmean_cumfat_5_12 == 3 and cumfat_7_1_0_material_dict.get("OLCF") not in (4,5,6):

            #LIMLIFE is copied over verbatim.
            #Excerpt from the cumfat 5.12 demo method file:
            ###Write LIMLIFE, telling that lives longer than LIMLIFE are given the
            ###     value LIMLIFE. This value is used only for plot data.
            #Excerpt from Cumfat 7.1.0 demo method file:
            ### Write the parameter LIMLIFE.
            ### - LIMLIFE, calculated life greater than LIMLIFE is set to LIMLIFE.
            ###   This value is only used in output files created for contour plotting
            ###   data in ANSYS.
            limlife_cumfat_5_12 = parameters_for_cumfat_5_12.get("LIMLIFE")
            self._parameters[version]["LIMLIFE"] = limlife_cumfat_5_12

            #NTOP is copied over verbatim.
            #Excerpt from the cumfat 5.12 demo method file:
            ###Write NTOP, telling that the node numbers of NTOP nodes with lowest
            ### life are sorted and written to the file job_name.inf
            #Excerpt from Cumfat 7.1.0 demo method file:
            ###Write the parameter NTOP
            ### - NTOP is the number of nodes with lowest life that will be written
            ###   on the file jobname.inf
            #TODO: Check this point in the final result, could be interesting to see if that is
            #   indeed the case.
            ntop_cumfat_5_12 = parameters_for_cumfat_5_12.get("NTOP")
            self._parameters[version]["NTOP"] = ntop_cumfat_5_12

            #NON is modified. The new NON is the node names, while NK denotes their number.
            #My parsing algorithm already interchanged the names and introduced the nk variable,
            #So I can go ahead and use nk and non verbatim.
            #Excerpt from the cumfat 5.12 demo method file:
            ###Write NON and define the NON nodes for which extra check data are
            ###     written to the file job_name.cyc (maximum value of NON is 10000)
            #Excerpt from Cumfat 7.1.0 demo method file:
            ###Write the parameters NK and NON in that order separated by space.
            ###  - NK is the number of nodes for which extra check data are
            ###    written to the file jobname.cyc (maximum value of NK is 10000, minimum
            ###    value is 0).
            #TODO: Check this point in the final result, could be interesting to see if that is
            #   indeed the case.
            ###  - NON is the node number for the NK nodes.
            ###  If more information about the Cumfat run is desired, on the next row
            ###  write -999, the TESTRUN parameter. A extra output file *.cyc 2 will be
            ###  written with more detailed information about the analysis.
            ###  Can be omitted if no extra output is desired.
            nk_cumfat_5_12 = parameters_for_cumfat_5_12.get("NK")
            self._parameters[version]["NK"] = nk_cumfat_5_12
            non_cumfat_5_12 = parameters_for_cumfat_5_12.get("NON")
            self._parameters[version]["NON"] = non_cumfat_5_12

    def get_alternate_version(self):
        if self.version == 5.12:
            alternate_version = 7.1
        else:
            alternate_version = 5.12
        return alternate_version

    def set_default_version(self):
        """For now, the default version is 7.1.0"""
        self.version  = 7.1

    def set_version(self, version):
        self.available_versions = [5.12, 7.1]
        if version in self.available_versions:
            self._version = version
        else:
            raise InvalidInput("""version should be one of %s. \"%s\" is unacceptable."""%(str(self.available_versions), version))

    def save_to_file(self, file_path, version=None, **kwargs):
        """File dumping method."""
        #TODO: these seem to be common.
        #I should just make a superclass that deals with this stuff.
        if version is None:
            self.set_default_version()
        else:
            self.set_version(version)
        allow_save = False

        parameters_for_required_version = self._parameters.get(self._version)
        if parameters_for_required_version is None:
            raise InsufficientData((
            		"There is no version %s compliant information. "
                    "If you're trying to convert between versions, "
                    "ensure you have written a conversion step.")%self._version)
        else:
            empty_entries = [key for key in parameters_for_required_version.keys() if parameters_for_required_version[key] is None]
            if len(empty_entries)>0:
                raise InsufficientData("The field(s) %s cannot be empty when attempting to save the method selection file for Cumfat v%s."%(empty_entries,self._version))
            else:
                if self._version == 5.12:
                    #raise FeatureNotImplementedError("I have yet to implement saving a cumfat method file in 5.12 version")
                    allow_save = True
                elif self._version == 7.1:
                    allow_save = True
                else:
                    raise InvalidInput("Wrong cumfat method file version.")
        if allow_save:
            if parameters_for_required_version["NHYP"] == 5.12:
                raise Exception("Wtf happened?")
            template = get_cumfat_method_selection_file_template(self._version)
            cumfat_file_contents = template.format(**parameters_for_required_version)
            with open(file_path, mode="wt", encoding="utf-8") as f:
                for line in cumfat_file_contents.splitlines():
                    f.write(line)
                    f.write("\n")
        else:
            raise SaveNotAllowedError

def get_cumfat_method_selection_file_template(version):
    template = ""
    if version == 5.12:
        template = """***********************Instruction block*******************************
 This is an instruction block. An instruction block starts with a row,
 which in at least in its 10 first positions contains asterisks. It also
 ends in the same way. An instruction block can have any number of rows.
 Data used by CUMFAT must be written in between instruction blocks. The
 purpose of the instruction block is to define what data to be written,
 and thus facilitate for the user. Blank rows are allowed in front of an
 instruction block. Now actual instructions are given:

 Write 2 rows with arbitrary information texts to appear in results files
******************End of instruction block******************************
{COMMENT_1}
{COMMENT_2}
************************************************************************
 Write the parameters NLOTY and SPEKT in that order separated
 by space.

 NLOTY indicates the format of the stress input:
 1 = Loading_history     (old format, normally not used)
 2 = Spannings_sekvens   (old format, normally not used)
 3 = Grundlastfall       (not implemented)
 4 = New_Stress_Sequence (linear elastic FE analysis)
 5 = Elastic_Plastic_FE  (elastic-plastic FE analysis)

 SPEKT activates or disengage the model for sequence effects, only
 available for NLOTY=4 and NLOTY=5
 0 = Disengage a model for sequence effects
 1 = Activate a model for sequence effects
************************************************************************
 {NLOTY} {SPEKT}
************************************************************************
 Write the parameter NAR, telling how many aeras with different material
 data there are in the model (maximum 10 is allowed)
************************************************************************
 {NAR}
************************************************************************
 Write NCONC, telling how many areas of the FE-model, which need to be
 provided with stress concentration factors (normally NCONC=0)
************************************************************************
 {NCONC}
************************************************************************
 Write the parameters NHYP

 NHYP indicates which of the hypotheses for multiaxial stress measure
 to be used in this analysis:
 1 = Maximum Principal Stress
 2 = Maximum Shear Stress
 3 = Maximum Principal Strain
 4 = Octahedral Shear Stress
 5 = Plastic Principal Strain (NLOTY=5)
************************************************************************
 {NHYP}
************************************************************************
 Write KORR, telling which of the hypotheses for elastic-plastic
 correction to be used:
 0 = No correction
 1 = The Linear Rule
 2 = The Neuber Rule
 3 = Correction performed by FE-code (NLOTY=5)
************************************************************************
 {KORR}
************************************************************************
 Write the parameter NCUR

 NCUR tells how the fatigue data are provided:
  Analysis without creep consideration:
   2 = Table of strain-range versus life
   3 = Data are defined by Basquin-Coffin-Manson parameters
   4 = Table of Smith-Watson-Topper-value versus life
   5 = Table of pseudo-stress-amplitude versus life
  Analysis with creep consideration:
 (PLM is the Larson-Miller parameter, here as function of stress in a table)
   6 = Table of strain-range versus life, followed by table of PLM
   7 = Table of strain-range versus life, followed by Coffin frequency-parameter
   8 = Data defined by Basq.-Coff.-Mans. parameters, followed by table of PLM
   9 = Data defined by Basq.-Coff.-Mans. parameters, followed by Coff. freq.-param
   10 = Table of Smith-Watson-Topper-value, followed by table of PLM
   11 = Table of Smith-Watson-Topper-value, followed by table Coff. freq.-parameter
   12 = Table of pseudo-stress-amplitude versus life, followed by table of PLM
   13 = Table of pseudo-stress-amplitude versus life, followed by Coff. freq.-param
************************************************************************
 {NCUR}
************************************************************************
 Write NMEAN, telling which of the hypotheses for mean stress influence
 to be used in this analysis:
 1 = Morrow
 2 = Smith-Watson-Topper
 3 = Walker
************************************************************************
 {NMEAN}
************************************************************************
 Write LIMLIFE, telling that lives longer than LIMLIFE are given the
 value LIMLIFE. This value is used only for plot data.
************************************************************************
 {LIMLIFE}
************************************************************************
 Write NTOP, telling that the node numbers of NTOP nodes with lowest
 life are sorted and written to the file job_name.inf
************************************************************************
  {NTOP}
************************************************************************
 Write NON and define the NON nodes for which extra check data are
 written to the file job_name.cyc (maximum value of NON is 10000)
************************************************************************
{NK} {NON}
"""
    elif version == 7.1:
        template = """***********************Instruction block*******************************
 This is an instruction block. An instruction block starts with a row,
 which in at least in its first positions contains 10 asterisks or
 10 plus signs. It also ends in the same way.
 An instruction block can have any number of rows.
 Data used by CUMFAT must be written in between instruction blocks. The
 purpose of the instruction block is to define what data to be written,
 and thus facilitate for the user. Blank rows are allowed in front of an
 instruction block. Now actual instructions are given:

------------------------------------------------------------------------
 Write the parameters NLOTY and OLCYC on the same row separated by space

 - NLOTY indicates the format of the load sequence file:
   1 = linear-elastic load input (Linear_FE)
   2 = elastic-plastic corrected load input (Elastic_Plastic_FE)

 - OLCYC indicates if the Largest CYCle should be found by iteration
   or in the RFC subroutine
    1 = find largest cycle by iteration, a combination of temperature and
        load level determine the largest cycle
    2 = find largest cycle in the RFC subroutine, only load level is used
        to determine the largest cycle (default)
************************************************************************
{NLOTY} {OLCYC}
************************************************************************
 Write the parameter OSKT KTXX KTYY KTZZ KTXY KTYZ KTXZ  on the same
 row separated by space.

 - OSKT indicate if stress concentration factor should be considered
   0 = No stress concentration
   1 = Stress concentration factor should be considered

 - KTXX KTYY KTZZ KTXY KTYZ KTXZ only needs to be specified if OSKT
   is set to 1 (Stress concentration factor should be considered).
   - KTXX corresponds to a factor that will be multiplied to the stress
     component SXX in the load history file.
   - KTYY corresponds to a factor that will be multiplied to the stress
     component SYY in the load history file.
   - And similar for remaining stress components.

 The stress concentration will be added directly after the load
 history has been read and before any manipulation of load data.
 I.e. SXX = KTXX*SXX, SYY = KTYY*SYY and etc.

 NB! Provided stress concentration factors is applied to all load steps.
 NB! Provided stress concentration factors is applied to all nodes.
 NB! Stress concentration factors can only be provided if NLOTY = 1
     (linear elastic FE analysis)
************************************************************************
{OSKT} {KT}
************************************************************************
 Write the parameters NHYP and OHYP on the same row separated by space.

 - NHYP indicates which of the hypotheses for effective
   stress/strain measure to be used in the analysis:
   1 = Maximum Principal Stress
   2 = Maximum Principal Strain
   3 = von Mises Stress with sign
   4 = Normal Stress acting on a specific plane

 NB! NLOTY = 2, (elastic plastic FE) cannot be combined with NHYP = 3
     (von Mises Stress).

 - OHYP only needs to be specified if NHYP is equal to 1 (Maximum
   Principal Stress), 2 (Maximum Principal Strain) or equal to 4
   (Normal Stress)
   1 = Only calculate damage in the direction of the largest principal
       stress/strain (default)
   2 = Calculate damage in the three principal stress/strain directions
       of the largest load step
   3 = Iterate through space to find the most critical plane.
       For this option the parameter IHYP needs to be specified. IHYP
       indicates how many steps should be made by the program to
       determine next plane for damage calculation. For instance, if
       IHYP is set to 6, first the three principal stress/strain
       directions will be used. Then the space will be divided into
       6*6 different planes. I.e. 3+6*6 = 39 iterations will be made.
       On the same row write NHYP OHYP IHYP separated by space.
   4 = calculate damage in predefined direction. If this option is chosen,
       write desired direction as the normal unit vector (NUX,NUY,NUZ)
       perpendicular to the chosen plane. Write the parameters
       NUX NUY NUZ separated by space directly after NHYP and OHYP.
       I.e. write NHYP OHYP NUX NUY NUZ
************************************************************************
{NHYP} {OHYP} {IHYP} {DIRECTIONVECTOR}
************************************************************************
 Write the parameters KORR and OKORR on the same row separated by space

 - KORR indicates which of the hypotheses for elastic-plastic
   correction to be used:
   0 = No correction
   1 = Linear Rule, displacement controlled (Strain controlled loading)
   2 = Neuber Rule (Notches)
   3 = Linear Rule, load controlled (Stress controlled loading)
   4 = Correction performed by FE-code

 - OKORR indicated if elastic-plastic correction should be performed
   before or after RFC
   1 = Before RFC.
   2 = After RFC (default)

 NB! OKORR will be set to OKORR = 2 (after RFC) if
     KORR = 0 (No correction) automatically by the program.
 NB! OKORR will be set to OKORR = 1 (before RFC) if
     NLOTY = 2 (elastic plastic FE) automatically by the program.
 NB! In Cumfat7.1, the combination NLOTY = 1 (linear elastic FE) and
     OKORR = 1 (correction before RFC) should only be performed in
     method development work or in consultation with system owner.
************************************************************************
{KORR} {OKORR}
************************************************************************
 Write the parameter NMEAN

 - NMEAN indicates which of the hypotheses for mean stress influence
   to be used in this analysis
   1 = Morrow_Hyp   Morrow Hypothesis
   2 = SWT_Hyp      Smith-Watson-Topper Hypothesis
   3 = WES_Hyp      Walker Effective Stress Hypothesis

 NB! Following NMEAN can only be combined with following OLCF
     (format of material data), all other alternatives are not allowed.
 NMEAN = 1,2 <-> OLCF = 1 LCF_Table   (Table of strain-range versus life)
 NMEAN = 1   <-> OLCF = 2 BCM_Coeff   (Data are defined by
                                       Basquin-Coffin-Manson parameters)
 NMEAN = 2   <-> OLCF = 3 SWT_Table   (Table of Smith-Watson-Topper-value
                                       versus life)
 NMEAN = 3   <-> OLCF = 4,5,6 WES_mR* (Data are defined by Walker
                                       Effective Stress parameters)
************************************************************************
{NMEAN}
************************************************************************
 Write the parameter LIMLIFE.

  - LIMLIFE, calculated life greater than LIMLIFE is set to LIMLIFE.
    This value is only used in output files created for contour plotting
    data in ANSYS.
************************************************************************
 {LIMLIFE}
************************************************************************
 Write the parameter NTOP

 - NTOP is the number of nodes with lowest life that will be written
   on the file jobname.inf
************************************************************************
  {NTOP}
************************************************************************
 Write the parameters NK and NON in that order separated by space.

 - NK is the number of nodes for which extra check data are
   written to the file jobname.cyc (maximum value of NK is 10000, minimum
   value is 0).

 - NON is the node number for the NK nodes.

 If more information about the Cumfat run is desired, on the next row
 write -999, the TESTRUN parameter. A extra output file *.cyc 2 will be
 written with more detailed information about the analysis.
 Can be omitted if no extra output is desired.
************************************************************************
 {NK} {NON}
{TEST}

"""
    return template
