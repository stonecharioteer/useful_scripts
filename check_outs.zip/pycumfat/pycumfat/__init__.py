#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""pycumfat Module Documentation

This module enables Cumfat users to automate their preprocessing, execution and postprocessing flows
using the Python programming language.

The module provides the following classes:

1. CumfatMethodSelection
2. CumfatMaterialData
3. CumfatControl

It also provides the following methods:

1. get_cumfat_error_from_code
2. get_cumfat_method_selection_file_template
3. get_cumfat_material_template

"""

from .CumfatControl import *
from .CumfatMaterialData import *
from .CumfatMethods import *
from .CumfatMethodSelection import *
