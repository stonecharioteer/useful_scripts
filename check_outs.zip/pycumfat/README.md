# pycumfat
===

This Python library was developed by Vinay Keerthi (yy54426) between 2016 and 2017. It rose as a result of the efforts put into testing Cumfat v7.1 for the RM12 LTS project.

It contains no export control data and is developed to be generic so that it can be used for any cumfat related project.
