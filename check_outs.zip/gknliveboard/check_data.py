# -*- coding: utf-8 -*-
"""
Created on Fri Jul 07 13:23:15 2017

@author: Vinay.Keerthi
"""

import json
import os
import pandas as pd
root = r"C:\Users\vinay.keerthi\svn_repos\XT4210\apps\tolkien\data"
j_path = os.path.join(root, "globe","world-110m.json")
with open(j_path) as f:
    names = json.load(f)
t_path = os.path.join(root, "globe","world-country-names_gkn.tsv")
df = pd.read_csv(t_path, delimiter="\t")
excel_path = os.path.join(root,"map list.xlsx")
map_df = pd.read_excel(excel_path,sheetname="data")
df_countries = pd.read_excel(excel_path,sheetname="countries_list")

condition_1 = pd.notnull(map_df["Latitude"])
condition_2 = pd.notnull(map_df["Country"])
condition = [one and two for one,two in zip(condition_1, condition_2)]


map_df = map_df.loc[condition].copy()
map_df["Country ID"] = None
for ix, row in map_df.iterrows():
    country = row["Country"]
    relevant_row = df_countries.loc[df_countries["name"] == country]
    country_id = int(relevant_row["id"])
    map_df.set_value(ix,"Country ID", country_id)
