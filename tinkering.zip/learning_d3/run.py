from flask import (Flask, url_for, render_template, request)


app = Flask(__name__)

@app.route("/", methods=["GET"])
def serve_example():
    example_no = request.args.get("exno")
    if example_no is None:
        return "Page not found!"
    else:
        return render_template("ex_{}.html".format(example_no))

if __name__ == "__main__":
    app.run(threaded=True, host="0.0.0.0", port=8081, debug=True)

