#!/usr/bin/env python3

from flask import (Flask, request, url_for,
        render_template, jsonify)

import os

app = Flask(__name__)

@app.route("/", methods=["GET"])
def serve_home():
    return render_template("home.html")

@app.route("/data", methods=["GET"])
def serve_data():
    dataset = request.args.get("dataset")
    print(dataset)
    if dataset == "circles":
        return serve_circles()
    elif dataset == "bar":
        return serve_bar()
    else:
        return "null"

def serve_bar():
    import random
    bar_count = random.randint(10,25)
    max_value = random.randint(100,2000)
    bars = [random.randint(0,max_value) for i in range(bar_count)]
    return jsonify(bars)

def serve_circles():
    import random
    circle_count = random.randint(100, 10**4)
    print("Decided to send {} circles.".format(circle_count))
    circles = []
    for i, c in enumerate(range(circle_count)):
        this_circle = {
                    "cx": random.randint(20,2000),
                    "cy": random.randint(20,2000),
                    "r": random.randint(1,10),
                    "color": "#%06x" % random.randint(0, 0xFFFFFF),
                    "opacity": (1.0-c/circle_count)
                    }
        circles.append(this_circle)
    return jsonify(circles)

if __name__ == "__main__":
    app.run(port=8081, host="0.0.0.0",
            debug=True, threaded=True)

