// Shopfloorman javascript.
//
//
//
//
//
//
//
//
//
//


function render_circles(dataset) {
    console.log("?")
    var selector = d3.select("svg").selectAll("circle")
        .style("opacity", function(d) {return 0.2 })
        .data(dataset);
    var entering = selector.enter();
    entering.append("circle")
        .attr("cx", function(d,i) {return d["cx"]})
        .attr("cy", function(d,i) {return d["cy"]})
        .attr("r", function(d,i) {return d["r"]})
        .style("opacity", function(d, i) { return d["opacity"]})
        .style("fill", function(d, i) {
            return d["color"];
        });

    selector
        .attr("cx", function(d,i) {return d["cx"]})
        .attr("cy", function(d,i) {return d["cy"]})
        .attr("r", function(d,i) {return d["r"]})
        .style("opacity", function(d, i) {return d["opacity"] })
        .style("fill", function(d, i) {
            return d["color"];
        });
    var exiting = selector.exit();
    exiting.remove();
    console.log(dataset.length)
};

function render_graph(dataset) {
    var barWidth = 25,
        barPadding = 1,
        graphWidth = dataset.length*(barWidth + barPadding) - barPadding,
        margin = {top: 10, right: 10, bottom: 10, left: 50},
        total_width = graphWidth + margin.left + margin.right,
        total_height = maxValue + margin.top + margin.bottom;

    function xloc(d, i) { return i * (barWidth + barPadding)};
    function yloc(d, i) {return maxValue - d; };
    function translator(d, i) {
            return "translate("+ xloc(d, i) + "," + yloc(d) + ")";
            };

    var maxValue = d3.max(dataset);
    var svg = d3.select("body")
                        // .selectAll("svg")
                        .append("svg")
                        .attrs({ 
                            width: total_width, 
                            height: total_height
                        });
    svg.append("rect").attrs({
                width: total_width,
                height: total_height,
                fill: "white",
                stroke: "black",
                "stroke-width": 3
            });
    var graphGroup = svg
                        .append("g")
                        .attr('transform', 'translate(' + margin.left + "," +
                                                    margin.top + ")");

    graphGroup.append("rect").attrs({
        fill: "rgba(0,0,0,0.1)",
        width: total_width - (margin.left + margin.right),
        height: total_height - (margin.bottom + margin.top)
    });
    
    


    graphGroup.selectAll("rect")
                .data(dataset)
                .enter()
                .append("rect")
                .attrs({
                    fill: 'steelblue',
                    transform: translator,
                    width: barWidth,
                    height: function(d) {return d; }
                });
};
function update() {
fetch("/data?dataset=bar")
    .then(resp => resp.json())
    .then(function(resp) {
        render_graph(resp)
    });
};

update()
