#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 11:54:38 2017

@author: yy54426
"""

from PyQt5.QtWidgets import QPushButton
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QSize


class ImageButton(QPushButton):
    def __init__(self, image_path, size_tuple=None, height=None, *args, **kwargs):
        super(ImageButton, self).__init__(*args, **kwargs)
        self.setIcon(QIcon(image_path))
        if size_tuple is not None:
            self.setIconSize(QSize(*size_tuple))
        # self.setFlat(True)
