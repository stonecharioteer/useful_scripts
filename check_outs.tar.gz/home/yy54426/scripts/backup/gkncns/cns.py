"""
CNS Module
===
This module provides an interface to parse CNS files.
It will enable users to read CNS files and construct their own CNS files.
===
Maintained & Created by : Najeem Muhammed & Vinay Keerthi

"""
import os
from getpass import getuser
import datetime
import subprocess

import pandas as pd

from gknpwlife import read_pwlife
from gknexceptions.invalidfileerror import InvalidFileError

class CNS(pd.DataFrame):
    """
    CNS Dataframe class
    Derived from Pandas Dataframe class
    """

    cns_file = None

    @property
    def _constructor(self):
        return CNS
    
    def _repr_html_(self):
        """Definition for IPython's HTML representation."""
        html = super()._repr_html_()
        info = "<h1>CNS Object Definition</h1><br>"
        info += "<b>File Path:</b> {}<br>".format(self.cns_file)
        info += "<b>No. of Nodes:</b> {}<br>".format(len(self.nodes()))
        info += "<b>No. of Time Points:</b> {}<br><br>".format(len(self.timepoints()))
        
        html = info + html
        return html
  
    def nodes(self):
        """Returns a list of all nodes in the current CNS file"""
        return self.index.get_level_values(0).unique()
    
    def timepoints(self):
        """Returns a list of all timepoints in the current CNS file"""
        return self.index.get_level_values(1).unique()
    
    def get_subset(self,nodes=None,timepoints=None):
        """
        Function to get a subset of the CNS dataframe filtered by node and timepoint list
        
        Parameters
        ----------
        nodes : A list or range of nodes in string format.
        timepoints : A list or range of timepoints in string format.
                
        Example of a list: "1,3,2,23"
        Example of a range: "1:10"
            
        You can combine the above method as well
        Example of combination: "1:10,15:18"
        """
        idx = pd.IndexSlice
        if nodes==None or nodes=="":
            idx_nodes = eval("idx[:]")
        else:
            if ":" not in nodes:
                nodes = nodes + ":" + nodes
            idx_nodes = eval("idx[{}]".format(nodes))
        if timepoints==None or timepoints=="":
            idx_tp = eval("idx[:]")
        else:
            if ":" not in timepoints:
                timepoints = timepoints + ":" + timepoints
            idx_tp = eval("idx[{}]".format(timepoints))
        return self.loc[(idx_nodes,idx_tp),:].copy()
    
    def derived_stress(self,label):
        """
        Create derived stresses like SEQV, S1, S2 and S3
        
        Parameters
        ----------
        label : label of the derived quantity, String
               Following options are allowed
               'seqv' - for Equivalent stress
               's1' - for first principal stress
               's2' - for second principal stress
               's3' - for third principal stress
        """
        if label.lower() == 'seqv':
            return (((self.sxx-self.syy)**2 +
                 (self.syy-self.szz)**2 +
                 (self.szz-self.sxx)**2 +
                 6 * (self.sxy**2 + self.syz**2 + self.sxz**2))/2)**0.5
        elif label.lower() in ['s1', 's2', 's3']:
            return self.apply(principal, axis=1, label=label.lower())
    
    def write_cns(self,cns_file):
        """
        Function to write the current CNS object into a file
        
        Parameters
        ----------
        cns_file: The path to the CNS file to read
        """
        with open(cns_file, "w") as outf:
            outf.write("{}\n".format("*"*20))
            outf.write("Generated at {1} by {0}.\n".format(getuser(), datetime.datetime.now()))            
            if self.cns_file:
                outf.write("CNS file originated from {}\n".format(self.cns_file))            
            outf.write("{}\n".format("*"*20))
            
            message = ("File created by CNSClass Module from gknlib\n"
                    "rst file:\n"
                    "db file :\n"
                    "NUMBER OF NODES   ={:7d}\n"
                    "NUMBER OF L.STEPS ={:7d}\n").format(
                        len(self.nodes()),
                        len(self.timepoints())
                )
            outf.write(message)
            column_header = "".join(['   {:12}'.format(item) for item in self.columns]) +\
                            '   {}'.format("time") + "\n"
            column_header = column_header.upper() 
            curnode = 0
            for node in self.nodes():
                outf.write("NODE NO.          =" + '{:9d}'.format(int(node)) + "\n")
                outf.write(column_header)
                for index,row in self.loc[node,:].iterrows():
                    outf.write("".join(['  {: 1.6E}'.format(item) for item in row]) +\
                               '  {:1.7E}'.format(index) + "\n")    

    def to_pwlife(self, config_list, run_path):
        """
        Function to convert cns dataframe to a pwlife dataframe
        
        This function will convert a CNS object into a corresponding PWLife
        object. Internally, it runs the system command cns2pwlife. The function
        takes two arguments, a config_list and run_path. Details about the parameters
        are described below. 
        
        Parameters
        ----------
        config_list : A list of config items which has to be fed to the cns2pwlife 
                      command. In command line, the config items are given as a newline 
                      separated text file.
        run_path    : The folder in which the intermediate files will be created
                      and cns2pwlife will be run. You can later inspect the files
                      in this folder.
        """
        if config_list is None:
            raise ValueError("config_list is empty. cns2pwlife cannot work with\
                    an empty config data")
        if not os.path.exists(run_path):
            raise OSError("Given run_path {} is not existing".format(run_path))
        print("Writing CNS file...")
        self.write_cns(os.path.join(run_path, "cnsfile.cns"))
        print("Writing config file...")
        with open(os.path.join(run_path, "config_input.txt"), "w") as conf:
            conf.write("\n".join(config_list))
        os.chdir(run_path)
        print("Running cns2pwlife...")
        out_put = subprocess.check_output(["cns2pwlife",
                                 "-i","config_input.txt",
                                 "-c","cnsfile.cns",
                                 "-o","pwlife"])
        #print(out_put)
        if not os.path.exists("pwlife.csv"):
            raise OSError("The cns2pwlife run was not succesful")
        print("Reading PWLife input")
        return read_pwlife("pwlife.csv","pwlife.nod")


def generate_random_cns(nodes=None, time=None):
    import random

    if nodes is None:
        nodes = 50
    if time is None:
        time = 50        
    columns = ["NodeID","time","sxx","syy","szz","sxy","syz","sxz","temp"]
    data = []
    for node in range(nodes):
        node_id = node+1
        for time_point in range(time):
            time_point = time_point+1.0
            sxx = random.randint(500,10000)+random.random()
            syy = random.randint(500,10000)+random.random()
            szz = random.randint(500,10000)+random.random()
            sxy = random.randint(500,10000)+random.random()
            syz = random.randint(500,10000)+random.random()
            sxz = random.randint(500,10000)+random.random()
            temp = random.random()*500+500
            row = [node_id, time_point, sxx, syy, szz, sxy, syz, sxz, temp]
            data.append(row)
    cns_obj = CNS(data,columns=columns)
    cns_obj.set_index(["NodeID", "time"], inplace=True)
    return cns_obj

def read_cns(cns_file, no_of_nodes=None):    
    """
    Function to load a cns file.
    ---
    
    Parameters
    ---
    cns_file = absolute path to a cns file. 
            Note: Code doesn't need to be run from the same directory.
    
    no_of_nodes = implementation of Pandas' chunksize parameter but in node selection form. 
                  [Not yet implemented.]
    """
    node_matrix = []
    node_number = None
    with open(cns_file, "r") as contents:
        for line in contents:
            stripped_line = line.lower().strip()
            if "NODE NO." in line.upper():
                node_number = int(stripped_line[stripped_line.find(" = "):][3:])
            else:
                line_items = line.lower().strip().split()
                if node_matrix == [] and node_number is not None:
                    node_matrix = [["NodeID"] + line_items]
                elif node_number is not None:
                    try:
                        line_as_floats = [float(item) for item in line_items]
                        row = [node_number] + line_as_floats
                        node_matrix.append(row)
                    except ValueError:
                        pass
    new_cns = CNS(node_matrix[1:],columns=node_matrix[0])
    new_cns.cns_file = cns_file
    new_cns.set_index(["NodeID", "time"], inplace=True)
    return new_cns

def principal(s, label):
    """
    Function to return a principal stress based on the label.
    This function is meant to be used with the dataframe.apply function.
    s should be a pandas series object with all the stress components.
    ---
    
    Usage: cns_df.apply(principal, axis=1, label= "s1" | "s2" | "s3")
    
    ---
    
    Parameters
    ---
    
    label : The label for principal stress; 's1', 's2' or 's3'
    """
    import numpy as np
    from gknexceptions.invalidinputerror import InvalidInputError
    principals = np.linalg.eigvals(np.array(
        [s.sxx, s.sxy, s.sxz, s.sxy, s.syy, s.syz, s.sxz, s.syz, s.szz]).reshape(3,3))
    if label.lower() == 's1':
        return principals[0]
    elif label.lower() == 's2':
        return principals[1]
    elif label.lower() == 's3':
        return principals[2]
    else:
        raise InvalidInputError("Invalid Input, choose from s1, s2, or s3.")

if __name__ == "__main__":
    pass
