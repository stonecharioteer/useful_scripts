# GKN Linux Utils

---

This repository contains useful scripts and tools that help Linux Users in GKN.
Scripts contained herein should be general, non-project related and useful for anyone on Linux.
Examples are:
    * A script to fix the Firefox crash error.
    * vimrc
    * bashrc
    * cshrc
    * readmes or howtos for general linux users.
    * bash scripts that have nowhere else to go.



