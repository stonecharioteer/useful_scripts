#!/usr/bin/env python3
import os
import glob
if __name__ == "__main__":
    firefox_lock_files = glob.glob(os.path.abspath("~/.mozilla/firefox/*.default/.parentlock"))
    if len(firefox_lock_files)>0:
        firefox_lock_file = firefox_lock_files[0]
        if os.path.exists(firefox_lock_file):
            os.remove(firefox_lock_file)
