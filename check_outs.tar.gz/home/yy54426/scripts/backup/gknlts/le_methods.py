#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
# LTS Specific Methods.

---

"""


def parse_las_results(results_folder_path):
    """Function to parse the html file and return dataframes.

    Args:
        results_folder_path: Path to a folder containing results.html.

    Returns
        List of dataframes.
    """
    import pandas as pd
    import os
    results_html = os.path.join(results_folder_path, "results.html")
    if not os.path.isfile(results_html):
        raise Exception(("Cannot find results.html in {}"
                         "This looks like an incomplete"
                         " run.").format(results_folder_path))
    else:
        results = pd.read_html(results_html)
        run_data = results[0].transpose()
        run_data.columns = list(run_data.loc[0, :])
        run_data = run_data[1:].copy()
        run_results = results[1]
        run_results.columns = list(run_results.loc[0, :])
        run_results = run_results[1:].copy()
        for column in run_results.columns:
            try:
                run_results[column] = pd.to_numeric(run_results[column])
            except ValueError:
                pass

        if len(results) == 3:
            mix_results = results[2]
            mix_results.columns = list(mix_results.loc[0, :])
            mix_results = mix_results[1:].copy()
            for column in mix_results.columns:
                try:
                    mix_results[column] = pd.to_numeric(mix_results[column])
                except ValueError:
                    pass
            return [run_data, run_results, mix_results]
        else:
            return [run_data, run_results]


def get_sub_folders(folder_path):
    import os
    folders = [x for x in os.listdir(results_folder_path) if (os.path.isdir(os.path.join(results_folder_path, x)) and x != ".AppleDouble")]
    return sorted(folders)


def get_area_xml(release_state, config, path_to_input):
    from .areaparser import Area
    import os
    xml_path = os.path.join(path_to_input, release_state, "rm12", "config",config,"area.xml")
    area = Area(xml_path)
    return area

