#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 13:52:04 2017

@author: yy54426
"""

import pandas as pd

def get_ansys_license_info():
    """Returns licenses in use.

    """
    info_list = pd.read_html(
            "http://inblrxa88/license_current/ansysblr2.shtml"
            )
    license_info = []
    for df in info_list:
        license_type = df[0][0]
        status = df[1][0]
        users = df[1:]
        license_dict = {
                "license": license_type,
                "status": status,
                "users": users
                    }
        license_info.append(license_dict)
    return license_info
