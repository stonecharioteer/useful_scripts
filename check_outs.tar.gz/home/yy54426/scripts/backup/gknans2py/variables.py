""" Ansys variables to python

This module helps to convert ansys parameter files to python.

Use the class AsnysVars to convert ansys parameter file to python object
"""

__all__ = ['AnsysVars']
__version__ = '0.1'
__author__ = "Najeem Muhammed"

import numpy as np

class AnsysVars:
    """ AnsysVars

    Convert ansys parameter file in to python variables.

    To write a parameter file from ansys, use the command
    parsav,all,ansvariables,par

    You can read this file in to python using the class contructor AnsysVars
    example:
        m = AnsysVars("ansvariables.par")

    Now, all variales which were available in the ansys parameter file
    will be available in python under the namespace 'm'

    For example:
        If pth_model was a string variable inside ansys, then the same will be
        accessible using m.pth_model.

    All string variables will be available as str in python
    All scalars in ansys will be floats/strings in python
    All arrays in ansys will be numpy arrays in python

    """
    
    def __init__(self,ansparfile):
        """ Initializing the AnsysVars object with a path to the par file """
        self.__vardict = {} # Dicitonary that will store the ansys parameters
        with open(ansparfile,"r") as f:
            for line in f:
                # The function expects ansys parameters to be initialized using *dim first
                # Value assignment for arrays will contain parenthesis which are replaced by
                # ',' so that its easier to parse the line
                varline = [i.strip() for i in line.replace("(",",")
                        .replace(")","").lower().split(",")]
                # Handling 'array' data type. Empty numpy array is defined for every array
                if all([x in varline for x in ["*dim", "array"]]):
                    self.__vardict[varline[1]] = np.zeros(
                            [int(varline[3]),int(varline[4]),int(varline[5])])
                # Handling 'char' data type.
                elif all([x in varline for x in ["*dim", "char"]]):
                    self.__vardict[varline[1]] = np.empty(
                            [int(varline[3]),int(varline[4]),int(varline[5])], dtype=object)
                # Handling 'string' data type. The first dimension is ignored as string length
                # need not be defined in python
                elif all([x in varline for x in ["*dim", "string"]]):
                    self.__vardict[varline[1]] = np.empty(
                            [1, int(varline[4]),int(varline[5])], dtype=object)
                elif "*set" in varline:
                    # Setting scalar values
                    if len(varline) == 3:
                        self.__vardict[varline[1]] = eval(varline[2])
                    elif len(varline) == 6:
                        # Setting strings, chars and arrays
                        if varline[1] in self.__vardict.keys():
                            self.__vardict[varline[1]]\
                                    [int(varline[2])-1][int(varline[3])-1][int(varline[4])-1] \
                                    = eval(varline[5])
                        else:
                            # If the array item is not defined using *dim, they are skipped
                            # Less likely to happen if the parameter file has been written directly in ansys
                            # But if the file has been modified manually, some *dim definisions may be skipped
                            print("Skipping {} as the *dim definition not found".format(varline[1]))
        # Storing all variable names read from ansys in a list
        self.ansvars = list(self.__vardict.keys()) 
        # Some of the arrays created may have dimensions which are not required
        # These can be 'squeezed' out using np.squeeze function
        for key in self.__vardict.keys():
            try:
                self.__vardict[key] = self.__vardict[key].squeeze()
                if self.__vardict[key].size == 1:
                # If the array is having only single element, then dont remove the list
                    self.__vardict[key] = self.__vardict[key].item()
            except AttributeError:
                pass

    def __getattr__(self,attr):
        """
        Modifying the __getattr__ funciton so that parameters are
        accessible using 'dot' notation
        """
        return self.__vardict[attr]
