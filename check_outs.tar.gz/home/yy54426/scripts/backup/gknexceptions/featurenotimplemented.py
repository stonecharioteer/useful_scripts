#!/usrbinenv python3
"""
Custom Exception
Defines the FeatureNotImplementedError exception. 
This should be raised whenever a particular feature hasn't been implemented.
"""

class FeatureNotImplementedError(Exception):
	"""This error is raised when the code is acalling a feature that has yet to be implemented."""
	pass