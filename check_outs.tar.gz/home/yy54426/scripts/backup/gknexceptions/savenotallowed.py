#!/usr/bin/env python3
class SaveNotAllowedError(Exception):
	pass