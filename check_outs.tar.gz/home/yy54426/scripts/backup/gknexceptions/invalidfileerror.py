class InvalidFileError(Exception):
    pass