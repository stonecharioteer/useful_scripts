#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 12 09:45:46 2017

@author: yy54426
"""


class IncompatibleOSError(Exception):
    """Raised whenever the method isn't supported for the current OS.
    """
    def __init__(self, *args, **kwargs):
        super().__init__()
