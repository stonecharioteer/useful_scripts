#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""Run Script for the HPCMonApplication

  platform: Unix (Server + ), Windows.
.. moduleauthor:: Vinay Keerthi (yy54426)
    <VinayKeerthi.KrishnapuramTirumala@gknaerospace.com>
"""
import os
import argparse

from gknqtwidgets import TableWidget


from hpcjobmon import run_hpcjobmon


def main():
    if os.name == "posix":
        server_id = "a"
        #  start_server()
    else:
        server_id = None
    parser = argparse.ArgumentParser()

    help_string = ("List of input files to "
                   "the hpcjobmon application. "
                   "Optional.")
    parser.add_argument("-i", "-inp", help=help_string)
    input_files = parser.parse_args().i
    run_hpcjobmon(server_id, input_files)

if __name__ == "__main__":
    main()
