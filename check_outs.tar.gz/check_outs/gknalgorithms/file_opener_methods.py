#!/usr/bin/env python3
"""Module which contains common file opening operations."""
import os

def get_all_encodings():
    """Returns a list of all available encodings."""
    import encodings
    import pkgutil
    modnames = set(
        [modname for importer, modname, ispkg in pkgutil.walk_packages(
            path=[os.path.dirname(encodings.__file__)], prefix='')])
    aliases = set(encodings.aliases.aliases.values())
    return sorted(modnames.union(aliases))

def get_file_as_list_using_any_encoding(path_to_file):
    """Retrieves the file contents as a list using every possible type of encoding."""
    for encoding_name in get_all_encodings():
        # if encoding_name != "quopri_codec":
        try:
            with open(path_to_file,encoding=encoding_name) as f:
                file_contents = f.readlines()
            #print("*"*200)
            #print(encoding_name)
            #print("*"*200)
            break
        except UnicodeDecodeError as e:
            file_contents = None
            #print(repr(e))
            pass
        except LookupError:
            pass
    return file_contents
