#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""

"""
from . import textprocessing
from . import unix_methods
from . import analysis_methods
from . import file_opener_methods
import os
if os.name == "nt":
    from . import windows_methods

del os
