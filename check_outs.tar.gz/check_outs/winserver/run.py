"""

Windows Job Submission Server Script
---

This script allows users to send commands to their Windows machine using HTTP requests.

API Documentation.

* Route: "/"
    - POST: 
        - args: 
            * cmd='FULL COMMAND STRING WITH ARGUMENTS GOES HERE.'
            * rundir='Windows Compliant Path goes here.'
        - Returns
            * jobid.
        - Writes to 
    - GET:
        - args:
            * jobid
        - Returns:
            * Job status.
                NOTE: All job IDs are kept in the user's linux directory.
                    Stored in text files.
                    TODO: Think about using an sqllite db instead.

* Route: "/jobs"
    - GET
        - Args:
            * jobs=None:
                Returns: List of all running hobs.
            * Jobs=All
                Returns: List of all jobs that ever ran.



Author: Vinay Keerthi K. T. (yy54426)


"""

from http import server
from http.server import HTTPServer, BaseHTTPRequestHandler
import re
import datetime
import os
import json

import pandas as pd

class WinServer(BaseHTTPRequestHandler):
    """Sub classed version of http.server.BaseHTTPRequestHandler
    ---
    This server handler provides a way to run commands on a remote machine over the network.

    """
    def write(self, msg):
        """Writes output REST style in plain text.."""
        self.send_header('Content-Type', 'text/plain')
        self.end_headers()
        self.wfile.write(bytes(msg+"\n", "utf-8"))

    def read_route(self):
        """Returns the flask style route and args dictionary."""
        full_route = self.path.split("/")[1] if (len(self.path.split("/"))>1) else ""

        if "?" in full_route:
            self.route, self.args = full_route.split("?")
            self.args = dict((x.split("=")[0], x.split("=")[1]) for x in self.args.split("&"))
        else:
            self.route = full_route
            self.args = {}

    def do_GET(self):
        """GET request."""
        # self.send_response(200)
        self.write("GET Request")
        self.read_route()
        self.write("Route: /{}".format(self.route))
        if self.route == "":
            self.send_response(200)
            self.write("Running jobs will be printed here.")
        elif self.route == "jobs":
            self.send_response(200)
            self.write("Trying to get {}.".format(self.route))
            for key in self.args.keys():
                self.write("Argument: {}: {}".format(key, self.args.get(key)))
        else:
            self.send_response(404)
            self.write("No page defined for /{} route.".format(self.route))

    def do_POST(self):
        """Method to run the jobs."""
        # self.read_route()
        print("{} Incoming HTTP: {}".format(datetime.datetime.now(), self.path))
        incoming_content_length = int(self.headers["Content-Length"])
        incoming_data_str = self.rfile.read(incoming_content_length).decode("utf-8")
        # if "\\" in incoming_data_str and "\\\\" not in :
        #     incoming_data_str = incoming_data_str.replace("\\","\\\\")
        incoming_data = json.loads(incoming_data_str)
        self.read_route()
        if self.route == "":
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            response = {}
            cmd = incoming_data.get("cmd")
            rundir = incoming_data.get("rundir")
            msg = "Command received: {}.\nRun Directory: {}".format(cmd, rundir)
            response["cmd"] = cmd
            response["rundir"] = rundir
            print("{}, {}".format(datetime.datetime.now(), msg))
            if os.path.exists(rundir):
                #Execute the command.
                original_dir = os.getcwd()
                os.chdir(rundir)
                output = os.popen(cmd).read()
                os.chdir(original_dir)
                msg = "Executed {} in {}.\nOutput Received:\n{}".format(cmd, rundir, output)

                response["output"] = output

                print("{}, {}".format(datetime.datetime.now(), msg))
            else:
                msg = ("{} is not a valid directory. "
                       "The server accepts only {} "
                       "style paths.").format(rundir,
                                            "Windows" if os.name=="nt" else "Linux")
                response["output"] = msg
                print("{}, {}".format(datetime.datetime.now(), msg))
            self.wfile.write(json.dumps(response).encode("utf8"))
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            response = {
                    "output": "Unauthorized path {}.".format(self.path)
                    }
            self.wfile.write(json.dumps(response).encode("utf8"))
        self.end_headers()

            


def run(server_class=server.HTTPServer, handler_class=WinServer):
    server_address = ("", 8000)
    httpd = server_class(server_address, handler_class)
    httpd.serve_forever()

if __name__ == "__main__":
    run()
