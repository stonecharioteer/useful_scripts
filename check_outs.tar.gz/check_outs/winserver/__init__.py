"""

Windows Job Submission Server Script
---

This script allows users to send commands to their Windows machine using HTTP requests.

API Documentation.

* Route: "/"
    - POST: 
        - args: 
            * cmd='FULL COMMAND STRING WITH ARGUMENTS GOES HERE.'
            * rundir='Windows Compliant Path goes here.'
        - Returns
            * jobid.
        - Writes to 
    - GET:
        - args:
            * jobid
        - Returns:
            * Job status.
                NOTE: All job IDs are kept in the user's linux directory.
                    Stored in text files.
                    TODO: Think about using an sqllite db instead.

* Route: "/jobs"
    - GET
        - Args:
            * jobs=None:
                Returns: List of all running hobs.
            * Jobs=All
                Returns: List of all jobs that ever ran.



Author: Vinay Keerthi K. T. (yy54426)


"""