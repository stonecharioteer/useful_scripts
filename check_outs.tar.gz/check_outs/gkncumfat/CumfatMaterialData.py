#!/usr/bin/env python3
"""
Module to parse, convert and set the material data between cumfat versions.
******************This is the D21 File******************
From the Cumfat 5.12 Demo Material File:
        ### ***********************Instruction block*******************************
        ###  This instruction block normally contains data provided by the materials
        ###  data department regarding identification of the material. Such data can
        ###  also be written at the end of this file.

        ###  Write number of temperature values NTA(k), for which E and NY are defined,
        ###  and directly after, these temperatures TVA(1:NTA(k))
        ### ***********************************************************************
        ###  6 296.9 410. 600.58 714.46 790.38 866.31
        ### ***********************************************************************
        ###  Now write the values of the modulus of elasticity E:
        ### ***********************************************************************
        ###  1.178E11 1.120E11 1.062E11 9.653E10 9.267E10 8.881E10
        ### ***********************************************************************
        ###  Next write Poisson ratio NY (lateral contraction):
        ### ***********************************************************************
        ###  0.316 0.322 0.334 0.342 0.348 0.355
        ### ***********************************************************************
        ###  Write number of temperature values NTCA(k), for which the cyclic stress-
        ###  strain-data are given, and directly after the temperatures TCA(1:NTCA(k),k):
        ### ***********************************************************************
        ###  5 296.9 366.3 477.4 533.0 616.3
        ### ***********************************************************************
        ###  Write number of points NCA(k) in the stress-strain tables, directly
        ###  followed by NTCA(k) tables of stress-strain data (SCA, ECA)
        ### ***********************************************************************
        ###  7
        ###     0.0    0.0
        ###   706.7E6  0.006
        ###   779.3E6  0.008
        ###   827.6E6  0.010
        ###   862.1E6  0.012
        ###   896.6E6  0.015
        ###   1200.E6  0.050

        ###      0.0    0.0
        ###   565.5E6  0.005
        ###   689.7E6  0.007
        ###   744.8E6  0.009
        ###   758.6E6  0.010
        ###   793.1E6  0.012
        ###   1040.E6  0.050

        ###      0.0    0.0
        ###   427.6E6  0.004
        ###   496.6E6  0.005
        ###   537.9E6  0.006
        ###   558.6E6  0.007
        ###   579.3E6  0.008
        ###   880.0E6  0.050

        ###      0.0    0.0
        ###   413.8E6  0.004
        ###   482.8E6  0.005
        ###   524.1E6  0.006
        ###   551.7E6  0.007
        ###   593.1E6  0.010
        ###   840.0E6  0.050

        ###      0.0    0.0
        ###   406.9E6  0.004
        ###   475.9E6  0.005
        ###   517.2E6  0.006
        ###   558.6E6  0.008
        ###   586.2E6  0.010
        ###   800.0E6  0.050

        ### ***********************************************************************
        ###  Write the number of temperatures NTLCFA(k) for which there are LCF-data,
        ###  followed directly by the values of the temperatures on the same row.
        ###  On next row, write number of data points in the tables with LCF-data.
        ###  Thereafter, on following rows, the tables with LCF-data are written.
        ###  Finally, on the last row, the LCF_reps value, i.e. the R-value shall be written.
        ### ***********************************************************************
        ### 2 293.5 366.3
        ### 5
        ###  0.046832  1.E2
        ###  0.022104  1.E3
        ###  0.010947  1.E4
        ###  0.006404  1.E5
        ###  0.004367  1.E6

        ###  0.046832  1.E2
        ###  0.022104  1.E3
        ###  0.010947  1.E4
        ###  0.006404  1.E5
        ###  0.004367  1.E6

        ###  0.0

Contact yy54426 - Vinay Keerthi K. T. for assistance.
"""
import sys
import os
import glob
import pandas as pd


from gknexceptions import (InsufficientData, InvalidInput, CumfatLimitation)

from gknalgorithms.file_opener_methods import get_file_as_list_using_any_encoding

from gknalgorithms import textprocessing

class CumfatMaterialData:
    """
    CumfatMaterialData class.
        This module contains the class definition for the CumfatMaterialData class.
        It offers parsing methods, creation methods and it can retrieve associated
        attributes as well.
        This is the .d21 file.
    """
    def __init__(self, file_path=None, version=None, material_data=None):
        """Initializer method."""
        if version is None:
            self.set_default_version()
        else:
            self.set_version(version)
        cumfat_5_12_material_file_parameters = [
                                                #number of temperature values NTA(k), for which E and NY are defined
                                                "ntva",  #Single integer
                                                #these temperatures TVA(1:NTA(k))
                                                "tva",  #Space separated list of floating point temperature values.
                                                #the values of the modulus of elasticity E
                                                "ea",  #Space separated floating point values of Young's modulus E.0
                                                #Poisson ratio NY (lateral contraction)
                                                "nya", #Space separated floating point values, none greater than 1.
                                                #number of temperature values NTCA(k), for which the cyclic stress-strain-data are given
                                                "ntca",  #Single integer
                                                #These temparature values.
                                                "tca",  #Space separated list of floating point temperature values.
                                                #number of points NCA(k) in the stress-strain tables
                                                "nca",  #Single integer
                                                #tables of stress-strain data (SCA, ECA)
                                                "sca_eca_tables", #List of lists. Each sublist has nca items. (see above).
                                                                #Each item in this sublist has 2 values, both floating point values, separated by a space
                                                                #Each sublist is separated by an empty line
                                                #number of temperatures NTLCFA(k) for which there are LCF-data
                                                "ntlcfa",  #Single integer
                                                #the values of the temperatures
                                                "tlcfa",  #Space separated list of floating point temperature values.
                                                #number of data points in the tables with LCF-data
                                                "nlcfa",  #Single integer.
                                                #the tables with LCF-data
                                                "lcf_tables",  #List of lists. Each sublist has nlcfa items. (see above)
                                                            #Each item in that sublist has 2 items,
                                                            #one floating point, and one scientifically notated value.
                                                #the LCF_reps value, i.e. the R-value
                                                "lcf_reps" #Single floating point value. Usually 0.0(?) #TODO: Check with Eva/Magnus/Google.
                                                ]
        cumfat_7_specific_parameters = [
                                        "olcf",  # Upgraded NCUR from the method file.
                                        "ocreep",  # Boolean to use creep or not.
                                        "nplma", # Required only if ocreep is 1
                                        "creep_sig_plm_table",  # Required only if ocreep is 1
                                        "creep_va", # Required only if ocreep is 1
                                        "creep_tr",  # Required only if ocreep is 1
                                        "creep_min_t",  # Required only if ocreep is 1
                                        "creep_max_t"  # Required only if ocreep is 1
                                        ]
        cumfat_7_1_material_file_parameters = cumfat_5_12_material_file_parameters + cumfat_7_specific_parameters

        self.parameters = {
                        5.12: dict((key, None) for key in cumfat_5_12_material_file_parameters),
                        7.1: dict((key, None) for key in cumfat_7_1_material_file_parameters)
                        }
        if file_path is None and material_data is None:
            raise InsufficientData
        else:
            if file_path is not None:
                self.parse_from_file(file_path, version)

    def __str__(self):
        """Need to parse data and print it in a nice and readable format."""
        return str(self.parameters)

    def __repr__(self):
        """Class representation."""
        return ("CumfatMaterialData Object from data in %s"%self.file_path)

    def parse_from_file(self, file_path, version=None):
        """parser method.
        This method is used to read a d21 file,
        and gather the attributes for the material data from it.
        """
        if version is None:
            self.set_default_version()
        else:
            self.set_version(version)

        if not(os.path.isfile(file_path)):
            raise FileNotFoundError
        else:
            self.file_path = file_path
            file_contents = get_file_as_list_using_any_encoding(self.file_path)
            #Loop through the file contents,
            #Set initial parameters to None. This allows us to avoid booleans to check the mode.

            self.olcf = None #7.10 parameter.
            self.ocreep = None #7.10 parameter.

            self.ntva = None
            self.tva = None

            self.ea = None

            self.nya = None

            self.ntca = None
            self.tca = None

            self.nca = None #7.10 parameter.
            self.sca_eca_tables = None

            self.ntlcfa = None
            self.tlcfa = None
            self.nlcfa = None
            self.lcf_tables = None
            self.lcf_reps = None

            self.nplma = None
            self.creep_sig_plm_table = None
            self.creep_va = None
            self.creep_tr = None
            self.creep_min_t = None
            self.creep_max_t = None

            #Find the ++++++++++ block, and get the values.
            cumfat_7_block_positions = textprocessing.get_matching_positions(file_contents,"+"*10, exact_match=False)

            if (cumfat_7_block_positions is not None) and (len(cumfat_7_block_positions) >=2):
                cumfat_7_block_start_index, cumfat_7_block_stop_index = cumfat_7_block_positions
                cumfat_7_block = file_contents[(cumfat_7_block_start_index+1):(cumfat_7_block_stop_index-1)]
                cumfat_7_options_list = cumfat_7_block.split()
                if len(cumfat_7_options_list) == 2:
                    try:
                        self.olcf, self.ocreep = [int(x) for x in cumfat_7_options_list]
                    except ValueError:
                        raise InvalidInput((("Erroneous value is stored in the material file (%s)for OLCF "%(file_path)),
                                            "and OCREEP. Values should be integers, ",
                                            "but %s has been found while parsing."%(str(cumfat_7_options_list))))
                else:
                    raise InvalidInput(("The material file (%s) doesn't have sufficient values for "%(file_path),
                                        "the Cumfat 7 OLCF and OCREEP block. Expected 2 integer values, found %s."%str(cumfat_7_options_list)))
            #Parse the
            #Find the ********** blocks and get the values.
            cumfat_block_positions = textprocessing.get_matching_positions(file_contents, "*"*10, exact_match=False)
            if not ((cumfat_block_positions is not None) and (len(cumfat_block_positions)==12)):
                raise InvalidInput("The given material file (%s) is invalid."%self.file_path)
            else:
                #First comes the TVA block
                tva_block_start_index, tva_block_stop_index = cumfat_block_positions[1:3]
                tva_block_start_index +=1
                #tva_block_stop_index = (tva_block_stop_index-1)
                tva_block = file_contents[tva_block_start_index:tva_block_stop_index]
                tva_block_contents = tva_block[0].split()
                try:
                    self.ntva = int(tva_block_contents[0])
                except:
                    raise InvalidInput(("Expected an integer in the TVA block ",
                                        "for NTVA in the material data file (%s). "%file_path,
                                        "Found %s."%str(tva_block_contents[0])))
                if len(tva_block_contents[1:]) == self.ntva:
                    try:
                        self.tva = [float(x) for x in tva_block_contents[1:]]
                    except ValueError:
                        raise InvalidInput(("Expected a list of floating point numbers in the TVA ",
                                            "block corresponding to NTVA=%s "%self.ntva,
                                            "in the material file (%s). Found %s."%(file_path, tva_block_contents[1:]))
                                            )
                else:
                    raise InvalidInput(("Expected %d floating point values in the TVA "%self.ntva,
                                        "block of the material file (%s). "%file_path,
                                        "Found %s instead."%str(tva_block_contents[1:])))

                #Then follows the EA block.
                ea_block_start_index, ea_block_stop_index = cumfat_block_positions[3:5]
                ea_block_start_index += 1
                ea_block = file_contents[ea_block_start_index:ea_block_stop_index]
                ea_block_contents = ea_block[0].split()
                if len(ea_block_contents) == self.ntva:
                    try:
                        self.ea = [float(x) for x in ea_block_contents]
                    except ValueError:
                        raise InvalidInput("Expected %d floating point values for EA ",
                                                    "in the material file (%s). ",
                                                    "Found %s instead."%(self.ntva, file_path, str(ea_block)))
                else:
                    raise InvalidInput(("Expected %d floating point values for EA in the "%self.ntva,
                                        "material file (%s). Found %s instead."%(file_path, str(ea_block))))

                #Then comes the NYA block.
                nya_block_start_index, nya_block_stop_index = cumfat_block_positions[5:7]
                nya_block_start_index += 1
                nya_block = file_contents[nya_block_start_index:nya_block_stop_index]
                nya_block_contents = nya_block[0].split()
                if len(nya_block_contents) == self.ntva:
                    try:
                        self.nya = [float(x) for x in nya_block_contents]
                    except ValueError:
                        raise InvalidInput("Expected %d floating point values corresponding to the NYA variable in the material file (%s). Found %s instead."%(self.ntva, file_path, str(nya_block_contents)))
                else:
                    raise InvalidInput("Expected %d floating point values corresponding to the NYA variable in the material file (%s). Found %s instead."%(self.ntva, file_path, str(nya_block_contents)))

                #Then follows the NTCA and TCA block.
                tca_block_start_index, tca_block_stop_index = cumfat_block_positions[7:9]
                tca_block_start_index += 1
                tca_block = file_contents[tca_block_start_index:tca_block_stop_index]
                tca_block_contents = tca_block[0].split()
                try:
                    self.ntca = int(tca_block_contents[0])
                except ValueError:
                    raise InvalidInput("Expected an integer value for NTCA in the material data file (%s). Found %s instead."%(file_path, tca_block_contents[0]))
                tca_sublist = tca_block_contents[1:]
                if len(tca_sublist) == self.ntca :
                    try:
                        self.tca = [float(x) for x in tca_sublist]
                    except ValueError:
                        raise InvalidInput("Expected %d floating point values for tca in the material data file (%s). Found %s instead,"%(self.ntca, file_path, tca_sublist))
                    if self.tca != sorted(self.tca):
                        raise InvalidInput(("The tca values should be sorted in the ascending order ",
                                        "in the material data file (%s). Found them in the following order: %s.")%(file_path, self.tca))
                else:
                    error_message = (
                                    "Insufficient values for tca. "
                                    "Expected %d values in the material data "
                                    "file (%s). Found %s instead."
                                    )%(self.tca, file_path, tca_sublist)
                    raise InvalidInput(error_message)

                #Then follows the nva and the stress-strain tables.
                nca_stress_tables_block_start_index, nca_stress_tables_block_stop_index = cumfat_block_positions[9:11]
                nca_stress_tables_block_start_index += 1
                nca_stress_tables_block = "\n".join(file_contents[nca_stress_tables_block_start_index:nca_stress_tables_block_stop_index])

                nca_stress_tables_block_contents = [x for x in nca_stress_tables_block.split("\n") if x.strip() != ""]
                try:
                    self.nca = int(nca_stress_tables_block_contents[0].strip())
                except ValueError:
                    raise InvalidInput(("Expected an integer value for NVA in the material file (%s). Found %s instead."%(file_path, nca_stress_tables_block_contents[0])))
                sca_eca_tables_segment = nca_stress_tables_block_contents[1:]
                points_in_sca_eca_table = len(sca_eca_tables_segment)
                expected_number_of_points = self.nca*self.ntca
                if points_in_sca_eca_table != expected_number_of_points:
                    error_message = (
                                    "The material data file was expected to have %d "
                                    "stress-strain tables, each with %d points, "
                                    "and a total of %d points. However, "
                                    " %d points were found."
                                    )
                    raise InvalidInput(error_message%(self.ntca, self.nca, expected_number_of_points, points_in_sca_eca_table))
                else:
                    self.sca_eca_tables = []
                    for i in range(self.ntca):
                        sca_eca_table_start_index = i*self.nca
                        sca_eca_table_stop_index = (i+1)*self.nca
                        sca_eca_table = [[float(x.split()[0]),float(x.split()[1])] for x in sca_eca_tables_segment[sca_eca_table_start_index:sca_eca_table_stop_index]]
                        self.sca_eca_tables.append(sca_eca_table)
                #Then follows the LCF block.
                #This block can change depending on the value of the OLCF parameter.
                #It formerly depended on the NCUR variable.
                #This has several possible formats.
                lcf_block_start_index= cumfat_block_positions[11]
                lcf_block_start_index += 1
                lcf_block = "\n".join(file_contents[lcf_block_start_index:])
                #print(lcf_block)
                lcf_block_cleaned = [x for x in lcf_block.split("\n") if x.strip() != ""]
                ntlcfa_row = lcf_block_cleaned[0]
                ntlcfa_contents_list = ntlcfa_row.split()
                try:
                    self.ntlcfa = int(ntlcfa_contents_list[0])
                except ValueError:
                    error_message = (
                                    "Expected an integer value for ntlcfa in the "
                                    "material data file (%s). Found %s instead."
                                )%(file_path, ntlcfa_contents_list[0])
                    raise InputError(error_message)
                tlcfa_array = ntlcfa_contents_list[1:]
                if len(tlcfa_array) == self.ntlcfa:
                    try:
                        self.tlcfa = [float(x) for x in tlcfa_array]
                    except ValueError:
                        raise InvalidInput(("Expected a list of %d floating point values for "%self.ntlcfa,
                            "tlcfa in the material data file (%s). "%file_path,
                            "Found %s instead."%tlcfa_array))
                else:
                    raise InvalidInput(("Expected a list of %d floating point values for ",
                        "tlcfa in the material data file (%s). Found %s instead.")%(self.ntlcfa, file_path, tlcfa_array))
                #NLCFA subblock
                self.nlcfa = int(lcf_block_cleaned[1])
                self.lcf_tables = []
                for i in range(self.ntlcfa):
                    lcf_table_start_index = 2 + i*self.nlcfa
                    lcf_table_stop_index = 2 + (i+1)*self.nlcfa

                    lcf_table = [[float(x.split()[0]), float(x.split()[1])] for x in lcf_block_cleaned[lcf_table_start_index:lcf_table_stop_index]]
                    self.lcf_tables.append(lcf_table)
                self.lcf_reps = float(lcf_block_cleaned[-1])

                # #TODO: NEED TO PARSE THE CREEP DATA BLOCK.
                #Creep block is for the 7.1 edition. Required only if ocreep is 1.
                # #Creep Data block.
                # #Again, this depends upon the OCREEP data parsed from the Cumfat7.1.0 block coded above.
                # #There is no stop index, the file ends without a block of ****
                # creep_block_start_index = cumfat_block_positions[13]+1
                # creep_block = file_contents[creep_block_start_index+1:]
                # creep_block_contents = creep_block.split()
                # #The first possibility corresponds to the Larson-Miller parameter.
                # if self.ocreep == 1:
                #     self.nplma = int(creep_block_contents[0])
                #     self.creep_sig_plm_table = [float(y) for y in x.split() for x in creep_block_contents[1:self.nplma]]
                #     creep_va_tr_segment = creep_block_contents[self.nplma+1].split()
                #     self.creep_va = float(creep_va_tr_segment[0])
                #     self.creep_tr = float(creep_va_tr_segment[1])
                #     creep_mix_max_t_segment = creep_block_contents[self.nplma+2].split()
                #     self.creep_min_t = float(creep_mix_max_t_segment[0])
                #     self.creep_max_t = float(creep_mix_max_t_segment[1])

            if self.version == 5.12:
                self.parameters[self.version] = {
                                "ntva": self.ntva,
                                "tva": self.tva,
                                "ea": self.ea,
                                "nya": self.nya,
                                "ntca": self.ntca,
                                "tca": self.tca,
                                "nca": self.nca,
                                "sca_eca_tables": self.sca_eca_tables,
                                "ntlcfa": self.ntlcfa,
                                "tlcfa": self.tlcfa,
                                "nlcfa": self.nlcfa,
                                "lcf_tables": self.lcf_tables,
                                "lcf_reps": self.lcf_reps
                                # "olcf": self.olcf,
                                # "ocreep": self.ocreep,
                                # "nplma": self.nplma,
                                # "creep_sig_plm_table": self.creep_sig_plm_table,
                                # "creep_va": self.creep_va,
                                # "creep_tr": self.creep_tr,
                                # "creep_min_t": self.creep_min_t,
                                # "creep_max_t": self.creep_max_t
                            }
            elif self.version == 7.1:
                self.parameters[self.version] = {
                                "olcf": self.olcf,
                                "ocreep": self.ocreep,
                                "ntva": self.ntva,
                                "tva": self.tva,
                                "ea": self.ea,
                                "nya": self.nya,
                                "ntca": self.ntca,
                                "tca": self.tca,
                                "nca": self.nca,
                                "sca_eca_tables": self.sca_eca_tables,
                                "ntlcfa": self.ntlcfa,
                                "tlcfa": self.tlcfa,
                                "nlcfa": self.nlcfa,
                                "lcf_tables": self.lcf_tables,
                                "lcf_reps": self.lcf_reps,
                                "nplma": self.nplma,
                                "creep_sig_plm_table": self.creep_sig_plm_table,
                                "creep_va": self.creep_va,
                                "creep_tr": self.creep_tr,
                                "creep_min_t": self.creep_min_t,
                                "creep_max_t": self.creep_max_t
                            }

    def update(self, version, **kwargs):
        """This method is used to update the parameters between versions.
        TODO: Need to add format validation here.
        The inputs need to be in a specific format as well, so need to check that,
        TODO: Need to check the values as well."""
        self.set_version(version)
        version_specific_keys = ["ntva", "tva", "ea", "nya",
                                "ntca", "tca", "nca", "sca_eca_tables",
                                "ntlcfa", "tlcfa", "nlcfa", "lcf_tables", "lcf_reps"]
        if self.version == 7.1:
            version_specific_keys.extend(["olcf", "ocreep", "nplma",
                                        "creep_sig_plm_table", "creep_va","creep_tr",
                                        "creep_min_t", "creep_max_t"])
        for key in version_specific_keys:
            if kwargs.get(key) is not None:
                self.parameters[self.version][key] = kwargs.get(key)
        empty_keys = [key for key in version_specific_keys if self.parameters[self.version][key] is None]
        for key in empty_keys:
            self.parameters[self.version][key] = self.parameters[self.get_alternate_version()].get(key)

    def save_to_file(self, file_path, version=None, **kwargs):
        """File dumping method.
        This method needs to be able to handle upgradation of data and validation
        of the inputs.
        The kwargs should provide missing data in an appropriate format for
        the code to handle the saving."""
        if version is None:
            self.set_default_version()
        else:
            self.set_version(version)
        #First, validate the parameters to see if they are valid.
        #Existence validation.
        allow_save = False
        parameters_for_required_version = self.parameters.get(self.version)
        if parameters_for_required_version is None:
            raise InsufficientData(("There is no version %s compliant information. "%self.version,
                                    "If you're trying to convert between versions, ",
                                    "ensure you have written a conversion step."))
        else:
            empty_entries = [key for key in parameters_for_required_version.keys() if parameters_for_required_version[key] is None]
            if self.version == 5.12 and len(empty_entries) >0:
                raise InsufficientData("%s cannot be empty while saving the material file."%str(empty_entries))
            else:
                if self.version == 7.1 and self.parameters[self.version]["ocreep"] == 0:
                    creep_specific_keys = ["nplma","creep_sig_plm_table","creep_va",
                                            "creep_tr","creep_min_t","creep_max_t"]
                    if sorted(empty_entries) != sorted([creep_specific_keys]):
                        raise InsufficientData("%s cannot be empty while saving the material file."%str(empty_entries))
                    else:
                        allow_save = True
                        #print("It is possible to save data in %s material data format."%self.version)
                else:
                    allow_save = True
                    #print("It is possible to save data in %s material data format."%self.version)
                #Check for agreement and rules.
                #Need to note down version-specific rules.
        if allow_save:
            template = get_cumfat_material_template(self.version)
            formatted_parameters_dictionary = self.get_formatted_parameters_dictionary(version)
            with open(file_path, mode="wt", encoding="utf-8") as f:
                f.write(template.format_map(formatted_parameters_dictionary))

    def get_formatted_parameters_dictionary(self, version):
        """This method is used when saving the file.
        It returns the parameters dictionary in a formatted version,
        for direct dumping into a file."""
        formatted_dictionary = None
        parameters_dictionary = self.parameters[version]

        nca = parameters_dictionary["nca"]
        sca_eca_tables = parameters_dictionary["sca_eca_tables"]
        temperature_counter = len(sca_eca_tables)
        formatted_sca_eca_tables = ""
        table_counter = 0
        for sca_eca_table in sca_eca_tables:
            counter = 0
            for item in sca_eca_table:
                formatted_sca_eca_tables = formatted_sca_eca_tables + "%e %e"%(item[0],item[1]) + "\n"
                counter+=1
                if counter == nca:
                    counter = 0
                    table_counter +=1
                    if table_counter < temperature_counter:
                        formatted_sca_eca_tables = formatted_sca_eca_tables + "\n"

        nlcfa = parameters_dictionary["nlcfa"]
        lcf_tables = parameters_dictionary["lcf_tables"]
        formatted_lcf_tables = ""
        temperature_counter = len(lcf_tables)
        table_counter = 0
        for lcfa_table in lcf_tables:
            counter = 0
            for item in lcfa_table:
                formatted_lcf_tables = formatted_lcf_tables + " " + "%e %e"%(item[0],item[1]) + "\n"
                counter += 1
                if counter == nlcfa:
                    counter = 0
                    table_counter += 1
                    if table_counter < temperature_counter:
                        formatted_lcf_tables = formatted_lcf_tables + "\n"
        formatted_dictionary = {
                            "ntva": parameters_dictionary["ntva"],
                            "tva": " ".join([str(x) for x in parameters_dictionary["tva"]]),
                            "ea": " ".join([str(x) for x in parameters_dictionary["ea"]]),
                            "nya": " ".join([str(x) for x in parameters_dictionary["nya"]]),
                            "ntca": parameters_dictionary["ntca"],
                            "tca": " ".join([str(x) for x in parameters_dictionary["tca"]]),
                            "nca": parameters_dictionary["nca"],
                            "sca_eca_tables": formatted_sca_eca_tables,
                            "ntlcfa": parameters_dictionary["ntlcfa"],
                            "tlcfa": " ".join([str(x) for x in parameters_dictionary["tlcfa"]]),
                            "nlcfa": parameters_dictionary["nlcfa"],
                            "lcf_tables": formatted_lcf_tables,
                            "lcf_reps": parameters_dictionary["lcf_reps"]
                    }
        #TODO: CREEP SECTION
        if version == 7.1:
            version_specific_parameters = {
                                "olcf": parameters_dictionary["olcf"],
                                "ocreep": parameters_dictionary["ocreep"]
                                }
            formatted_dictionary.update(version_specific_parameters)
        return formatted_dictionary

    def get_alternate_version(self):
        if self.version == 5.12:
            alternate_version = 7.1
        else:
            alternate_version = 5.12
        return alternate_version

    def set_default_version(self):
        """For now, the default version is 7.1.0"""
        self.set_version(7.1)

    def set_version(self, version):
        self.available_versions = [5.12, 7.1]
        if version in self.available_versions:
            self.version = version
        else:
            raise InvalidInput("""Cumfat version should be one of %s. \"%s\" is unacceptable."""%(str(self.available_versions), version))


def get_cumfat_material_template(version, material_object=None):
    """This method returns the required template for saving the material file."""
    #TODO: modify the template based on the olcf or ocreep value.
    template_7_1 = """***********************Instruction block*******************************
 This is an instruction block. An instruction block starts with a row,
 which in at least in its first positions contains 10 asterisks or
 10 plus signs. It also ends in the same way.
 An instruction block can have any number of rows.
 Data used by CUMFAT must be written in between instruction blocks. The
 purpose of the instruction block is to define what data to be written,
 and thus facilitate for the user.
 Blank rows are allowed in front of an instruction block.

 Now actual instructions are given:
 --------------------------------------------
 This instruction block normally contains data provided by the material
 department regarding identification of the material. Such data can
 also be written at the end of this file.

 All material data are preferably in SI units, Cumfat do not convert any data

 Now material parameters and data are given:
 --------------------------------------------

 Write the parameters OLCF and OCREEP, in that order separated by space

 - OLCF tells how the fatigue data is provided:
   1 = LCF_Table      = Table of (strain-range,life) for one Reps ratio
   2 = BCM_Coeff      = Data are defined by Basquin-Coffin-Manson parameters
                        for Reps = -1
   3 = SWT_Table      = Table of (Smith-Watson-Topper-value,life)
   4 = WES_mRsig_tanh = Data are defined by Walker Effective Stress
                        parameters. The exponent m(R) is expressed as a
                        hyperbolic tangent function, where R is the
                        R-stress ratio.
   5 = WES_mRsig_tab  = Data are defined by Walker Effective Stress
                        parameters. The exponent m(R) is expressed as
                        tabulated values, where R is the R-stress ratio.
   6 = WES_mReps_tab  = Data are defined by Walker Effective Stress
                        parameters. The exponent m(R) is expressed as
                        tabulated values, where R is the R-strain ratio.

 - OCREEP tells if and how creep data are provided:
   0 = no_creep      = No creep data available
   1 = PLM_creep     = Larson-Miller parameter, table of (stress,PLM)

 (The Cumfat70 material data file is build to be backwards compatible to
  Cumfat 50 for the most common cases. The plus signs below instead of
  asterisks will make it possible for Cumfat50 to read the material file.
  Valid for OLCF 1 and 3)
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 {olcf} {ocreep}
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 Write parameters NTVA and TVA on the same row separated by space.

 - NTVA is the number of temperature values for which Young's modulus
   and Poissons ratio are defined. (Minimum number of NTA is 2,
   maximum is 100)

 - TVA is the corresponding temperature vector listed in increasing order.

 NB! The TVA temperature vector must cover the temperatures of available
     LCF material data
***********************************************************************
 {ntva} {tva}
***********************************************************************
 Write the parameters of EA on the same row separated by space.

 - EA are the values of the Young's modulus of elasticity corresponding
   to the above listed temperatures TVA. The temperatures TVA and the
   Young's modulus EA must be listed in the same order.
***********************************************************************
 {ea}
***********************************************************************
 Write the parameters of NYA on the same row separated by space.

 - NYA are the values of the Poisson ratio corresponding to the
   above listed temperatures TVA. The temperatures TVA and the
   Poisson ratio NYA must be listed in the same order.
***********************************************************************
 {nya}
***********************************************************************
 Write the parameters NTCA and TCA on the same row separated by space.

 - NTCA is the number of temperature values for which the stress-strain
   curves are given. (Minimum number of NTCA is 2, maximum is 100)

 - TCA is the corresponding temperature vector. Must be listed in
   increasing order.

 NB! The TCA temperature vector must cover the temperatures of available
     LCF material data
***********************************************************************
 {ntca} {tca}
***********************************************************************
 On the first row write the parameter NCA
 - NCA is the number of points in the stress-strain tables.
   (Minimum number of NCA is 2, maximum is 100)

 Following rows, write the stress-strain table (SCA, ECA) in the same
 order as the corresponding above listed temperatures.
 (Empty rows are allowed between tables)
  - SCA is the stress of the stress-strain material curve
  - ECA is the strain of the stress-strain material curve

 NB! It is important that the fist listed value of each table is (0,0).
     And that second point corresponds to the end of the elastic part.
 NB! It is important that the points listed in stress-strain curves are
     evenly distributed. Cumfat will do a point by point interpolation in
     linear scale to create stress- strain curve for an arbitrary temperature.
***********************************************************************
 {nca}
 {sca_eca_tables}

***********************************************************************
 --------------------------------------------
 LCF Data
 --------------------------------------------
 --------------------------------------------
 This part of the material file differ for different OLCF,
 format of provided fatigue data.

 Here is an example for OLCF = 1, LCF_Table
 Table of strain-range versus life for one R-strain ratio
 --------------------------------------------

 On the first row, write the parameters NTLCFA and TLCFA on the same row
 separated by space.
  - NTLCFA is number of temperature values for which LCF data are defined.
    (Minimum number of NTLCFA is 2, maximum is 100)
  - TLCFA is the corresponding temperature vector. Must be listed in
    increasing order.

 Next row, write the parameter NLCFA.
 (Empty rows are allowed before and after)
  - NLCFA is the number of data points in the LCF tables
    (Minimum number of NLCFA is 2, maximum is 100)

 Following rows, write the LCF tables (LCF_epsRANGE,LCF_N) in the
 same order as the corresponding above listed temperatures.
 (Empty rows are allowed between tables)
  - LCF_epsRANGE, strain range
  - LCF_N,        corresponding life

 NB! It is important that the points listed in strain range- life curves are
     evenly distributed. Cumfat will do a point by point interpolation in
     logarithmic scale to create a LCF curve for an arbitrary temperature.

 Below the LCF tables write LCF_Reps
 (Empty rows are allowed before and after)
  -  LCF_Reps is the R-strain ratio for provided LCF material data.

 NB! It is not possible to provide the program with (strain-range,life) tables
     for stress based R-ratio.
***********************************************************************
{ntlcfa} {tlcfa}

{nlcfa}

{lcf_tables}
 {lcf_reps}
"""
    #TODO: Accomodate alternate values of OLCF. The LCF table portion changes with OLCF value/

    #TODO, INCORPORATE CREEP
    creep="""
***********************************************************************
 --------------------------------------------
 Creep Data
 --------------------------------------------
 --------------------------------------------
 This part of the material file can be omitted if OCREEP is set to 0.

 Here is an example for OCREEP = 1, Larson-Miller Parameter
 PLM=T*(Va+log(tRJ))
 Where PLM is the Larson-Miller parameter, T is the temperature, Va is
 a material parameter and tRJ is the time to failure.
 --------------------------------------------

On the first row, write the parameter NPLMA
    - NPLMA is the number of points in the (stress,PLM) table
     (Minimum number of NPLMA is 2, maximum is 100)

Following rows, write the (CREEP_sig,CREEP_PLM) table
 - CREEP_sig is the stress
 - CREEP_PLM is the corresponding Larson-Miller parameter

Next row, write the parameters CREEP_Va and CREEP_TR
          in that order separated by space
 - CREEP_Va is a material parameter
 - CREEP_TR is a time factor.
            If time t at PLM extraction was in seconds TR=1.0
            If time t at PLM extraction was in minutes TR=60.0
            If time t at PLM extraction was in hours TR=3600.

Next row, write the parameters CREEP_minT and CREEP_maxT
          in that order separated by space
 - CREEP_minT is the minimum tested temperature in the creep material test
 - CREEP_maxT is the maximum tested temperature in the creep material test
***********************************************************************
6
3000.e6 6.e3
800.e6 8.e3
792.e6 10.e3
790.e6 12.e3
610.e6 14.e3
190.e6 16.e3
20.0 3600.0
293.0 366.3


"""
    #TODO: Need to implement saving 5.12 material.
    template_5_12 = """***********************Instruction block*******************************
 This instruction block normally contains data provided by the materials
 data department regarding identification of the material. Such data can
 also be written at the end of this file.

 Write number of temperature values NTA(k), for which E and NY are defined,
 and directly after, these temperatures TVA(1:NTA(k))
***********************************************************************
 {ntva} {tva}
***********************************************************************
 Now write the values of the modulus of elasticity E:
***********************************************************************
 {ea}
***********************************************************************
 Next write Poisson ratio NY (lateral contraction):
***********************************************************************
 {nya}
***********************************************************************
 Write number of temperature values NTCA(k), for which the cyclic stress-
 strain-data are given, and directly after the temperatures TCA(1:NTCA(k),k):
***********************************************************************
 {ntca} {tca}
***********************************************************************
 Write number of points NCA(k) in the stress-strain tables, directly
 followed by NTCA(k) tables of stress-strain data (SCA, ECA)
***********************************************************************
 {nca}
 {sca_eca_tables}

***********************************************************************
 Write the number of temperatures NTLCFA(k) for which there are LCF-data,
 followed directly by the values of the temperatures on the same row.
 On next row, write number of data points in the tables with LCF-data.
 Thereafter, on following rows, the tables with LCF-data are written.
 Finally, on the last row, the LCF_reps value, i.e. the R-value shall be written.
***********************************************************************
{ntlcfa} {tlcfa}
{nlcfa}
 {lcf_tables}

 {lcf_reps}"""
    if version==7.1:
        return template_7_1
    else:
        return template_5_12

if __name__ == "__main__":
    pass