import os
import ipywidgets as widgets
from ipywidgets import VBox, HBox, Text, Button

class FileBrowser(object):
    """FileBrowser

    Provides a file browser object that can be used to select files.

    """

    def __init__(self, colnumber=None, start_path=None, show_hidden=None, show_files=None):
        if colnumber is None:
            self.colnumber = 4
        else:
            self.colnumber = colnumber
        
        if show_files is None:
            self.show_files = True
        else:
            self.show_files = show_files

        if start_path is None:
            self.path = os.getcwd()
        else:
            self.path = start_path

        if show_hidden is None:
            self.show_hidden = False
        else:
            self.show_hidden = True
        self._update_files()
        
    def _update_files(self):
        self.files = list()
        self.dirs = list()
        if(os.path.isdir(self.path)):
            for f in os.listdir(self.path):
                ff = os.path.join(self.path, f)
                #print(ff)
                if os.path.isdir(ff):
                    self.dirs.append(f)
                else:
                    self.files.append(f)
        
    def widget(self):
        box = widgets.VBox()
        self._update(box)        
        return box

    def _update(self, box):
        
        def on_click(b):
            if b.description == '..':
                self.path = os.path.split(self.path)[0]
            else:
                self.path = os.path.join(self.path, b.description)
            self._update_files()
            self._update(box)
        
        buttons = []
        #if self.files:
        button = widgets.Button(description='..', icon="level-up")
        button.style.button_color="#d1c4e9"
        button.on_click(on_click)
        buttons.append(button)
   
        for f in sorted(self.dirs):
            if ((f.startswith(".") and self.show_hidden) or (not f.startswith("."))):
                if os.name == "posix":
                    import pwd
                    full_path = os.path.join(self.path, f)
                    stats = os.stat(full_path).st_uid
                    owner_info = pwd.getpwuid(stats)
                    owner_id, owner_name = owner_info.pw_name, owner_info.pw_gecos
                    tooltip = "Name: {}\nOwner: [{}] {}.".format(f, owner_id, owner_name)
                else:
                    tooltip = "Name: {}\nClick to open folder.".format(f)

                button = widgets.Button(description=f,icon="folder", tooltip=tooltip)
                button.style.button_color = "#90caf9"
                button.on_click(on_click)
                buttons.append(button)
        
        if self.show_files:
            for f in sorted(self.files):
                if ((f.startswith(".") and self.show_hidden) or (not f.startswith("."))):
                    if os.name == "posix":
                        import pwd
                        full_path = os.path.join(self.path, f)
                        stats = os.stat(full_path).st_uid
                        owner_info = pwd.getpwuid(stats)
                        owner_id, owner_name = owner_info.pw_name, owner_info.pw_gecos
                        tooltip = "Name: {}\nOwner: [{}] {}.".format(f, owner_id, owner_name)
                    else:
                        tooltip = "Name: {}\nClick to open file.".format(f)

                    button = widgets.Button(description=f, icon="file", tooltip=tooltip)
                    button.style.button_color = "#9fa8da"
                    button.on_click(on_click)
                    buttons.append(button)

        #Rearrange in grid.

        self.path_text = Text(description="<b>Selected Path:</b>", placeholder="Paste a path here and click the OK button.", value=self.path)
        self.path_text.layout.width="400px"
        self.load_path_button = Button(description="Load Path", button_style="success", icon="check", tooltip="Click to load the selected path.")

        def load_path(*args):
            path = self.path_text.value
            if os.path.isfile(path):
                if self.show_files:
                    self.path = path
                else:
                    self.path = os.path.dirname(path)
            elif os.path.isdir(path):
                self.path = path
            else:
                self.path_text.value = self.path
            self._update_files()
            self._update(box)

        self.load_path_button.on_click(load_path)

        arrayed_list = [[self.path_text, self.load_path_button]] + get_arrayed_list(buttons, self.colnumber)
        children = []
        for row in arrayed_list:
            if isinstance(row, list):
                row_hbox = widgets.HBox(tuple(row))
                children.append(row_hbox)
            else:
                children.append(row)
                
        box.children = tuple(children)

def get_arrayed_list(inp_list, cols):
    j = 0
    new_list = []
    for i in range(int(len(inp_list)/cols)+1):
        new_list.append(inp_list[j:j+cols])
        j += cols
    return new_list
