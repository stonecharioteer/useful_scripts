import datetime
from IPython.display import HTML, display
def log(message):
    now = datetime.datetime.now
    display(HTML("<b>{}</b> : {}".format(now(), message)))

def code_toggler(debug=None):
    from IPython.display import HTML
    if debug is not None:
        debug = True
    else:
        debug = False
    script = """<script>
    code_show=%s;
    function code_toggle() {
     if (code_show){
     $('div.input').hide();
     } else {
     $('div.input').show();
     }
     code_show = !code_show
    }
    $( document ).ready(code_toggle);
    code_show_err=%s;
    function code_show_err_func() {
     if (code_show_err){
     $('div.output_stderr').hide();
     } else {
     $('div.output_stderr').show();
     }
     code_show_err = !code_show_err
    }
    $( document ).ready(code_show_err_func);
    </script>\n"""%("false" if debug else "true", "false" if debug else "true")
    html = ('Click <a href="javascript:code_toggle()">here</a>'
        ' to toggle code and <a href="javascript:code_show_err_func()">'
        'here</a> to toggle warnings.')
    return HTML(script+html)

def log_progress(sequence, every=None, size=None, start_time=None, name='Items'):
    """
        Function to provide a progress bar.
        ---
        This function is useful only when this program is run
        as a Jupyter notebook.

        In order to use this, run
            `jupyter nbextension enable --py --sys-prefix widgetsnbextension`
        prior to launching the notebook server.
    """
    from ipywidgets import IntProgress, HTML, VBox
    from IPython.display import display
    import datetime
    is_iterator = False
    if size is None:
        try:
            size = len(sequence)
        except TypeError:
            is_iterator = True
    if size is not None:
        if every is None:
            if size <= 200:
                every = 1
            else:
                every = int(size / 200)     # every 0.5%
    else:
        assert every is not None, 'sequence is iterator, set every'
    if start_time is None:
        start_time = datetime.datetime.now()
    if is_iterator:
        progress = IntProgress(min=0, max=1, value=1)
        progress.bar_style = 'info'
    else:
        progress = IntProgress(min=0, max=size, value=0)
    label = HTML()
    box = VBox(children=[label, progress])
    display(box)

    index = 0
    try:
        for index, record in enumerate(sequence, 1):
            if start_time is not None:
                time_elapsed = datetime.datetime.now() - start_time
            else:
                time_elapsed = datetime.datetime.now()
            if index == 1 or index % every == 0:
                if is_iterator:
                    label.value = '{name}: {index} / ? | Time Elapsed: {time_elapsed}'.format(
                        name=name,
                        index=index,
                        time_elapsed=time_elapsed
                    )
                else:
                    progress.value = index
                    label.value = u'{name}: {index} / {size} | Time Elapsed: {time_elapsed}'.format(
                        name=name,
                        index=index,
                        size=size,
                        time_elapsed=time_elapsed
                    )
            yield record
    except:
        progress.bar_style = 'danger'
        raise
    else:
        progress.bar_style = 'success'
        if start_time is not None:
            time_elapsed = datetime.datetime.now() - start_time
        else:
            time_elapsed = datetime.datetime.now()
        progress.value = index
        label.value = "{name}: {index} | Total Time: {time_elapsed}".format(
                name=name,
                index=str(index or '?'),
                time_elapsed=time_elapsed
            )