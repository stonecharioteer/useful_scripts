# HPCJOBMON
---

This tool will be used to submit and monitor jobs to the High Performance Cluster
used at GAI.

Created by Vinay Keerthi (yy4426).

Instructions
---

Before trying to use this application, be sure to add 
the directory which contains the checkout to your PYTHONPATH.

---

ToDo:

* Corpus of PyQt5 widgets.
* Build initial interface.
* Add actions.
