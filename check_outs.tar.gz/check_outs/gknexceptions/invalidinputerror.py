class InvalidInputError(Exception):
    pass
