#!/opt/anaconda3/bin/python
# -*- coding: utf-8 -*-
"""
widgetmethods

"""


def get_image(image_name, ext=None):
    import os
    if ext is None:
        ext = ".png"
    else:
        ext = ".{}".format(ext)
    return os.path.join(os.getcwd(), "images", "{}{}".format(image_name, ext))

